--
-- NOTE:
--
-- File paths need to be edited. Search for $$PATH$$ and
-- replace it with the path to the directory containing
-- the extracted data files.
--
--
-- PostgreSQL database dump
--

-- Dumped from database version 12.11
-- Dumped by pg_dump version 12.11

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

DROP DATABASE "nwd-atomskills-2023";
--
-- Name: nwd-atomskills-2023; Type: DATABASE; Schema: -; Owner: -
--

CREATE DATABASE "nwd-atomskills-2023" WITH TEMPLATE = template0 ENCODING = 'UTF8' LC_COLLATE = 'Russian_Russia.1251@icu' LC_CTYPE = 'Russian_Russia.1251';


\connect -reuse-previous=on "dbname='nwd-atomskills-2023'"

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: camunda; Type: SCHEMA; Schema: -; Owner: -
--

CREATE SCHEMA camunda;


--
-- Name: crm_request; Type: SCHEMA; Schema: -; Owner: -
--

CREATE SCHEMA crm_request;


--
-- Name: dictionaries; Type: SCHEMA; Schema: -; Owner: -
--

CREATE SCHEMA dictionaries;


--
-- Name: uni_api; Type: SCHEMA; Schema: -; Owner: -
--

CREATE SCHEMA uni_api;


--
-- Name: uni_component; Type: SCHEMA; Schema: -; Owner: -
--

CREATE SCHEMA uni_component;


--
-- Name: uni_const; Type: SCHEMA; Schema: -; Owner: -
--

CREATE SCHEMA uni_const;


--
-- Name: uni_error; Type: SCHEMA; Schema: -; Owner: -
--

CREATE SCHEMA uni_error;


--
-- Name: uni_generator; Type: SCHEMA; Schema: -; Owner: -
--

CREATE SCHEMA uni_generator;


--
-- Name: dblink; Type: EXTENSION; Schema: -; Owner: -
--

CREATE EXTENSION IF NOT EXISTS dblink WITH SCHEMA public;


--
-- Name: EXTENSION dblink; Type: COMMENT; Schema: -; Owner: -
--

COMMENT ON EXTENSION dblink IS 'connect to other PostgreSQL databases from within a database';


--
-- Name: t_boolean; Type: DOMAIN; Schema: public; Owner: -
--

CREATE DOMAIN public.t_boolean AS boolean;


--
-- Name: t_caption; Type: DOMAIN; Schema: public; Owner: -
--

CREATE DOMAIN public.t_caption AS character varying(254);


--
-- Name: t_clob; Type: DOMAIN; Schema: public; Owner: -
--

CREATE DOMAIN public.t_clob AS text;


--
-- Name: t_code; Type: DOMAIN; Schema: public; Owner: -
--

CREATE DOMAIN public.t_code AS character varying(254);


--
-- Name: t_date; Type: DOMAIN; Schema: public; Owner: -
--

CREATE DOMAIN public.t_date AS date;


--
-- Name: t_datetime; Type: DOMAIN; Schema: public; Owner: -
--

CREATE DOMAIN public.t_datetime AS timestamp without time zone;


--
-- Name: t_description; Type: DOMAIN; Schema: public; Owner: -
--

CREATE DOMAIN public.t_description AS character varying(4000);


--
-- Name: t_float; Type: DOMAIN; Schema: public; Owner: -
--

CREATE DOMAIN public.t_float AS numeric;


--
-- Name: t_html; Type: DOMAIN; Schema: public; Owner: -
--

CREATE DOMAIN public.t_html AS text;


--
-- Name: t_id; Type: DOMAIN; Schema: public; Owner: -
--

CREATE DOMAIN public.t_id AS numeric(15,0);


--
-- Name: t_integer; Type: DOMAIN; Schema: public; Owner: -
--

CREATE DOMAIN public.t_integer AS integer;


--
-- Name: t_json; Type: DOMAIN; Schema: public; Owner: -
--

CREATE DOMAIN public.t_json AS jsonb;


--
-- Name: t_longstring; Type: DOMAIN; Schema: public; Owner: -
--

CREATE DOMAIN public.t_longstring AS character varying(4000);


--
-- Name: t_money; Type: DOMAIN; Schema: public; Owner: -
--

CREATE DOMAIN public.t_money AS numeric(15,4);


--
-- Name: t_name; Type: DOMAIN; Schema: public; Owner: -
--

CREATE DOMAIN public.t_name AS character varying(30);


--
-- Name: t_shortstring; Type: DOMAIN; Schema: public; Owner: -
--

CREATE DOMAIN public.t_shortstring AS character varying(254);


--
-- Name: t_xml; Type: DOMAIN; Schema: public; Owner: -
--

CREATE DOMAIN public.t_xml AS xml;


--
-- Name: request__after_edit(public.t_id); Type: FUNCTION; Schema: crm_request; Owner: -
--

CREATE FUNCTION crm_request.request__after_edit(idp_self public.t_id) RETURNS void
    LANGUAGE plpgsql
    AS $$
/*<meta object="crm_request.request__after_edit"
        title="Функция after_edit таблицы crm_request.request"
        author="sys"
        created="26.02.2023"
        version="1.0"
        description="">
</meta>*/
begin
  perform crm_request.request__validate(idp_self);
end; $$;


--
-- Name: request__create_request(); Type: FUNCTION; Schema: crm_request; Owner: -
--

CREATE FUNCTION crm_request.request__create_request() RETURNS public.t_id
    LANGUAGE plpgsql
    AS $$
/*<meta object="crm_request.request__insert_record"
        title="Функция создания рандомного заказа"
        author="sys"
        created="26.02.2023"
        version="1.0"
        description="Функция создания рандомного заказа">
</meta>*/
declare
  nv_min_items t_integer := 2;
  nv_max_items t_integer := 12;
  nv_items t_integer := floor(random()*(nv_max_items-nv_min_items) + nv_min_items);

  nv_min_item_qty t_integer := 100;
  nv_max_item_qty t_integer := 1000;
  nv_item_qty t_integer := floor(random()*(nv_max_item_qty-nv_min_item_qty) + nv_min_item_qty);

  nv_contractor_count t_integer;
  idv_random_contractor t_id;

  idv_request t_id;
  idv_request_item t_id;
  dv_release_date t_datetime;
begin
  begin
    select count(*)
    into nv_contractor_count
    from dictionaries.contractor ctr;
  end;
  begin
    select ctr.id
    into idv_random_contractor
    from dictionaries.contractor ctr
    order by ctr.id
    offset floor(random()*nv_contractor_count)
    limit 1;
  end;

  idv_request := crm_request.request__insert_record();
  for i in 1..nv_items loop
    idv_request_item := crm_request.request_item__insert_record(idv_request
                                                               ,dictionaries.products__create_product());
    nv_item_qty := floor(random()*(nv_max_item_qty-nv_min_item_qty) + nv_min_item_qty);
    perform crm_request.request_item__set_quantity(idv_request_item, nv_item_qty);
    perform crm_request.request_item__after_edit(idv_request_item);
  end loop;
  begin
    select now()::t_date + (interval '1 sec'
          *(coalesce(sum(prod.n_milling_time*req_item.f_quantity),0)
           +coalesce(sum(prod.n_lathe_time*req_item.f_quantity),0)))
    into dv_release_date
    from crm_request.request_item req_item
    inner join dictionaries.products prod on prod.id = req_item.id_product
    where req_item.id_request = idv_request;
  end;
  raise notice '%', dv_release_date;
  perform crm_request.request__set_release_date(idv_request, dv_release_date::t_date);
  perform crm_request.request__after_edit(idv_request);
  return idv_request;
end;
$$;


--
-- Name: request__delete_record(public.t_id); Type: FUNCTION; Schema: crm_request; Owner: -
--

CREATE FUNCTION crm_request.request__delete_record(idp_self public.t_id) RETURNS void
    LANGUAGE plpgsql
    AS $$
/*<meta object="crm_request.request__delete_record"
        title="Функция delete_record таблицы crm_request.request"
        author="sys"
        created="26.02.2023"
        version="1.0"
        description="">
</meta>*/
begin
 delete from crm_request.request where id = idp_self;
end; $$;


--
-- Name: seq_request_number; Type: SEQUENCE; Schema: crm_request; Owner: -
--

CREATE SEQUENCE crm_request.seq_request_number
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: request; Type: TABLE; Schema: crm_request; Owner: -
--

CREATE TABLE crm_request.request (
    id public.t_id NOT NULL,
    s_number public.t_shortstring DEFAULT (((now())::public.t_date || '-'::text) || nextval('crm_request.seq_request_number'::regclass)) NOT NULL,
    d_date public.t_date DEFAULT (now())::public.t_date NOT NULL,
    id_contractor public.t_id,
    s_description public.t_description,
    s_state_code public.t_code DEFAULT 'DRAFT'::character varying NOT NULL,
    d_release_date public.t_date
);


--
-- Name: TABLE request; Type: COMMENT; Schema: crm_request; Owner: -
--

COMMENT ON TABLE crm_request.request IS 'Заявка';


--
-- Name: COLUMN request.id; Type: COMMENT; Schema: crm_request; Owner: -
--

COMMENT ON COLUMN crm_request.request.id IS 'Код';


--
-- Name: COLUMN request.s_number; Type: COMMENT; Schema: crm_request; Owner: -
--

COMMENT ON COLUMN crm_request.request.s_number IS 'Номер документа';


--
-- Name: COLUMN request.d_date; Type: COMMENT; Schema: crm_request; Owner: -
--

COMMENT ON COLUMN crm_request.request.d_date IS 'Дата документа';


--
-- Name: COLUMN request.id_contractor; Type: COMMENT; Schema: crm_request; Owner: -
--

COMMENT ON COLUMN crm_request.request.id_contractor IS 'Код контрагента-заявителя';


--
-- Name: COLUMN request.s_description; Type: COMMENT; Schema: crm_request; Owner: -
--

COMMENT ON COLUMN crm_request.request.s_description IS 'Описание';


--
-- Name: COLUMN request.s_state_code; Type: COMMENT; Schema: crm_request; Owner: -
--

COMMENT ON COLUMN crm_request.request.s_state_code IS 'Код состояния';


--
-- Name: COLUMN request.d_release_date; Type: COMMENT; Schema: crm_request; Owner: -
--

COMMENT ON COLUMN crm_request.request.d_release_date IS 'Желаемая дата изготовления';


--
-- Name: request__get_row(public.t_id); Type: FUNCTION; Schema: crm_request; Owner: -
--

CREATE FUNCTION crm_request.request__get_row(idp_self public.t_id) RETURNS crm_request.request
    LANGUAGE sql
    AS $$
/*<meta object="crm_request.request__get_row"
        title="Функция get_row таблицы crm_request.request"
        author="sys"
        created="26.02.2023"
        version="1.0"
        description="">
</meta>*/
  select t.* from crm_request.request t where t.id = idp_self;
$$;


--
-- Name: request__insert_record(); Type: FUNCTION; Schema: crm_request; Owner: -
--

CREATE FUNCTION crm_request.request__insert_record() RETURNS public.t_id
    LANGUAGE plpgsql
    AS $$
/*<meta object="crm_request.request__insert_record"
        title="Функция insert_record таблицы crm_request.request"
        author="sys"
        created="26.02.2023"
        version="1.0"
        description="">
</meta>*/
declare
 rv_row crm_request.request%rowtype;
begin
 rv_row.id := uni_api.get_table_id('crm_request','request');

 insert into crm_request.request(id)
 values(rv_row.id);

 return rv_row.id;

end; $$;


--
-- Name: request__lock_record(public.t_id); Type: FUNCTION; Schema: crm_request; Owner: -
--

CREATE FUNCTION crm_request.request__lock_record(idp_self public.t_id) RETURNS void
    LANGUAGE plpgsql
    AS $$
/*<meta object="crm_request.request__lock_record"
        title="Функция lock_record таблицы crm_request.request"
        author="sys"
        created="26.02.2023"
        version="1.0"
        description="">
</meta>*/
declare
 bv_is_ok t_boolean;
 sv_component_name t_name = 'UNI';
 sv_error_name t_name = 'ENoLockedRow';
begin
 select true into bv_is_ok from crm_request.request where id = idp_self for update nowait;
 exception when lock_not_available then
   perform uni_error.generate(sv_component_name, sv_error_name, idp_self::t_shortstring);
end; $$;


--
-- Name: request__set_contractor(public.t_id, public.t_id, public.t_boolean); Type: FUNCTION; Schema: crm_request; Owner: -
--

CREATE FUNCTION crm_request.request__set_contractor(idp_self public.t_id, p_value public.t_id, bp_internal_call public.t_boolean DEFAULT false) RETURNS void
    LANGUAGE plpgsql
    AS $$
/*<meta object="crm_request.request__set_contractor"
        title="Функция setter для колонки "id_contractor" таблицы crm_request.request"
        author="sys"
        created="26.02.2023"
        version="1.0"
        description="">
</meta>*/
declare
  sv_schema_name t_name = 'crm_request';
  sv_table_name t_name = 'request';
  sv_column_name t_name = 'id_contractor';
  sv_identity_field t_name = 'id';
begin
 perform uni_api.set_table_field_value(sv_schema_name, sv_table_name, sv_column_name,idp_self, p_value, sv_identity_field);
end; $$;


--
-- Name: request__set_date(public.t_id, public.t_date, public.t_boolean); Type: FUNCTION; Schema: crm_request; Owner: -
--

CREATE FUNCTION crm_request.request__set_date(idp_self public.t_id, p_value public.t_date, bp_internal_call public.t_boolean DEFAULT false) RETURNS void
    LANGUAGE plpgsql
    AS $$
/*<meta object="crm_request.request__set_date"
        title="Функция setter для колонки "d_date" таблицы crm_request.request"
        author="sys"
        created="26.02.2023"
        version="1.0"
        description="">
</meta>*/
declare
  sv_schema_name t_name = 'crm_request';
  sv_table_name t_name = 'request';
  sv_column_name t_name = 'd_date';
  sv_identity_field t_name = 'id';
begin
 perform uni_api.set_table_field_value(sv_schema_name, sv_table_name, sv_column_name,idp_self, p_value, sv_identity_field);
end; $$;


--
-- Name: request__set_description(public.t_id, public.t_description, public.t_boolean); Type: FUNCTION; Schema: crm_request; Owner: -
--

CREATE FUNCTION crm_request.request__set_description(idp_self public.t_id, p_value public.t_description, bp_internal_call public.t_boolean DEFAULT false) RETURNS void
    LANGUAGE plpgsql
    AS $$
/*<meta object="crm_request.request__set_description"
        title="Функция setter для колонки "s_description" таблицы crm_request.request"
        author="sys"
        created="26.02.2023"
        version="1.0"
        description="">
</meta>*/
declare
  sv_schema_name t_name = 'crm_request';
  sv_table_name t_name = 'request';
  sv_column_name t_name = 's_description';
  sv_identity_field t_name = 'id';
begin
 perform uni_api.set_table_field_value(sv_schema_name, sv_table_name, sv_column_name,idp_self, p_value, sv_identity_field);
end; $$;


--
-- Name: request__set_number(public.t_id, public.t_shortstring, public.t_boolean); Type: FUNCTION; Schema: crm_request; Owner: -
--

CREATE FUNCTION crm_request.request__set_number(idp_self public.t_id, p_value public.t_shortstring, bp_internal_call public.t_boolean DEFAULT false) RETURNS void
    LANGUAGE plpgsql
    AS $$
/*<meta object="crm_request.request__set_number"
        title="Функция setter для колонки "s_number" таблицы crm_request.request"
        author="sys"
        created="26.02.2023"
        version="1.0"
        description="">
</meta>*/
declare
  sv_schema_name t_name = 'crm_request';
  sv_table_name t_name = 'request';
  sv_column_name t_name = 's_number';
  sv_identity_field t_name = 'id';
begin
 perform uni_api.set_table_field_value(sv_schema_name, sv_table_name, sv_column_name,idp_self, p_value, sv_identity_field);
end; $$;


--
-- Name: request__set_release_date(public.t_id, public.t_date, public.t_boolean); Type: FUNCTION; Schema: crm_request; Owner: -
--

CREATE FUNCTION crm_request.request__set_release_date(idp_self public.t_id, p_value public.t_date, bp_internal_call public.t_boolean DEFAULT false) RETURNS void
    LANGUAGE plpgsql
    AS $$
/*<meta object="crm_request.request__set_release_date"
        title="Функция setter для колонки "d_release_date" таблицы crm_request.request"
        author="sys"
        created="26.02.2023"
        version="1.0"
        description="">
</meta>*/
declare
  sv_schema_name t_name = 'crm_request';
  sv_table_name t_name = 'request';
  sv_column_name t_name = 'd_release_date';
  sv_identity_field t_name = 'id';
begin
 perform uni_api.set_table_field_value(sv_schema_name, sv_table_name, sv_column_name,idp_self, p_value, sv_identity_field);
end; $$;


--
-- Name: request__set_state_code(public.t_id, public.t_code, public.t_boolean); Type: FUNCTION; Schema: crm_request; Owner: -
--

CREATE FUNCTION crm_request.request__set_state_code(idp_self public.t_id, p_value public.t_code, bp_internal_call public.t_boolean DEFAULT false) RETURNS void
    LANGUAGE plpgsql
    AS $$
/*<meta object="crm_request.request__set_state_code"
        title="Функция setter для колонки "s_state_code" таблицы crm_request.request"
        author="sys"
        created="26.02.2023"
        version="1.0"
        description="">
</meta>*/
declare
  sv_schema_name t_name = 'crm_request';
  sv_table_name t_name = 'request';
  sv_column_name t_name = 's_state_code';
  sv_identity_field t_name = 'id';
begin
 perform uni_api.set_table_field_value(sv_schema_name, sv_table_name, sv_column_name,idp_self, p_value, sv_identity_field);
end; $$;


--
-- Name: request__validate(public.t_id); Type: FUNCTION; Schema: crm_request; Owner: -
--

CREATE FUNCTION crm_request.request__validate(idp_self public.t_id) RETURNS void
    LANGUAGE plpgsql
    AS $$
/*<meta object="crm_request.request__validate"
        title="Функция validate таблицы crm_request.request"
        author="sys"
        created="26.02.2023"
        version="1.0"
        description="">
</meta>*/
begin
 null;
end; $$;


--
-- Name: request_item__after_edit(public.t_id); Type: FUNCTION; Schema: crm_request; Owner: -
--

CREATE FUNCTION crm_request.request_item__after_edit(idp_self public.t_id) RETURNS void
    LANGUAGE plpgsql
    AS $$
/*<meta object="crm_request.request_item__after_edit"
        title="Функция after_edit таблицы crm_request.request_item"
        author="sys"
        created="23.02.2023"
        version="1.0"
        description="">
</meta>*/
begin
  perform crm_request.request_item__validate(idp_self);
end; $$;


--
-- Name: request_item__delete_record(public.t_id); Type: FUNCTION; Schema: crm_request; Owner: -
--

CREATE FUNCTION crm_request.request_item__delete_record(idp_self public.t_id) RETURNS void
    LANGUAGE plpgsql
    AS $$
/*<meta object="crm_request.request_item__delete_record"
        title="Функция delete_record таблицы crm_request.request_item"
        author="sys"
        created="23.02.2023"
        version="1.0"
        description="">
</meta>*/
begin
 delete from crm_request.request_item where id = idp_self;
end; $$;


--
-- Name: request_item; Type: TABLE; Schema: crm_request; Owner: -
--

CREATE TABLE crm_request.request_item (
    id public.t_id NOT NULL,
    id_request public.t_id NOT NULL,
    id_product public.t_id NOT NULL,
    f_quantity public.t_float DEFAULT 0 NOT NULL,
    f_quantity_exec public.t_float DEFAULT 0 NOT NULL
);


--
-- Name: TABLE request_item; Type: COMMENT; Schema: crm_request; Owner: -
--

COMMENT ON TABLE crm_request.request_item IS 'Спецификация заявки';


--
-- Name: COLUMN request_item.id; Type: COMMENT; Schema: crm_request; Owner: -
--

COMMENT ON COLUMN crm_request.request_item.id IS 'Код';


--
-- Name: COLUMN request_item.id_request; Type: COMMENT; Schema: crm_request; Owner: -
--

COMMENT ON COLUMN crm_request.request_item.id_request IS 'Код заявки';


--
-- Name: COLUMN request_item.id_product; Type: COMMENT; Schema: crm_request; Owner: -
--

COMMENT ON COLUMN crm_request.request_item.id_product IS 'Код ГП';


--
-- Name: COLUMN request_item.f_quantity; Type: COMMENT; Schema: crm_request; Owner: -
--

COMMENT ON COLUMN crm_request.request_item.f_quantity IS 'Количество ГП';


--
-- Name: COLUMN request_item.f_quantity_exec; Type: COMMENT; Schema: crm_request; Owner: -
--

COMMENT ON COLUMN crm_request.request_item.f_quantity_exec IS 'Количество ГП исполнено';


--
-- Name: request_item__get_row(public.t_id); Type: FUNCTION; Schema: crm_request; Owner: -
--

CREATE FUNCTION crm_request.request_item__get_row(idp_self public.t_id) RETURNS crm_request.request_item
    LANGUAGE sql
    AS $$
/*<meta object="crm_request.request_item__get_row"
        title="Функция get_row таблицы crm_request.request_item"
        author="sys"
        created="23.02.2023"
        version="1.0"
        description="">
</meta>*/
  select t.* from crm_request.request_item t where t.id = idp_self;
$$;


--
-- Name: request_item__insert_record(public.t_id, public.t_id); Type: FUNCTION; Schema: crm_request; Owner: -
--

CREATE FUNCTION crm_request.request_item__insert_record(idp_request public.t_id, idp_product public.t_id) RETURNS public.t_id
    LANGUAGE plpgsql
    AS $$
/*<meta object="crm_request.request_item__insert_record"
        title="Функция insert_record таблицы crm_request.request_item"
        author="sys"
        created="23.02.2023"
        version="1.0"
        description="">
</meta>*/
declare
 rv_row crm_request.request_item%rowtype;
begin
 rv_row.id := uni_api.get_table_id('crm_request','request_item');
 rv_row.id_request := idp_request;
 rv_row.id_product := idp_product;

 insert into crm_request.request_item(id, id_request, id_product)
 values(rv_row.id, rv_row.id_request, rv_row.id_product);

 return rv_row.id;

end; $$;


--
-- Name: request_item__lock_record(public.t_id); Type: FUNCTION; Schema: crm_request; Owner: -
--

CREATE FUNCTION crm_request.request_item__lock_record(idp_self public.t_id) RETURNS void
    LANGUAGE plpgsql
    AS $$
/*<meta object="crm_request.request_item__lock_record"
        title="Функция lock_record таблицы crm_request.request_item"
        author="sys"
        created="23.02.2023"
        version="1.0"
        description="">
</meta>*/
declare
 bv_is_ok t_boolean;
 sv_component_name t_name = 'UNI';
 sv_error_name t_name = 'ENoLockedRow';
begin
 select true into bv_is_ok from crm_request.request_item where id = idp_self for update nowait;
 exception when lock_not_available then
   perform uni_error.generate(sv_component_name, sv_error_name, idp_self::t_shortstring);
end; $$;


--
-- Name: request_item__set_product(public.t_id, public.t_id, public.t_boolean); Type: FUNCTION; Schema: crm_request; Owner: -
--

CREATE FUNCTION crm_request.request_item__set_product(idp_self public.t_id, p_value public.t_id, bp_internal_call public.t_boolean DEFAULT false) RETURNS void
    LANGUAGE plpgsql
    AS $$
/*<meta object="crm_request.request_item__set_product"
        title="Функция setter для колонки "id_product" таблицы crm_request.request_item"
        author="sys"
        created="23.02.2023"
        version="1.0"
        description="">
</meta>*/
declare
  sv_schema_name t_name = 'crm_request';
  sv_table_name t_name = 'request_item';
  sv_column_name t_name = 'id_product';
  sv_identity_field t_name = 'id';
begin
 perform uni_api.set_table_field_value(sv_schema_name, sv_table_name, sv_column_name,idp_self, p_value, sv_identity_field);
end; $$;


--
-- Name: request_item__set_quantity(public.t_id, public.t_float, public.t_boolean); Type: FUNCTION; Schema: crm_request; Owner: -
--

CREATE FUNCTION crm_request.request_item__set_quantity(idp_self public.t_id, p_value public.t_float, bp_internal_call public.t_boolean DEFAULT false) RETURNS void
    LANGUAGE plpgsql
    AS $$
/*<meta object="crm_request.request_item__set_quantity"
        title="Функция setter для колонки "f_quantity" таблицы crm_request.request_item"
        author="sys"
        created="23.02.2023"
        version="1.0"
        description="">
</meta>*/
declare
  sv_schema_name t_name = 'crm_request';
  sv_table_name t_name = 'request_item';
  sv_column_name t_name = 'f_quantity';
  sv_identity_field t_name = 'id';
begin
 perform uni_api.set_table_field_value(sv_schema_name, sv_table_name, sv_column_name,idp_self, p_value, sv_identity_field);
end; $$;


--
-- Name: request_item__set_quantity_exec(public.t_id, public.t_float, public.t_boolean); Type: FUNCTION; Schema: crm_request; Owner: -
--

CREATE FUNCTION crm_request.request_item__set_quantity_exec(idp_self public.t_id, p_value public.t_float, bp_internal_call public.t_boolean DEFAULT false) RETURNS void
    LANGUAGE plpgsql
    AS $$
/*<meta object="crm_request.request_item__set_quantity_exec"
        title="Функция setter для колонки "f_quantity_exec" таблицы crm_request.request_item"
        author="sys"
        created="23.02.2023"
        version="1.0"
        description="">
</meta>*/
declare
  sv_schema_name t_name = 'crm_request';
  sv_table_name t_name = 'request_item';
  sv_column_name t_name = 'f_quantity_exec';
  sv_identity_field t_name = 'id';
begin
 perform uni_api.set_table_field_value(sv_schema_name, sv_table_name, sv_column_name,idp_self, p_value, sv_identity_field);
end; $$;


--
-- Name: request_item__set_request(public.t_id, public.t_id, public.t_boolean); Type: FUNCTION; Schema: crm_request; Owner: -
--

CREATE FUNCTION crm_request.request_item__set_request(idp_self public.t_id, p_value public.t_id, bp_internal_call public.t_boolean DEFAULT false) RETURNS void
    LANGUAGE plpgsql
    AS $$
/*<meta object="crm_request.request_item__set_request"
        title="Функция setter для колонки "id_request" таблицы crm_request.request_item"
        author="sys"
        created="23.02.2023"
        version="1.0"
        description="">
</meta>*/
declare
  sv_schema_name t_name = 'crm_request';
  sv_table_name t_name = 'request_item';
  sv_column_name t_name = 'id_request';
  sv_identity_field t_name = 'id';
begin
 perform uni_api.set_table_field_value(sv_schema_name, sv_table_name, sv_column_name,idp_self, p_value, sv_identity_field);
end; $$;


--
-- Name: request_item__validate(public.t_id); Type: FUNCTION; Schema: crm_request; Owner: -
--

CREATE FUNCTION crm_request.request_item__validate(idp_self public.t_id) RETURNS void
    LANGUAGE plpgsql
    AS $$
/*<meta object="crm_request.request_item__validate"
        title="Функция validate таблицы crm_request.request_item"
        author="sys"
        created="23.02.2023"
        version="1.0"
        description="">
</meta>*/
begin
 null;
end; $$;


--
-- Name: contractor__after_edit(public.t_id); Type: FUNCTION; Schema: dictionaries; Owner: -
--

CREATE FUNCTION dictionaries.contractor__after_edit(idp_self public.t_id) RETURNS void
    LANGUAGE plpgsql
    AS $$
/*<meta object="dictionaries.contractor__after_edit"
        title="Функция after_edit таблицы dictionaries.contractor"
        author="sys"
        created="26.02.2023"
        version="1.0"
        description="">
</meta>*/
begin
  perform dictionaries.contractor__validate(idp_self);
end; $$;


--
-- Name: contractor__delete_record(public.t_id); Type: FUNCTION; Schema: dictionaries; Owner: -
--

CREATE FUNCTION dictionaries.contractor__delete_record(idp_self public.t_id) RETURNS void
    LANGUAGE plpgsql
    AS $$
/*<meta object="dictionaries.contractor__delete_record"
        title="Функция delete_record таблицы dictionaries.contractor"
        author="sys"
        created="26.02.2023"
        version="1.0"
        description="">
</meta>*/
begin
 delete from dictionaries.contractor where id = idp_self;
end; $$;


--
-- Name: contractor; Type: TABLE; Schema: dictionaries; Owner: -
--

CREATE TABLE dictionaries.contractor (
    id public.t_id NOT NULL,
    s_inn public.t_shortstring NOT NULL,
    s_caption public.t_caption
);


--
-- Name: TABLE contractor; Type: COMMENT; Schema: dictionaries; Owner: -
--

COMMENT ON TABLE dictionaries.contractor IS 'Справочник кнтрагентов';


--
-- Name: COLUMN contractor.id; Type: COMMENT; Schema: dictionaries; Owner: -
--

COMMENT ON COLUMN dictionaries.contractor.id IS 'Код';


--
-- Name: COLUMN contractor.s_inn; Type: COMMENT; Schema: dictionaries; Owner: -
--

COMMENT ON COLUMN dictionaries.contractor.s_inn IS 'ИНН';


--
-- Name: COLUMN contractor.s_caption; Type: COMMENT; Schema: dictionaries; Owner: -
--

COMMENT ON COLUMN dictionaries.contractor.s_caption IS 'Наименование';


--
-- Name: contractor__get_row(public.t_id); Type: FUNCTION; Schema: dictionaries; Owner: -
--

CREATE FUNCTION dictionaries.contractor__get_row(idp_self public.t_id) RETURNS dictionaries.contractor
    LANGUAGE sql
    AS $$
/*<meta object="dictionaries.contractor__get_row"
        title="Функция get_row таблицы dictionaries.contractor"
        author="sys"
        created="26.02.2023"
        version="1.0"
        description="">
</meta>*/
  select t.* from dictionaries.contractor t where t.id = idp_self;
$$;


--
-- Name: contractor__insert_record(public.t_shortstring); Type: FUNCTION; Schema: dictionaries; Owner: -
--

CREATE FUNCTION dictionaries.contractor__insert_record(sp_inn public.t_shortstring) RETURNS public.t_id
    LANGUAGE plpgsql
    AS $$
/*<meta object="dictionaries.contractor__insert_record"
        title="Функция insert_record таблицы dictionaries.contractor"
        author="sys"
        created="26.02.2023"
        version="1.0"
        description="">
</meta>*/
declare
 rv_row dictionaries.contractor%rowtype;
begin
 rv_row.id := uni_api.get_table_id('dictionaries','contractor');
 rv_row.s_inn := sp_inn;

 insert into dictionaries.contractor(id, s_inn)
 values(rv_row.id, rv_row.s_inn);

 return rv_row.id;

end; $$;


--
-- Name: contractor__lock_record(public.t_id); Type: FUNCTION; Schema: dictionaries; Owner: -
--

CREATE FUNCTION dictionaries.contractor__lock_record(idp_self public.t_id) RETURNS void
    LANGUAGE plpgsql
    AS $$
/*<meta object="dictionaries.contractor__lock_record"
        title="Функция lock_record таблицы dictionaries.contractor"
        author="sys"
        created="26.02.2023"
        version="1.0"
        description="">
</meta>*/
declare
 bv_is_ok t_boolean;
 sv_component_name t_name = 'UNI';
 sv_error_name t_name = 'ENoLockedRow';
begin
 select true into bv_is_ok from dictionaries.contractor where id = idp_self for update nowait;
 exception when lock_not_available then
   perform uni_error.generate(sv_component_name, sv_error_name, idp_self::t_shortstring);
end; $$;


--
-- Name: contractor__set_caption(public.t_id, public.t_caption, public.t_boolean); Type: FUNCTION; Schema: dictionaries; Owner: -
--

CREATE FUNCTION dictionaries.contractor__set_caption(idp_self public.t_id, p_value public.t_caption, bp_internal_call public.t_boolean DEFAULT false) RETURNS void
    LANGUAGE plpgsql
    AS $$
/*<meta object="dictionaries.contractor__set_caption"
        title="Функция setter для колонки "s_caption" таблицы dictionaries.contractor"
        author="sys"
        created="26.02.2023"
        version="1.0"
        description="">
</meta>*/
declare
  sv_schema_name t_name = 'dictionaries';
  sv_table_name t_name = 'contractor';
  sv_column_name t_name = 's_caption';
  sv_identity_field t_name = 'id';
begin
 perform uni_api.set_table_field_value(sv_schema_name, sv_table_name, sv_column_name,idp_self, p_value, sv_identity_field);
end; $$;


--
-- Name: contractor__set_inn(public.t_id, public.t_shortstring, public.t_boolean); Type: FUNCTION; Schema: dictionaries; Owner: -
--

CREATE FUNCTION dictionaries.contractor__set_inn(idp_self public.t_id, p_value public.t_shortstring, bp_internal_call public.t_boolean DEFAULT false) RETURNS void
    LANGUAGE plpgsql
    AS $$
/*<meta object="dictionaries.contractor__set_inn"
        title="Функция setter для колонки "s_inn" таблицы dictionaries.contractor"
        author="sys"
        created="26.02.2023"
        version="1.0"
        description="">
</meta>*/
declare
  sv_schema_name t_name = 'dictionaries';
  sv_table_name t_name = 'contractor';
  sv_column_name t_name = 's_inn';
  sv_identity_field t_name = 'id';
begin
 perform uni_api.set_table_field_value(sv_schema_name, sv_table_name, sv_column_name,idp_self, p_value, sv_identity_field);
end; $$;


--
-- Name: contractor__validate(public.t_id); Type: FUNCTION; Schema: dictionaries; Owner: -
--

CREATE FUNCTION dictionaries.contractor__validate(idp_self public.t_id) RETURNS void
    LANGUAGE plpgsql
    AS $$
/*<meta object="dictionaries.contractor__validate"
        title="Функция validate таблицы dictionaries.contractor"
        author="sys"
        created="26.02.2023"
        version="1.0"
        description="">
</meta>*/
begin
 null;
end; $$;


--
-- Name: products__after_edit(public.t_id); Type: FUNCTION; Schema: dictionaries; Owner: -
--

CREATE FUNCTION dictionaries.products__after_edit(idp_self public.t_id) RETURNS void
    LANGUAGE plpgsql
    AS $$
/*<meta object="dictionaries.products__after_edit"
        title="Функция after_edit таблицы dictionaries.products"
        author="sys"
        created="25.02.2023"
        version="1.0"
        description="">
</meta>*/
begin
  perform dictionaries.products__validate(idp_self);
end; $$;


--
-- Name: products__create_product(); Type: FUNCTION; Schema: dictionaries; Owner: -
--

CREATE FUNCTION dictionaries.products__create_product() RETURNS public.t_id
    LANGUAGE plpgsql
    AS $$
/*<meta object="dictionaries.products__insert_record"
        title="Функция создания рандомного продукта"
        author="sys"
        created="26.02.2023"
        version="1.0"
        description="Функция создания рандомного продукта">
</meta>*/
declare
  nv_min_mil_time t_integer := 20;
  nv_max_mil_time t_integer := 120;
  nv_min_lathe_time t_integer := 10;
  nv_max_lathe_time t_integer := 160;
  
  nv_mil_time t_integer := floor(random()*(nv_max_mil_time-nv_min_mil_time) + nv_min_mil_time);
  nv_lathe_time t_integer := floor(random()*(nv_max_lathe_time-nv_min_lathe_time) + nv_min_lathe_time);
  idv_new_product t_id;
begin
  begin
  	select prod.id
  	into idv_new_product
  	from dictionaries.products prod
  	where prod.s_code = format('ML%sLT%s',nv_mil_time, nv_lathe_time);
  end;
  if coalesce(idv_new_product, 0) = 0 then
    idv_new_product := dictionaries.products__insert_record(format('ML%sLT%s',nv_mil_time, nv_lathe_time));
    perform dictionaries.products__set_caption(idv_new_product, format('ФР%s-ТК%s',nv_mil_time, nv_lathe_time));
    perform dictionaries.products__set_milling_time(idv_new_product, nv_mil_time);
    perform dictionaries.products__set_lathe_time(idv_new_product, nv_lathe_time);
    perform dictionaries.products__after_edit(idv_new_product);
  end if;
  return idv_new_product;
end; $$;


--
-- Name: products__delete_record(public.t_id); Type: FUNCTION; Schema: dictionaries; Owner: -
--

CREATE FUNCTION dictionaries.products__delete_record(idp_self public.t_id) RETURNS void
    LANGUAGE plpgsql
    AS $$
/*<meta object="dictionaries.products__delete_record"
        title="Функция delete_record таблицы dictionaries.products"
        author="sys"
        created="25.02.2023"
        version="1.0"
        description="">
</meta>*/
begin
 delete from dictionaries.products where id = idp_self;
end; $$;


--
-- Name: products__find_by_code(public.t_code); Type: FUNCTION; Schema: dictionaries; Owner: -
--

CREATE FUNCTION dictionaries.products__find_by_code(sp_code public.t_code) RETURNS public.t_id
    LANGUAGE plpgsql
    AS $$
/*<meta object="dictionaries.products__find_by_code"
        title="Функция find_by_code таблицы dictionaries.products"
        author="sys"
        created="25.02.2023"
        version="1.0"
        description="">
</meta>*/
declare
  nv_count t_integer := 0;
  idv_self t_id;
begin
  select count(*) into nv_count from dictionaries.products t where t.s_code = sp_code;
  if nv_count > 1 then
    return 0;
  end if;
  select t.id into idv_self from dictionaries.products t where t.s_code = sp_code;
  return idv_self;
end;
$$;


--
-- Name: products; Type: TABLE; Schema: dictionaries; Owner: -
--

CREATE TABLE dictionaries.products (
    id public.t_id NOT NULL,
    s_code public.t_code NOT NULL,
    s_caption public.t_caption,
    n_milling_time public.t_integer DEFAULT 0 NOT NULL,
    n_lathe_time public.t_integer DEFAULT 0 NOT NULL
);


--
-- Name: TABLE products; Type: COMMENT; Schema: dictionaries; Owner: -
--

COMMENT ON TABLE dictionaries.products IS 'Справочник готовой продукции';


--
-- Name: COLUMN products.id; Type: COMMENT; Schema: dictionaries; Owner: -
--

COMMENT ON COLUMN dictionaries.products.id IS 'Код';


--
-- Name: COLUMN products.s_code; Type: COMMENT; Schema: dictionaries; Owner: -
--

COMMENT ON COLUMN dictionaries.products.s_code IS 'Символьный код ГП';


--
-- Name: COLUMN products.s_caption; Type: COMMENT; Schema: dictionaries; Owner: -
--

COMMENT ON COLUMN dictionaries.products.s_caption IS 'Наименование';


--
-- Name: COLUMN products.n_milling_time; Type: COMMENT; Schema: dictionaries; Owner: -
--

COMMENT ON COLUMN dictionaries.products.n_milling_time IS 'План. Секунд фрезерной обработки';


--
-- Name: COLUMN products.n_lathe_time; Type: COMMENT; Schema: dictionaries; Owner: -
--

COMMENT ON COLUMN dictionaries.products.n_lathe_time IS 'План. Секунд токарной обработки';


--
-- Name: products__get_row(public.t_id); Type: FUNCTION; Schema: dictionaries; Owner: -
--

CREATE FUNCTION dictionaries.products__get_row(idp_self public.t_id) RETURNS dictionaries.products
    LANGUAGE sql
    AS $$
/*<meta object="dictionaries.products__get_row"
        title="Функция get_row таблицы dictionaries.products"
        author="sys"
        created="25.02.2023"
        version="1.0"
        description="">
</meta>*/
  select t.* from dictionaries.products t where t.id = idp_self;
$$;


--
-- Name: products__insert_record(public.t_code); Type: FUNCTION; Schema: dictionaries; Owner: -
--

CREATE FUNCTION dictionaries.products__insert_record(sp_code public.t_code) RETURNS public.t_id
    LANGUAGE plpgsql
    AS $$
/*<meta object="dictionaries.products__insert_record"
        title="Функция insert_record таблицы dictionaries.products"
        author="sys"
        created="25.02.2023"
        version="1.0"
        description="">
</meta>*/
declare
 rv_row dictionaries.products%rowtype;
begin
 rv_row.id := uni_api.get_table_id('dictionaries','products');
 rv_row.s_code := sp_code;

 insert into dictionaries.products(id, s_code)
 values(rv_row.id, rv_row.s_code);

 return rv_row.id;

end; $$;


--
-- Name: products__lock_record(public.t_id); Type: FUNCTION; Schema: dictionaries; Owner: -
--

CREATE FUNCTION dictionaries.products__lock_record(idp_self public.t_id) RETURNS void
    LANGUAGE plpgsql
    AS $$
/*<meta object="dictionaries.products__lock_record"
        title="Функция lock_record таблицы dictionaries.products"
        author="sys"
        created="25.02.2023"
        version="1.0"
        description="">
</meta>*/
declare
 bv_is_ok t_boolean;
 sv_component_name t_name = 'UNI';
 sv_error_name t_name = 'ENoLockedRow';
begin
 select true into bv_is_ok from dictionaries.products where id = idp_self for update nowait;
 exception when lock_not_available then
   perform uni_error.generate(sv_component_name, sv_error_name, idp_self::t_shortstring);
end; $$;


--
-- Name: products__set_caption(public.t_id, public.t_caption, public.t_boolean); Type: FUNCTION; Schema: dictionaries; Owner: -
--

CREATE FUNCTION dictionaries.products__set_caption(idp_self public.t_id, p_value public.t_caption, bp_internal_call public.t_boolean DEFAULT false) RETURNS void
    LANGUAGE plpgsql
    AS $$
/*<meta object="dictionaries.products__set_caption"
        title="Функция setter для колонки "s_caption" таблицы dictionaries.products"
        author="sys"
        created="25.02.2023"
        version="1.0"
        description="">
</meta>*/
declare
  sv_schema_name t_name = 'dictionaries';
  sv_table_name t_name = 'products';
  sv_column_name t_name = 's_caption';
  sv_identity_field t_name = 'id';
begin
 perform uni_api.set_table_field_value(sv_schema_name, sv_table_name, sv_column_name,idp_self, p_value, sv_identity_field);
end; $$;


--
-- Name: products__set_code(public.t_id, public.t_code, public.t_boolean); Type: FUNCTION; Schema: dictionaries; Owner: -
--

CREATE FUNCTION dictionaries.products__set_code(idp_self public.t_id, p_value public.t_code, bp_internal_call public.t_boolean DEFAULT false) RETURNS void
    LANGUAGE plpgsql
    AS $$
/*<meta object="dictionaries.products__set_code"
        title="Функция setter для колонки "s_code" таблицы dictionaries.products"
        author="sys"
        created="25.02.2023"
        version="1.0"
        description="">
</meta>*/
declare
  sv_schema_name t_name = 'dictionaries';
  sv_table_name t_name = 'products';
  sv_column_name t_name = 's_code';
  sv_identity_field t_name = 'id';
begin
 perform uni_api.set_table_field_value(sv_schema_name, sv_table_name, sv_column_name,idp_self, p_value, sv_identity_field);
end; $$;


--
-- Name: products__set_lathe_time(public.t_id, public.t_integer, public.t_boolean); Type: FUNCTION; Schema: dictionaries; Owner: -
--

CREATE FUNCTION dictionaries.products__set_lathe_time(idp_self public.t_id, p_value public.t_integer, bp_internal_call public.t_boolean DEFAULT false) RETURNS void
    LANGUAGE plpgsql
    AS $$
/*<meta object="dictionaries.products__set_lathe_time"
        title="Функция setter для колонки "n_lathe_time" таблицы dictionaries.products"
        author="sys"
        created="25.02.2023"
        version="1.0"
        description="">
</meta>*/
declare
  sv_schema_name t_name = 'dictionaries';
  sv_table_name t_name = 'products';
  sv_column_name t_name = 'n_lathe_time';
  sv_identity_field t_name = 'id';
begin
 perform uni_api.set_table_field_value(sv_schema_name, sv_table_name, sv_column_name,idp_self, p_value, sv_identity_field);
end; $$;


--
-- Name: products__set_milling_time(public.t_id, public.t_integer, public.t_boolean); Type: FUNCTION; Schema: dictionaries; Owner: -
--

CREATE FUNCTION dictionaries.products__set_milling_time(idp_self public.t_id, p_value public.t_integer, bp_internal_call public.t_boolean DEFAULT false) RETURNS void
    LANGUAGE plpgsql
    AS $$
/*<meta object="dictionaries.products__set_milling_time"
        title="Функция setter для колонки "n_milling_time" таблицы dictionaries.products"
        author="sys"
        created="25.02.2023"
        version="1.0"
        description="">
</meta>*/
declare
  sv_schema_name t_name = 'dictionaries';
  sv_table_name t_name = 'products';
  sv_column_name t_name = 'n_milling_time';
  sv_identity_field t_name = 'id';
begin
 perform uni_api.set_table_field_value(sv_schema_name, sv_table_name, sv_column_name,idp_self, p_value, sv_identity_field);
end; $$;


--
-- Name: products__validate(public.t_id); Type: FUNCTION; Schema: dictionaries; Owner: -
--

CREATE FUNCTION dictionaries.products__validate(idp_self public.t_id) RETURNS void
    LANGUAGE plpgsql
    AS $$
/*<meta object="dictionaries.products__validate"
        title="Функция validate таблицы dictionaries.products"
        author="sys"
        created="25.02.2023"
        version="1.0"
        description="">
</meta>*/
begin
 null;
end; $$;


--
-- Name: get_table_id(public.t_name, public.t_name); Type: FUNCTION; Schema: uni_api; Owner: -
--

CREATE FUNCTION uni_api.get_table_id(sp_schema public.t_name, sp_table public.t_name) RETURNS bigint
    LANGUAGE sql
    AS $$
  select nextval(format('%I.seq_%I', sp_schema, sp_table));
$$;


--
-- Name: set_table_field_value(public.t_name, public.t_name, public.t_name, public.t_id, public.t_boolean, public.t_name); Type: FUNCTION; Schema: uni_api; Owner: -
--

CREATE FUNCTION uni_api.set_table_field_value(sp_schema public.t_name, sp_table public.t_name, sp_field public.t_name, idp_self public.t_id, p_value public.t_boolean, sp_identityfield public.t_name) RETURNS void
    LANGUAGE plpgsql
    AS $_$
declare
  sv_query text := format('update %I.%I set %I = $1 where %I = $2', sp_schema, sp_table, sp_field, sp_identityfield);
begin
  execute sv_query using p_value, idp_self;
exception
  when others then
    perform uni_error.generate('UNI','EError','Ошибка при обновлении таблицы '||sp_schema||'.'||sp_table||'с ключом "'||idp_self||'"'||Chr(10)||sqlerrm);
end;$_$;


--
-- Name: set_table_field_value(public.t_name, public.t_name, public.t_name, public.t_id, public.t_caption, public.t_name); Type: FUNCTION; Schema: uni_api; Owner: -
--

CREATE FUNCTION uni_api.set_table_field_value(sp_schema public.t_name, sp_table public.t_name, sp_field public.t_name, idp_self public.t_id, p_value public.t_caption, sp_identityfield public.t_name) RETURNS void
    LANGUAGE plpgsql
    AS $_$
declare
  sv_query text := format('update %I.%I set %I = $1 where %I = $2', sp_schema, sp_table, sp_field, sp_identityfield);
begin
  execute sv_query using p_value, idp_self;
exception
  when others then
    perform uni_error.generate('UNI','EError','Ошибка при обновлении таблицы '||sp_schema||'.'||sp_table||'с ключом "'||idp_self||'"'||Chr(10)||sqlerrm);
end;$_$;


--
-- Name: set_table_field_value(public.t_name, public.t_name, public.t_name, public.t_id, public.t_clob, public.t_name); Type: FUNCTION; Schema: uni_api; Owner: -
--

CREATE FUNCTION uni_api.set_table_field_value(sp_schema public.t_name, sp_table public.t_name, sp_field public.t_name, idp_self public.t_id, p_value public.t_clob, sp_identityfield public.t_name) RETURNS void
    LANGUAGE plpgsql
    AS $_$
declare
  sv_query text := format('update %I.%I set %I = $1 where %I = $2', sp_schema, sp_table, sp_field, sp_identityfield);
begin
  execute sv_query using p_value, idp_self;
exception
  when others then
    perform uni_error.generate('UNI','EError','Ошибка при обновлении таблицы '||sp_schema||'.'||sp_table||'с ключом "'||idp_self||'"'||Chr(10)||sqlerrm);
end;$_$;


--
-- Name: set_table_field_value(public.t_name, public.t_name, public.t_name, public.t_id, public.t_code, public.t_name); Type: FUNCTION; Schema: uni_api; Owner: -
--

CREATE FUNCTION uni_api.set_table_field_value(sp_schema public.t_name, sp_table public.t_name, sp_field public.t_name, idp_self public.t_id, p_value public.t_code, sp_identityfield public.t_name) RETURNS void
    LANGUAGE plpgsql
    AS $_$
declare
  sv_query text := format('update %I.%I set %I = $1 where %I = $2', sp_schema, sp_table, sp_field, sp_identityfield);
begin
  execute sv_query using p_value, idp_self;
exception
  when others then
    perform uni_error.generate('UNI','EError','Ошибка при обновлении таблицы '||sp_schema||'.'||sp_table||'с ключом "'||idp_self||'"'||Chr(10)||sqlerrm);
end;$_$;


--
-- Name: set_table_field_value(public.t_name, public.t_name, public.t_name, public.t_id, public.t_date, public.t_name); Type: FUNCTION; Schema: uni_api; Owner: -
--

CREATE FUNCTION uni_api.set_table_field_value(sp_schema public.t_name, sp_table public.t_name, sp_field public.t_name, idp_self public.t_id, p_value public.t_date, sp_identityfield public.t_name) RETURNS void
    LANGUAGE plpgsql
    AS $_$
declare
  sv_query text := format('update %I.%I set %I = $1 where %I = $2', sp_schema, sp_table, sp_field, sp_identityfield);
begin
  execute sv_query using p_value, idp_self;
exception
  when others then
    perform uni_error.generate('UNI','EError','Ошибка при обновлении таблицы '||sp_schema||'.'||sp_table||'с ключом "'||idp_self||'"'||Chr(10)||sqlerrm);
end;$_$;


--
-- Name: set_table_field_value(public.t_name, public.t_name, public.t_name, public.t_id, public.t_datetime, public.t_name); Type: FUNCTION; Schema: uni_api; Owner: -
--

CREATE FUNCTION uni_api.set_table_field_value(sp_schema public.t_name, sp_table public.t_name, sp_field public.t_name, idp_self public.t_id, p_value public.t_datetime, sp_identityfield public.t_name) RETURNS void
    LANGUAGE plpgsql
    AS $_$
declare
  sv_query text := format('update %I.%I set %I = $1 where %I = $2', sp_schema, sp_table, sp_field, sp_identityfield);
begin
  execute sv_query using p_value, idp_self;
exception
  when others then
    perform uni_error.generate('UNI','EError','Ошибка при обновлении таблицы '||sp_schema||'.'||sp_table||'с ключом "'||idp_self||'"'||Chr(10)||sqlerrm);
end;$_$;


--
-- Name: set_table_field_value(public.t_name, public.t_name, public.t_name, public.t_id, public.t_description, public.t_name); Type: FUNCTION; Schema: uni_api; Owner: -
--

CREATE FUNCTION uni_api.set_table_field_value(sp_schema public.t_name, sp_table public.t_name, sp_field public.t_name, idp_self public.t_id, p_value public.t_description, sp_identityfield public.t_name) RETURNS void
    LANGUAGE plpgsql
    AS $_$
declare
  sv_query text := format('update %I.%I set %I = $1 where %I = $2', sp_schema, sp_table, sp_field, sp_identityfield);
begin
  execute sv_query using p_value, idp_self;
exception
  when others then
    perform uni_error.generate('UNI','EError','Ошибка при обновлении таблицы '||sp_schema||'.'||sp_table||'с ключом "'||idp_self||'"'||Chr(10)||sqlerrm);
end;$_$;


--
-- Name: set_table_field_value(public.t_name, public.t_name, public.t_name, public.t_id, public.t_float, public.t_name); Type: FUNCTION; Schema: uni_api; Owner: -
--

CREATE FUNCTION uni_api.set_table_field_value(sp_schema public.t_name, sp_table public.t_name, sp_field public.t_name, idp_self public.t_id, p_value public.t_float, sp_identityfield public.t_name) RETURNS void
    LANGUAGE plpgsql
    AS $_$
declare
  sv_query text := format('update %I.%I set %I = $1 where %I = $2', sp_schema, sp_table, sp_field, sp_identityfield);
begin
  execute sv_query using p_value, idp_self;
exception
  when others then
    perform uni_error.generate('UNI','EError','Ошибка при обновлении таблицы '||sp_schema||'.'||sp_table||'с ключом "'||idp_self||'"'||Chr(10)||sqlerrm);
end;$_$;


--
-- Name: set_table_field_value(public.t_name, public.t_name, public.t_name, public.t_id, public.t_html, public.t_name); Type: FUNCTION; Schema: uni_api; Owner: -
--

CREATE FUNCTION uni_api.set_table_field_value(sp_schema public.t_name, sp_table public.t_name, sp_field public.t_name, idp_self public.t_id, p_value public.t_html, sp_identityfield public.t_name) RETURNS void
    LANGUAGE plpgsql
    AS $_$
declare
  sv_query text := format('update %I.%I set %I = $1 where %I = $2', sp_schema, sp_table, sp_field, sp_identityfield);
begin
  execute sv_query using p_value, idp_self;
exception
  when others then
    perform uni_error.generate('UNI','EError','Ошибка при обновлении таблицы '||sp_schema||'.'||sp_table||'с ключом "'||idp_self||'"'||Chr(10)||sqlerrm);
end;$_$;


--
-- Name: set_table_field_value(public.t_name, public.t_name, public.t_name, public.t_id, public.t_id, public.t_name); Type: FUNCTION; Schema: uni_api; Owner: -
--

CREATE FUNCTION uni_api.set_table_field_value(sp_schema public.t_name, sp_table public.t_name, sp_field public.t_name, idp_self public.t_id, p_value public.t_id, sp_identityfield public.t_name) RETURNS void
    LANGUAGE plpgsql
    AS $_$
declare
  sv_query text := format('update %I.%I set %I = $1 where %I = $2', sp_schema, sp_table, sp_field, sp_identityfield);
begin
  execute sv_query using p_value, idp_self;
exception
  when others then
    perform uni_error.generate('UNI','EError','Ошибка при обновлении таблицы '||sp_schema||'.'||sp_table||'с ключом "'||idp_self||'"'||Chr(10)||sqlerrm);
end;
$_$;


--
-- Name: set_table_field_value(public.t_name, public.t_name, public.t_name, public.t_id, public.t_integer, public.t_name); Type: FUNCTION; Schema: uni_api; Owner: -
--

CREATE FUNCTION uni_api.set_table_field_value(sp_schema public.t_name, sp_table public.t_name, sp_field public.t_name, idp_self public.t_id, p_value public.t_integer, sp_identityfield public.t_name) RETURNS void
    LANGUAGE plpgsql
    AS $_$
declare
  sv_query text := format('update %I.%I set %I = $1 where %I = $2', sp_schema, sp_table, sp_field, sp_identityfield);
begin
  execute sv_query using p_value, idp_self;
exception
  when others then
    perform uni_error.generate('UNI','EError','Ошибка при обновлении таблицы '||sp_schema||'.'||sp_table||'с ключом "'||idp_self||'"'||Chr(10)||sqlerrm);
end;$_$;


--
-- Name: set_table_field_value(public.t_name, public.t_name, public.t_name, public.t_id, public.t_json, public.t_name); Type: FUNCTION; Schema: uni_api; Owner: -
--

CREATE FUNCTION uni_api.set_table_field_value(sp_schema public.t_name, sp_table public.t_name, sp_field public.t_name, idp_self public.t_id, p_value public.t_json, sp_identityfield public.t_name) RETURNS void
    LANGUAGE plpgsql
    AS $_$
declare
  sv_query text := format('update %I.%I set %I = $1 where %I = $2', sp_schema, sp_table, sp_field, sp_identityfield);
begin
  execute sv_query using p_value, idp_self;
exception
  when others then
    perform uni_error.generate('UNI','EError','Ошибка при обновлении таблицы '||sp_schema||'.'||sp_table||'с ключом "'||idp_self||'"'||Chr(10)||sqlerrm);
end;$_$;


--
-- Name: set_table_field_value(public.t_name, public.t_name, public.t_name, public.t_id, public.t_longstring, public.t_name); Type: FUNCTION; Schema: uni_api; Owner: -
--

CREATE FUNCTION uni_api.set_table_field_value(sp_schema public.t_name, sp_table public.t_name, sp_field public.t_name, idp_self public.t_id, p_value public.t_longstring, sp_identityfield public.t_name) RETURNS void
    LANGUAGE plpgsql
    AS $_$
declare
  sv_query text := format('update %I.%I set %I = $1 where %I = $2', sp_schema, sp_table, sp_field, sp_identityfield);
begin
  execute sv_query using p_value, idp_self;
exception
  when others then
    perform uni_error.generate('UNI','EError','Ошибка при обновлении таблицы '||sp_schema||'.'||sp_table||'с ключом "'||idp_self||'"'||Chr(10)||sqlerrm);
end;$_$;


--
-- Name: set_table_field_value(public.t_name, public.t_name, public.t_name, public.t_id, public.t_money, public.t_name); Type: FUNCTION; Schema: uni_api; Owner: -
--

CREATE FUNCTION uni_api.set_table_field_value(sp_schema public.t_name, sp_table public.t_name, sp_field public.t_name, idp_self public.t_id, p_value public.t_money, sp_identityfield public.t_name) RETURNS void
    LANGUAGE plpgsql
    AS $_$
declare
  sv_query text := format('update %I.%I set %I = $1 where %I = $2', sp_schema, sp_table, sp_field, sp_identityfield);
begin
  execute sv_query using p_value, idp_self;
exception
  when others then
    perform uni_error.generate('UNI','EError','Ошибка при обновлении таблицы '||sp_schema||'.'||sp_table||'с ключом "'||idp_self||'"'||Chr(10)||sqlerrm);
end;$_$;


--
-- Name: set_table_field_value(public.t_name, public.t_name, public.t_name, public.t_id, public.t_name, public.t_name); Type: FUNCTION; Schema: uni_api; Owner: -
--

CREATE FUNCTION uni_api.set_table_field_value(sp_schema public.t_name, sp_table public.t_name, sp_field public.t_name, idp_self public.t_id, p_value public.t_name, sp_identityfield public.t_name) RETURNS void
    LANGUAGE plpgsql
    AS $_$
declare
  sv_query text := format('update %I.%I set %I = $1 where %I = $2', sp_schema, sp_table, sp_field, sp_identityfield);
begin
  execute sv_query using p_value, idp_self;
exception
  when others then
    perform uni_error.generate('UNI','EError','Ошибка при обновлении таблицы '||sp_schema||'.'||sp_table||'с ключом "'||idp_self||'"'||Chr(10)||sqlerrm);
end;$_$;


--
-- Name: set_table_field_value(public.t_name, public.t_name, public.t_name, public.t_id, public.t_shortstring, public.t_name); Type: FUNCTION; Schema: uni_api; Owner: -
--

CREATE FUNCTION uni_api.set_table_field_value(sp_schema public.t_name, sp_table public.t_name, sp_field public.t_name, idp_self public.t_id, p_value public.t_shortstring, sp_identityfield public.t_name) RETURNS void
    LANGUAGE plpgsql
    AS $_$
declare
  sv_query text := format('update %I.%I set %I = $1 where %I = $2', sp_schema, sp_table, sp_field, sp_identityfield);
begin
  execute sv_query using p_value, idp_self;
exception
  when others then
    perform uni_error.generate('UNI','EError','Ошибка при обновлении таблицы '||sp_schema||'.'||sp_table||'с ключом "'||idp_self||'"'||Chr(10)||sqlerrm);
end;$_$;


--
-- Name: set_table_field_value(public.t_name, public.t_name, public.t_name, public.t_id, public.t_xml, public.t_name); Type: FUNCTION; Schema: uni_api; Owner: -
--

CREATE FUNCTION uni_api.set_table_field_value(sp_schema public.t_name, sp_table public.t_name, sp_field public.t_name, idp_self public.t_id, p_value public.t_xml, sp_identityfield public.t_name) RETURNS void
    LANGUAGE plpgsql
    AS $_$
declare
  sv_query text := format('update %I.%I set %I = $1 where %I = $2', sp_schema, sp_table, sp_field, sp_identityfield);
begin
  execute sv_query using p_value, idp_self;
exception
  when others then
    perform uni_error.generate('UNI','EError','Ошибка при обновлении таблицы '||sp_schema||'.'||sp_table||'с ключом "'||idp_self||'"'||Chr(10)||sqlerrm);
end;$_$;


--
-- Name: component__after_edit(public.t_id); Type: FUNCTION; Schema: uni_component; Owner: -
--

CREATE FUNCTION uni_component.component__after_edit(idp_self public.t_id) RETURNS void
    LANGUAGE plpgsql
    AS $$
begin
  perform uni_component.component__validate(idp_self);
end; $$;


--
-- Name: component__delete_record(public.t_id); Type: FUNCTION; Schema: uni_component; Owner: -
--

CREATE FUNCTION uni_component.component__delete_record(idp_self public.t_id) RETURNS void
    LANGUAGE plpgsql
    AS $$
begin
 delete from uni_component.component where id = idp_self;
end; $$;


--
-- Name: component__find_by_name(public.t_name); Type: FUNCTION; Schema: uni_component; Owner: -
--

CREATE FUNCTION uni_component.component__find_by_name(sp_name public.t_name) RETURNS public.t_id
    LANGUAGE plpgsql
    AS $$
declare
  nv_count t_integer := 0;
  idv_self t_id;
begin
  select count(*) into nv_count from uni_component.component t where t.s_name = sp_name;
  if nv_count > 1 then
    return 0;
  end if;
  select t.id into idv_self from uni_component.component t where t.s_name = sp_name;
  return idv_self;
end;
$$;


--
-- Name: component; Type: TABLE; Schema: uni_component; Owner: -
--

CREATE TABLE uni_component.component (
    id public.t_id NOT NULL,
    s_name public.t_name NOT NULL,
    s_caption public.t_caption,
    s_description public.t_description,
    id_parent public.t_id
);


--
-- Name: TABLE component; Type: COMMENT; Schema: uni_component; Owner: -
--

COMMENT ON TABLE uni_component.component IS 'Компоненты';


--
-- Name: COLUMN component.id; Type: COMMENT; Schema: uni_component; Owner: -
--

COMMENT ON COLUMN uni_component.component.id IS 'Код';


--
-- Name: COLUMN component.s_name; Type: COMMENT; Schema: uni_component; Owner: -
--

COMMENT ON COLUMN uni_component.component.s_name IS 'Системное имя';


--
-- Name: COLUMN component.s_caption; Type: COMMENT; Schema: uni_component; Owner: -
--

COMMENT ON COLUMN uni_component.component.s_caption IS 'Наименование';


--
-- Name: COLUMN component.s_description; Type: COMMENT; Schema: uni_component; Owner: -
--

COMMENT ON COLUMN uni_component.component.s_description IS 'Описание';


--
-- Name: COLUMN component.id_parent; Type: COMMENT; Schema: uni_component; Owner: -
--

COMMENT ON COLUMN uni_component.component.id_parent IS 'Код родительского компонента';


--
-- Name: component__get_row(public.t_id); Type: FUNCTION; Schema: uni_component; Owner: -
--

CREATE FUNCTION uni_component.component__get_row(idp_self public.t_id) RETURNS uni_component.component
    LANGUAGE sql
    AS $$
  select t.* from uni_component.component t where t.id = idp_self;
$$;


--
-- Name: component__insert_record(public.t_name); Type: FUNCTION; Schema: uni_component; Owner: -
--

CREATE FUNCTION uni_component.component__insert_record(sp_name public.t_name) RETURNS public.t_id
    LANGUAGE plpgsql
    AS $$
declare
 rv_row uni_component.component%rowtype;
begin
 rv_row.id := uni_api.get_table_id('uni_component','component');
 rv_row.s_name := sp_name;

 insert into uni_component.component(id, s_name)
 values(rv_row.id, rv_row.s_name);

 return rv_row.id;

end; $$;


--
-- Name: component__lock_record(public.t_id); Type: FUNCTION; Schema: uni_component; Owner: -
--

CREATE FUNCTION uni_component.component__lock_record(idp_self public.t_id) RETURNS void
    LANGUAGE plpgsql
    AS $$
declare
 bv_is_ok t_boolean;
 sv_component_name t_name = 'UNI';
 sv_error_name t_name = 'ENoLockedRow';
begin
 select true into bv_is_ok from uni_component.component where id = idp_self for update nowait;
 exception when lock_not_available then
   perform uni_error.generate(sv_component_name, sv_error_name, idp_self::t_shortstring);
end; $$;


--
-- Name: component__set_caption(public.t_id, public.t_caption); Type: FUNCTION; Schema: uni_component; Owner: -
--

CREATE FUNCTION uni_component.component__set_caption(idp_self public.t_id, p_value public.t_caption) RETURNS void
    LANGUAGE plpgsql
    AS $$
declare
  sv_schema_name t_name = 'uni_component';
  sv_table_name t_name = 'component';
  sv_column_name t_name = 's_caption';
  sv_identity_field t_name = 'id';
begin
 perform uni_api.set_table_field_value(sv_schema_name, sv_table_name, sv_column_name,idp_self, p_value, sv_identity_field);
end; $$;


--
-- Name: component__set_description(public.t_id, public.t_description); Type: FUNCTION; Schema: uni_component; Owner: -
--

CREATE FUNCTION uni_component.component__set_description(idp_self public.t_id, p_value public.t_description) RETURNS void
    LANGUAGE plpgsql
    AS $$
declare
  sv_schema_name t_name = 'uni_component';
  sv_table_name t_name = 'component';
  sv_column_name t_name = 's_description';
  sv_identity_field t_name = 'id';
begin
 perform uni_api.set_table_field_value(sv_schema_name, sv_table_name, sv_column_name,idp_self, p_value, sv_identity_field);
end; $$;


--
-- Name: component__set_name(public.t_id, public.t_name); Type: FUNCTION; Schema: uni_component; Owner: -
--

CREATE FUNCTION uni_component.component__set_name(idp_self public.t_id, p_value public.t_name) RETURNS void
    LANGUAGE plpgsql
    AS $$
declare
  sv_schema_name t_name = 'uni_component';
  sv_table_name t_name = 'component';
  sv_column_name t_name = 's_name';
  sv_identity_field t_name = 'id';
begin
 perform uni_api.set_table_field_value(sv_schema_name, sv_table_name, sv_column_name,idp_self, p_value, sv_identity_field);
end; $$;


--
-- Name: component__set_parent(public.t_id, public.t_id); Type: FUNCTION; Schema: uni_component; Owner: -
--

CREATE FUNCTION uni_component.component__set_parent(idp_self public.t_id, p_value public.t_id) RETURNS void
    LANGUAGE plpgsql
    AS $$
declare
  sv_schema_name t_name = 'uni_component';
  sv_table_name t_name = 'component';
  sv_column_name t_name = 'id_parent';
  sv_identity_field t_name = 'id';
begin
 perform uni_api.set_table_field_value(sv_schema_name, sv_table_name, sv_column_name,idp_self, p_value, sv_identity_field);
end; $$;


--
-- Name: component__validate(public.t_id); Type: FUNCTION; Schema: uni_component; Owner: -
--

CREATE FUNCTION uni_component.component__validate(idp_self public.t_id) RETURNS void
    LANGUAGE plpgsql
    AS $$
begin
 null;
end; $$;


--
-- Name: endl(); Type: FUNCTION; Schema: uni_const; Owner: -
--

CREATE FUNCTION uni_const.endl() RETURNS character varying
    LANGUAGE sql IMMUTABLE LEAKPROOF
    AS $$
	select chr(10) as endl;
$$;


--
-- Name: max_date(); Type: FUNCTION; Schema: uni_const; Owner: -
--

CREATE FUNCTION uni_const.max_date() RETURNS public.t_date
    LANGUAGE sql IMMUTABLE LEAKPROOF
    AS $$
  select to_date('31.12.4096','dd.mm.yyyy')::t_date as d_date
$$;


--
-- Name: min_date(); Type: FUNCTION; Schema: uni_const; Owner: -
--

CREATE FUNCTION uni_const.min_date() RETURNS public.t_date
    LANGUAGE sql IMMUTABLE LEAKPROOF
    AS $$
  select to_date('01.01.0001','dd.mm.yyyy')::t_date as d_date
$$;


--
-- Name: reg_col_type(); Type: FUNCTION; Schema: uni_const; Owner: -
--

CREATE FUNCTION uni_const.reg_col_type() RETURNS character varying
    LANGUAGE sql IMMUTABLE LEAKPROOF
    AS $$
	select '^(\w{1,4})_(.+)' as regular;
$$;


--
-- Name: reg_replace(public.t_name); Type: FUNCTION; Schema: uni_const; Owner: -
--

CREATE FUNCTION uni_const.reg_replace(sp_prefix public.t_name) RETURNS character varying
    LANGUAGE sql IMMUTABLE LEAKPROOF
    AS $$
  select '\1'||Coalesce(sp_prefix,'p')||'_\2';
$$;


--
-- Name: error__after_edit(public.t_id); Type: FUNCTION; Schema: uni_error; Owner: -
--

CREATE FUNCTION uni_error.error__after_edit(idp_self public.t_id) RETURNS void
    LANGUAGE plpgsql
    AS $$
begin
  perform uni_error.error__validate(idp_self);
  update uni_error.error set d_edited = current_timestamp where id = idp_self;
end; $$;


--
-- Name: error__delete_record(public.t_id); Type: FUNCTION; Schema: uni_error; Owner: -
--

CREATE FUNCTION uni_error.error__delete_record(idp_self public.t_id) RETURNS void
    LANGUAGE plpgsql
    AS $$
begin
 delete from uni_error.error where id = idp_self;
end; $$;


--
-- Name: error__find_by_name(public.t_name); Type: FUNCTION; Schema: uni_error; Owner: -
--

CREATE FUNCTION uni_error.error__find_by_name(sp_name public.t_name) RETURNS public.t_id
    LANGUAGE plpgsql
    AS $$
declare
  nv_count t_integer := 0;
  idv_self t_id;
begin
  select count(*) into nv_count from uni_error.error t where t.s_name = sp_name;
  if nv_count > 1 then
    return 0;
  end if;
  select t.id into idv_self from uni_error.error t where t.s_name = sp_name;
  return idv_self;
end;
$$;


--
-- Name: error; Type: TABLE; Schema: uni_error; Owner: -
--

CREATE TABLE uni_error.error (
    id public.t_id NOT NULL,
    s_name public.t_name NOT NULL,
    s_caption public.t_caption,
    s_description public.t_description,
    d_created public.t_datetime DEFAULT CURRENT_TIMESTAMP NOT NULL,
    d_edited public.t_datetime DEFAULT CURRENT_TIMESTAMP NOT NULL,
    id_component public.t_id NOT NULL
);


--
-- Name: TABLE error; Type: COMMENT; Schema: uni_error; Owner: -
--

COMMENT ON TABLE uni_error.error IS 'Ошибки';


--
-- Name: COLUMN error.id; Type: COMMENT; Schema: uni_error; Owner: -
--

COMMENT ON COLUMN uni_error.error.id IS 'Код';


--
-- Name: COLUMN error.s_name; Type: COMMENT; Schema: uni_error; Owner: -
--

COMMENT ON COLUMN uni_error.error.s_name IS 'Системное имя';


--
-- Name: COLUMN error.s_caption; Type: COMMENT; Schema: uni_error; Owner: -
--

COMMENT ON COLUMN uni_error.error.s_caption IS 'Наименование';


--
-- Name: COLUMN error.s_description; Type: COMMENT; Schema: uni_error; Owner: -
--

COMMENT ON COLUMN uni_error.error.s_description IS 'Описание';


--
-- Name: COLUMN error.d_created; Type: COMMENT; Schema: uni_error; Owner: -
--

COMMENT ON COLUMN uni_error.error.d_created IS 'Дата создания';


--
-- Name: COLUMN error.d_edited; Type: COMMENT; Schema: uni_error; Owner: -
--

COMMENT ON COLUMN uni_error.error.d_edited IS 'Дата последнего редактирования';


--
-- Name: COLUMN error.id_component; Type: COMMENT; Schema: uni_error; Owner: -
--

COMMENT ON COLUMN uni_error.error.id_component IS 'Код компонента';


--
-- Name: error__get_row(public.t_id); Type: FUNCTION; Schema: uni_error; Owner: -
--

CREATE FUNCTION uni_error.error__get_row(idp_self public.t_id) RETURNS uni_error.error
    LANGUAGE sql
    AS $$
  select t.* from uni_error.error t where t.id = idp_self;
$$;


--
-- Name: error__insert_record(public.t_name, public.t_id); Type: FUNCTION; Schema: uni_error; Owner: -
--

CREATE FUNCTION uni_error.error__insert_record(sp_name public.t_name, idp_component public.t_id) RETURNS public.t_id
    LANGUAGE plpgsql
    AS $$
declare
 rv_row uni_error.error%rowtype;
begin
 rv_row.id := uni_api.get_table_id('uni_error','error');
 rv_row.s_name := sp_name;
 rv_row.id_component := idp_component;
 rv_row.d_created := now()::t_datetime;
 rv_row.d_edited := now()::t_datetime;

 insert into uni_error.error(id, s_name, id_component, d_created, d_edited)
 values(rv_row.id, rv_row.s_name, rv_row.id_component, rv_row.d_created, rv_row.d_edited);

 return rv_row.id;

end; $$;


--
-- Name: error__lock_record(public.t_id); Type: FUNCTION; Schema: uni_error; Owner: -
--

CREATE FUNCTION uni_error.error__lock_record(idp_self public.t_id) RETURNS void
    LANGUAGE plpgsql
    AS $$
declare
 bv_is_ok t_boolean;
 sv_component_name t_name = 'UNI';
 sv_error_name t_name = 'ENoLockedRow';
begin
 select true into bv_is_ok from uni_error.error where id = idp_self for update nowait;
 exception when lock_not_available then
   perform uni_error.generate(sv_component_name, sv_error_name, idp_self::t_shortstring);
end; $$;


--
-- Name: error__set_caption(public.t_id, public.t_caption); Type: FUNCTION; Schema: uni_error; Owner: -
--

CREATE FUNCTION uni_error.error__set_caption(idp_self public.t_id, p_value public.t_caption) RETURNS void
    LANGUAGE plpgsql
    AS $$
declare
  sv_schema_name t_name = 'uni_error';
  sv_table_name t_name = 'error';
  sv_column_name t_name = 's_caption';
  sv_identity_field t_name = 'id';
begin
 perform uni_api.set_table_field_value(sv_schema_name, sv_table_name, sv_column_name,idp_self, p_value, sv_identity_field);
end; $$;


--
-- Name: error__set_component(public.t_id, public.t_id); Type: FUNCTION; Schema: uni_error; Owner: -
--

CREATE FUNCTION uni_error.error__set_component(idp_self public.t_id, p_value public.t_id) RETURNS void
    LANGUAGE plpgsql
    AS $$
declare
  sv_schema_name t_name = 'uni_error';
  sv_table_name t_name = 'error';
  sv_column_name t_name = 'id_component';
  sv_identity_field t_name = 'id';
begin
 perform uni_api.set_table_field_value(sv_schema_name, sv_table_name, sv_column_name,idp_self, p_value, sv_identity_field);
end; $$;


--
-- Name: error__set_created(public.t_id, public.t_datetime); Type: FUNCTION; Schema: uni_error; Owner: -
--

CREATE FUNCTION uni_error.error__set_created(idp_self public.t_id, p_value public.t_datetime) RETURNS void
    LANGUAGE plpgsql
    AS $$
declare
  sv_schema_name t_name = 'uni_error';
  sv_table_name t_name = 'error';
  sv_column_name t_name = 'd_created';
  sv_identity_field t_name = 'id';
begin
 perform uni_api.set_table_field_value(sv_schema_name, sv_table_name, sv_column_name,idp_self, p_value, sv_identity_field);
end; $$;


--
-- Name: error__set_description(public.t_id, public.t_description); Type: FUNCTION; Schema: uni_error; Owner: -
--

CREATE FUNCTION uni_error.error__set_description(idp_self public.t_id, p_value public.t_description) RETURNS void
    LANGUAGE plpgsql
    AS $$
declare
  sv_schema_name t_name = 'uni_error';
  sv_table_name t_name = 'error';
  sv_column_name t_name = 's_description';
  sv_identity_field t_name = 'id';
begin
 perform uni_api.set_table_field_value(sv_schema_name, sv_table_name, sv_column_name,idp_self, p_value, sv_identity_field);
end; $$;


--
-- Name: error__set_edited(public.t_id, public.t_datetime); Type: FUNCTION; Schema: uni_error; Owner: -
--

CREATE FUNCTION uni_error.error__set_edited(idp_self public.t_id, p_value public.t_datetime) RETURNS void
    LANGUAGE plpgsql
    AS $$
declare
  sv_schema_name t_name = 'uni_error';
  sv_table_name t_name = 'error';
  sv_column_name t_name = 'd_edited';
  sv_identity_field t_name = 'id';
begin
 perform uni_api.set_table_field_value(sv_schema_name, sv_table_name, sv_column_name,idp_self, p_value, sv_identity_field);
end; $$;


--
-- Name: error__set_name(public.t_id, public.t_name); Type: FUNCTION; Schema: uni_error; Owner: -
--

CREATE FUNCTION uni_error.error__set_name(idp_self public.t_id, p_value public.t_name) RETURNS void
    LANGUAGE plpgsql
    AS $$
declare
  sv_schema_name t_name = 'uni_error';
  sv_table_name t_name = 'error';
  sv_column_name t_name = 's_name';
  sv_identity_field t_name = 'id';
begin
 perform uni_api.set_table_field_value(sv_schema_name, sv_table_name, sv_column_name,idp_self, p_value, sv_identity_field);
end; $$;


--
-- Name: error__validate(public.t_id); Type: FUNCTION; Schema: uni_error; Owner: -
--

CREATE FUNCTION uni_error.error__validate(idp_self public.t_id) RETURNS void
    LANGUAGE plpgsql
    AS $$
begin
 null;
end; $$;


--
-- Name: generate(public.t_name, public.t_name, public.t_shortstring[]); Type: FUNCTION; Schema: uni_error; Owner: -
--

CREATE FUNCTION uni_error.generate(sp_component public.t_name, sp_name public.t_name, VARIADIC params public.t_shortstring[]) RETURNS void
    LANGUAGE plpgsql
    AS $$
declare
  sv_error text;
  sv_stack text;
  param text;
begin
  -- Собираем данные из компонент таблицы с применением шаблонов ошибки
  begin
    select error.s_error_dc
    into sv_error
    from uni_error.component_errors error
    where Upper(error.s_component_mc) = Upper(sp_component)
      and Upper(error.s_error_mc) = Upper(sp_name);
  end;
  -- Если мы такого не нашли, то использовать первый параметр, как сообщение об ошибке
  if sv_error is null then
    sv_error := '%1';
  end if;
  -- Формируем по шаблону 
  declare
    nv_count t_integer := 1;
  begin
    foreach param in array params
    loop
      sv_error := Replace(sv_error, '%'||nv_count, param);
      nv_count := nv_count + 1;
    end loop;
  end;
  raise exception using message = sv_error;
end;$$;


--
-- Name: generate_after_edit(public.t_name, public.t_name); Type: FUNCTION; Schema: uni_generator; Owner: -
--

CREATE FUNCTION uni_generator.generate_after_edit(sp_schemaname public.t_name, sp_tablename public.t_name) RETURNS text
    LANGUAGE plpgsql
    AS $_$
declare
  sv_text text := '';
  sv_schemaname t_name := lower(sp_schemaname);
  sv_tablename t_name := lower(sp_tablename);
begin
  -- шапка функции
  sv_text := sv_text||format('create or replace function %I.%I__after_edit', sv_schemaname, sv_tablename);
  sv_text := sv_text||format('(idp_self %I.%I.id%%type)',sv_schemaname, sv_tablename)||uni_const.endl();
  -- Определение возвращаемого значения и языка функции
  begin
    sv_text := sv_text||'returns void'||uni_const.endl();
    sv_text := sv_text||'language plpgsql as $$'||uni_const.endl();
    sv_text := sv_text||format('/*<meta object="%I.%I__after_edit"',sv_schemaname, sv_tablename)||uni_const.endl();
    sv_text := sv_text||format('        title="Функция after_edit таблицы %I.%I"',sv_schemaname, sv_tablename)||uni_const.endl();
    sv_text := sv_text||format('        author="%I"',user)||uni_const.endl();
    sv_text := sv_text||format('        created=%I',to_char(now(),'dd.mm.yyyy'))||uni_const.endl();
    sv_text := sv_text||'        version="1.0"'||uni_const.endl();
    sv_text := sv_text||'        description="">'||uni_const.endl();
    sv_text := sv_text||'</meta>*/'||uni_const.endl();
  end;
  --begin
  declare
    sv_cred_time text;
  begin
    sv_text := sv_text||'begin'||uni_const.endl();
    sv_text := sv_text||format('  perform %I.%I__validate(idp_self);', sv_schemaname, sv_tablename)||uni_const.endl();
    begin
      select string_agg(db_tab_col.column_name||' = current_timestamp',',')
      into sv_cred_time
      from information_schema.columns db_tab_col
      where lower(db_tab_col.table_schema) = sv_schemaname
        and lower(db_tab_col.table_name) = sv_tablename
        and lower(db_tab_col.column_name) in ('d_edited');
    end;
    if Coalesce(sv_cred_time, 'None') != 'None' then
      sv_text := sv_text||format('  update %I.%I set '||sv_cred_time||' where id = idp_self;', sv_schemaname, sv_tablename)||uni_const.endl();
    end if;
  end;
  --end
  begin
    sv_text := sv_text||'end; $$;'||uni_const.endl()||uni_const.endl();
  end;
  return sv_text;
end;$_$;


--
-- Name: generate_delete_record(public.t_name, public.t_name); Type: FUNCTION; Schema: uni_generator; Owner: -
--

CREATE FUNCTION uni_generator.generate_delete_record(sp_schemaname public.t_name, sp_tablename public.t_name) RETURNS text
    LANGUAGE plpgsql
    AS $_$
declare
  sv_text text := '';
  sv_schemaname t_name := lower(sp_schemaname);
  sv_tablename t_name := lower(sp_tablename);
begin
  -- шапка функции
  sv_text := sv_text||format('create or replace function %I.%I__delete_record',sv_schemaname,sv_tablename);
  sv_text := sv_text||format('(idp_self %I.%I.id%%type)',sv_schemaname,sv_tablename)||uni_const.endl();
  -- Определение возвращаемого значения и языка функции
  begin
    sv_text := sv_text||'returns void'||uni_const.endl();
    sv_text := sv_text||'language plpgsql as $$'||uni_const.endl();
    sv_text := sv_text||format('/*<meta object="%I.%I__delete_record"',sv_schemaname, sv_tablename)||uni_const.endl();
    sv_text := sv_text||format('        title="Функция delete_record таблицы %I.%I"',sv_schemaname, sv_tablename)||uni_const.endl();
    sv_text := sv_text||format('        author="%I"',user)||uni_const.endl();
    sv_text := sv_text||format('        created=%I',to_char(now(),'dd.mm.yyyy'))||uni_const.endl();
    sv_text := sv_text||'        version="1.0"'||uni_const.endl();
    sv_text := sv_text||'        description="">'||uni_const.endl();
    sv_text := sv_text||'</meta>*/'||uni_const.endl();
  end;
  --begin
  begin
    sv_text := sv_text||'begin'||uni_const.endl();
    sv_text := sv_text||format(' delete from %I.%I where id = idp_self;',sp_schemaname,sp_tablename)||uni_const.endl();
  end;
  --end
  begin
    sv_text := sv_text||'end; $$;'||uni_const.endl()||uni_const.endl();
  end;
  return sv_text;
end;$_$;


--
-- Name: generate_find_by_code(public.t_name, public.t_name); Type: FUNCTION; Schema: uni_generator; Owner: -
--

CREATE FUNCTION uni_generator.generate_find_by_code(sp_schemaname public.t_name, sp_tablename public.t_name) RETURNS text
    LANGUAGE plpgsql
    AS $_$
declare
  sv_text text := '';
  sv_tablename t_name := lower(sp_tablename);
  sv_schemaname t_name := lower(sp_schemaname);
begin
  --sv_text := sv_text||'drop function '||sp_schemaname||'.'||sp_tablename||'_FindByName;'||uni_const.endl();
  -- шапка функции
  sv_text := sv_text||format('create or replace function %I.%I__find_by_code',sv_schemaname,sv_tablename);
  sv_text := sv_text||format('(sp_code %I.%I.s_code%%type)',sv_schemaname,sv_tablename)||uni_const.endl();
  -- Определение возвращаемого значения и языка функции
  begin
    sv_text := sv_text||format('returns %I.%I.id%%type',sv_schemaname,sv_tablename)||uni_const.endl();
    sv_text := sv_text||'language plpgsql as $$'||uni_const.endl();
    sv_text := sv_text||format('/*<meta object="%I.%I__find_by_code"',sv_schemaname, sv_tablename)||uni_const.endl();
    sv_text := sv_text||format('        title="Функция find_by_code таблицы %I.%I"',sv_schemaname, sv_tablename)||uni_const.endl();
    sv_text := sv_text||format('        author="%I"',user)||uni_const.endl();
    sv_text := sv_text||format('        created=%I',to_char(now(),'dd.mm.yyyy'))||uni_const.endl();
    sv_text := sv_text||'        version="1.0"'||uni_const.endl();
    sv_text := sv_text||'        description="">'||uni_const.endl();
    sv_text := sv_text||'</meta>*/'||uni_const.endl();
  end;
  -- declare
  sv_text := sv_text||'declare'||uni_const.endl();
  sv_text := sv_text||'  nv_count t_integer := 0;'||uni_const.endl();
  sv_text := sv_text||'  idv_self t_id;'||uni_const.endl();
  -- begin
  sv_text := sv_text||'begin'||uni_const.endl();
  sv_text := sv_text||format('  select count(*) into nv_count from %I.%I t where t.s_code = sp_code;',sv_schemaname,sv_tablename)||uni_const.endl();
  sv_text := sv_text||'  if nv_count > 1 then'||uni_const.endl();
  sv_text := sv_text||'    return 0;'||uni_const.endl();
  sv_text := sv_text||'  end if;'||uni_const.endl();
  sv_text := sv_text||format('  select t.id into idv_self from %I.%I t where t.s_code = sp_code;',sv_schemaname,sv_tablename)||uni_const.endl();
  sv_text := sv_text||'  return idv_self;'||uni_const.endl();
  --end
  sv_text := sv_text||'end;'||uni_const.endl();
  begin
    sv_text := sv_text||'$$;'||uni_const.endl()||uni_const.endl();
  end;
  return sv_text;
end; 
$_$;


--
-- Name: generate_find_by_name(public.t_name, public.t_name); Type: FUNCTION; Schema: uni_generator; Owner: -
--

CREATE FUNCTION uni_generator.generate_find_by_name(sp_schemaname public.t_name, sp_tablename public.t_name) RETURNS text
    LANGUAGE plpgsql
    AS $_$
declare
  sv_text text := '';
  sv_schemaname t_name := lower(sp_schemaname);
  sv_tablename t_name := lower(sp_tablename);
begin
  --sv_text := sv_text||'drop function '||sp_schemaname||'.'||sp_tablename||'_FindByName;'||uni_const.endl();
  -- шапка функции
  sv_text := sv_text||format('create or replace function %I.%I__find_by_name',sv_schemaname,sv_tablename);
  sv_text := sv_text||format('(sp_name %I.%I.s_name%%type)',sv_schemaname,sv_tablename)||uni_const.endl();
  -- Определение возвращаемого значения и языка функции
  begin
    sv_text := sv_text||format('returns %I.%I.id%%type',sv_schemaname,sv_tablename)||uni_const.endl();
    sv_text := sv_text||'language plpgsql as $$'||uni_const.endl();
    sv_text := sv_text||format('/*<meta object="%I.%I__find_by_name"',sv_schemaname, sv_tablename)||uni_const.endl();
    sv_text := sv_text||format('        title="Функция find_by_name таблицы %I.%I"',sv_schemaname, sv_tablename)||uni_const.endl();
    sv_text := sv_text||format('        author="%I"',user)||uni_const.endl();
    sv_text := sv_text||format('        created=%I',to_char(now(),'dd.mm.yyyy'))||uni_const.endl();
    sv_text := sv_text||'        version="1.0"'||uni_const.endl();
    sv_text := sv_text||'        description="">'||uni_const.endl();
    sv_text := sv_text||'</meta>*/'||uni_const.endl();
  end;
  -- declare
  sv_text := sv_text||'declare'||uni_const.endl();
  sv_text := sv_text||'  nv_count t_integer := 0;'||uni_const.endl();
  sv_text := sv_text||'  idv_self t_id;'||uni_const.endl();
  -- begin
  sv_text := sv_text||'begin'||uni_const.endl();
  sv_text := sv_text||format('  select count(*) into nv_count from %I.%I t where t.s_name = sp_name;',sv_schemaname,sv_tablename)||uni_const.endl();
  sv_text := sv_text||'  if nv_count > 1 then'||uni_const.endl();
  sv_text := sv_text||'    return 0;'||uni_const.endl();
  sv_text := sv_text||'  end if;'||uni_const.endl();
  sv_text := sv_text||format('  select t.id into idv_self from %I.%I t where t.s_name = sp_name;',sv_schemaname,sv_tablename)||uni_const.endl();
  --end
  sv_text := sv_text||'  return idv_self;'||uni_const.endl();
  sv_text := sv_text||'end;'||uni_const.endl();
  begin
    sv_text := sv_text||'$$;'||uni_const.endl()||uni_const.endl();
  end;
  return sv_text;
end; 
$_$;


--
-- Name: generate_get_row(public.t_name, public.t_name); Type: FUNCTION; Schema: uni_generator; Owner: -
--

CREATE FUNCTION uni_generator.generate_get_row(sp_schemaname public.t_name, sp_tablename public.t_name) RETURNS text
    LANGUAGE plpgsql
    AS $_$
declare
  sv_text text := '';
  sv_schemaname t_name := lower(sp_schemaname);
  sv_tablename t_name := lower(sp_tablename);
begin
  -- шапка функции
  sv_text := sv_text||format('create or replace function %I.%I__get_row',sv_schemaname,sv_tablename);
  sv_text := sv_text||format('(idp_self %I.%I.id%%Type)',sv_schemaname,sv_tablename)||uni_const.endl();
  -- Определение возвращаемого значения и языка функции
  begin
    sv_text := sv_text||format('returns %I.%I',sv_schemaname,sv_tablename)||uni_const.endl();
    sv_text := sv_text||'language sql as $$'||uni_const.endl();
    sv_text := sv_text||format('/*<meta object="%I.%I__get_row"',sv_schemaname, sv_tablename)||uni_const.endl();
    sv_text := sv_text||format('        title="Функция get_row таблицы %I.%I"',sv_schemaname, sv_tablename)||uni_const.endl();
    sv_text := sv_text||format('        author="%I"',user)||uni_const.endl();
    sv_text := sv_text||format('        created=%I',to_char(now(),'dd.mm.yyyy'))||uni_const.endl();
    sv_text := sv_text||'        version="1.0"'||uni_const.endl();
    sv_text := sv_text||'        description="">'||uni_const.endl();
    sv_text := sv_text||'</meta>*/'||uni_const.endl();
  end;
  --declare
  begin
    sv_text := sv_text||format('  select t.* from %I.%I t where t.id = idp_self;',sv_schemaname,sv_tablename)||uni_const.endl();
  end;
  --end
  begin
    sv_text := sv_text||'$$;'||uni_const.endl()||uni_const.endl();
  end;
  return sv_text;
end; $_$;


--
-- Name: generate_grants(public.t_name, public.t_name, public.t_shortstring[]); Type: FUNCTION; Schema: uni_generator; Owner: -
--

CREATE FUNCTION uni_generator.generate_grants(sp_schemaname public.t_name, sp_tablename public.t_name, sap_roles public.t_shortstring[]) RETURNS text
    LANGUAGE plpgsql
    AS $$
declare
  sv_text text := '';
  sv_schemanname t_name := lower(sp_schemaname);
  sv_tablename t_name := lower(sp_tablename);
  curv_data record;
  grant_role t_shortstring;
begin
  for curv_data in
  (
    select NSP.nspname as s_schemaname
          ,Proc.proName as s_procname
          ,pg_catalog.pg_get_function_identity_arguments(Proc.oid) as s_procparams
    from pg_catalog.pg_namespace NSP
    inner join pg_catalog.pg_proc Proc on Proc.pronamespace = NSP.oid
    where lower(NSP.nspname) = sv_schemanname
      and lower(Proc.proname) like sv_tablename||'_%'
  )
  loop
    foreach grant_role in array sap_roles::character varying(255)[]
    loop
      sv_text := sv_text||format('grant execute on function %I.%I(%s) to %I;',curv_data.s_schemaname,curv_data.s_procname, curv_data.s_procparams, grant_role)||uni_const.endl();
    end loop;
  end loop;
  return sv_text;
end;$$;


--
-- Name: generate_insert_record(public.t_name, public.t_name); Type: FUNCTION; Schema: uni_generator; Owner: -
--

CREATE FUNCTION uni_generator.generate_insert_record(sp_schemaname public.t_name, sp_tablename public.t_name) RETURNS text
    LANGUAGE plpgsql
    AS $_$
declare
  sv_text text := '';
  sv_schemaname t_name := lower(sp_schemaname);
  sv_tablename t_name := lower(sp_tablename);
begin
  -- шапка функции
  sv_text := sv_text||format('create or replace function %I.%I__insert_record',sv_schemaname,sv_tablename);
  -- Необходимые параметры (not null)
  declare
    curv_column record;
  begin
    -- Открываем блок параметров
    sv_text := sv_text||uni_const.endl()||'('||uni_const.endl();
    for curv_column in
      select row_number() over() as rownum
            ,count(*) over() as all_count
            ,db_tab_col.*
      from information_schema.columns db_tab_col
      where lower(db_tab_col.table_schema) = sv_schemaname
        and lower(db_tab_col.table_name) = sv_tablename
        and lower(db_tab_col.column_name) not in('id','d_created','d_edited')
        and db_tab_col.column_default is null
        and db_tab_col.is_nullable = 'NO'
    loop
      sv_text := sv_text||' '||case when curv_column.rownum = 1 then ' '
                               else ',' end
                        ||regexp_replace(curv_column.column_name
                                        ,uni_const.reg_col_type()
                                        ,uni_const.reg_replace('p'))
                        ||' '
                        ||format('%I.%I.%I%%type',sp_schemaname,sp_tablename,curv_column.column_name)
                        ||case when curv_column.rownum = curv_column.all_count then ''
                          else uni_const.endl() end;
    end loop;
    -- закрываем блок параметров
    sv_text := sv_text||uni_const.endl()||')'||uni_const.endl();
  end;
  -- Определение возвращаемого значения и языка функции
  begin
    sv_text := sv_text||format(' returns %I.%I.id%%type',sv_schemaname,sv_tablename)||uni_const.endl();
    sv_text := sv_text||'language plpgsql as $$'||uni_const.endl();
    sv_text := sv_text||format('/*<meta object="%I.%I__insert_record"',sv_schemaname, sv_tablename)||uni_const.endl();
    sv_text := sv_text||format('        title="Функция insert_record таблицы %I.%I"',sv_schemaname, sv_tablename)||uni_const.endl();
    sv_text := sv_text||format('        author="%I"',user)||uni_const.endl();
    sv_text := sv_text||format('        created=%I',to_char(now(),'dd.mm.yyyy'))||uni_const.endl();
    sv_text := sv_text||'        version="1.0"'||uni_const.endl();
    sv_text := sv_text||'        description="">'||uni_const.endl();
    sv_text := sv_text||'</meta>*/'||uni_const.endl();
  end;
  --Тело функции
  --declare
  begin
    sv_text := sv_text||'declare'||uni_const.endl();
    sv_text := sv_text||format(' rv_row %I.%I%%rowtype;',sv_schemaname,sv_tablename)||uni_const.endl();
  end;
  --begin
  declare
    curv_column record;
  begin
    sv_text := sv_text||'begin'||uni_const.endl();
    -- Устанавливаем все системные поля и поля которые нужны для инсерта
    sv_text := sv_text||format(' rv_row.id := uni_api.get_table_id(''%I'',''%I'');',sv_schemaname,sv_tablename)||uni_const.endl();
    for curv_column in
      select row_number() over() as rownum
            ,count(*) over() as all_count
            ,db_tab_col.*
      from information_schema.columns db_tab_col
      where lower(db_tab_col.table_schema) = sv_schemaname
        and lower(db_tab_col.table_name) = sv_tablename
        and lower(db_tab_col.column_name) not in('id','d_created','d_edited')
        and db_tab_col.column_default is null
        and db_tab_col.is_nullable = 'NO'
    loop
      sv_text := sv_text||format(' rv_row.%I := %I;',curv_column.column_name,regexp_replace(curv_column.column_name
                                                                                          ,uni_const.reg_col_type()
                                                                                          ,uni_const.reg_replace('p')))
                        ||uni_const.endl();
    end loop;
    -- Добрасываем редактирование дат создани я редактирования
    for curv_column in
      select row_number() over() as rownum
            ,count(*) over() as all_count
            ,db_tab_col.*
      from information_schema.columns db_tab_col
      where lower(db_tab_col.table_schema) = sv_schemaname
        and lower(db_tab_col.table_name) = sv_tablename
        and lower(db_tab_col.column_name) in('d_created','d_edited')
    loop
      sv_text := sv_text||format(' rv_row.%I := now()::t_datetime;',curv_column.column_name)
                        ||uni_const.endl();
    end loop;
    -- Пишем вставку
    sv_text := sv_text||uni_const.endl();
    sv_text := sv_text||format(' insert into %I.%I(id',sv_schemaname,sv_tablename);
    for curv_column in
      select row_number() over() as rownum
            ,count(*) over() as all_count
            ,db_tab_col.*
      from information_schema.columns db_tab_col
      where lower(db_tab_col.table_schema) = sv_schemaname
        and lower(db_tab_col.table_name) = sv_tablename
        and lower(db_tab_col.column_name) not in('id','d_created','d_edited')
        and db_tab_col.column_default is null
        and db_tab_col.is_nullable = 'NO'
    loop
      sv_text := sv_text||', '||curv_column.column_name;
    end loop;
    for curv_column in
      select row_number() over() as rownum
            ,count(*) over() as all_count
            ,db_tab_col.*
      from information_schema.columns db_tab_col
      where lower(db_tab_col.table_schema) = sv_schemaname
        and lower(db_tab_col.table_name) = sv_tablename
        and lower(db_tab_col.column_name) in('d_created','d_edited')
    loop
      sv_text := sv_text||', '||curv_column.column_name;
    end loop;
    sv_text := sv_text||')'||uni_const.endl();
    sv_text := sv_text||' values(rv_row.id';
    for curv_column in
      select row_number() over() as rownum
            ,count(*) over() as all_count
            ,db_tab_col.*
      from information_schema.columns db_tab_col
      where lower(db_tab_col.table_schema) = sv_schemaname
        and lower(db_tab_col.table_name) = sv_tablename
        and lower(db_tab_col.column_name) not in('id','d_created','d_edited')
        and db_tab_col.column_default is null
        and db_tab_col.is_nullable = 'NO'
    loop
      sv_text := sv_text||', rv_row.'||curv_column.column_name;
    end loop;
    for curv_column in
      select row_number() over() as rownum
            ,count(*) over() as all_count
            ,db_tab_col.*
      from information_schema.columns db_tab_col
      where lower(db_tab_col.table_schema) = sv_schemaname
        and lower(db_tab_col.table_name) = sv_tablename
        and lower(db_tab_col.column_name) in('d_created','d_edited')
    loop
      sv_text := sv_text||', rv_row.'||curv_column.column_name;
    end loop;
    sv_text := sv_text||');'||uni_const.endl();
    sv_text := sv_text||uni_const.endl();
    sv_text := sv_text||' return rv_row.id;'||uni_const.endl();
    sv_text := sv_text||uni_const.endl();
  end;
  --end
  begin
    sv_text := sv_text||'end; $$;'||uni_const.endl()||uni_const.endl();
  end;
  -- Возвращаем значение заготовки
  return sv_text;
end;$_$;


--
-- Name: generate_lock_record(public.t_name, public.t_name); Type: FUNCTION; Schema: uni_generator; Owner: -
--

CREATE FUNCTION uni_generator.generate_lock_record(sp_schemaname public.t_name, sp_tablename public.t_name) RETURNS text
    LANGUAGE plpgsql
    AS $_$
declare
  sv_text text := '';
  sv_schemaname t_name := lower(sp_schemaname);
  sv_tablename t_name := lower(sp_tablename);
begin
  -- шапка функции
  sv_text := sv_text||format('create or replace function %I.%I__lock_record',sv_schemaname,sv_tablename);
  sv_text := sv_text||format('(idp_self %I.%I.id%%type)',sv_schemaname,sv_tablename)||uni_const.endl();
  -- Определение возвращаемого значения и языка функции
  begin
    sv_text := sv_text||'returns void'||uni_const.endl();
    sv_text := sv_text||'language plpgsql as $$'||uni_const.endl();
    sv_text := sv_text||format('/*<meta object="%I.%I__lock_record"',sv_schemaname, sv_tablename)||uni_const.endl();
    sv_text := sv_text||format('        title="Функция lock_record таблицы %I.%I"',sv_schemaname, sv_tablename)||uni_const.endl();
    sv_text := sv_text||format('        author="%I"',user)||uni_const.endl();
    sv_text := sv_text||format('        created=%I',to_char(now(),'dd.mm.yyyy'))||uni_const.endl();
    sv_text := sv_text||'        version="1.0"'||uni_const.endl();
    sv_text := sv_text||'        description="">'||uni_const.endl();
    sv_text := sv_text||'</meta>*/'||uni_const.endl();
  end;
  --declare
  begin
    sv_text := sv_text||'declare'||uni_const.endl();
    sv_text := sv_text||' bv_is_ok t_boolean;'||uni_const.endl();
    sv_text := sv_text||' sv_component_name t_name = ''UNI'';'||uni_const.endl();
    sv_text := sv_text||' sv_error_name t_name = ''ENoLockedRow'';'||uni_const.endl();
  end;
  --begin
  begin
    sv_text := sv_text||'begin'||uni_const.endl();
    sv_text := sv_text||format(' select true into bv_is_ok from %I.%I where id = idp_self for update nowait;',sv_schemaname,sv_tablename)||uni_const.endl();
    sv_text := sv_text||' exception when lock_not_available then'||uni_const.endl();
    sv_text := sv_text||'   perform uni_error.generate(sv_component_name, sv_error_name, idp_self::t_shortstring);'||uni_const.endl();
  end;
  --end
  begin
    sv_text := sv_text||'end; $$;'||uni_const.endl()||uni_const.endl();
  end;
  return sv_text;
end;$_$;


--
-- Name: generate_setters(public.t_name, public.t_name); Type: FUNCTION; Schema: uni_generator; Owner: -
--

CREATE FUNCTION uni_generator.generate_setters(sp_schemaname public.t_name, sp_tablename public.t_name) RETURNS text
    LANGUAGE plpgsql
    AS $_$
declare
  sv_text text := '';
  sv_schemaname t_name := lower(sp_schemaname);
  sv_tablename t_name := lower(sp_tablename);
  curv_column record;
begin
  for curv_column in
    select row_number() over() as rownum
          ,count(*) over() as all_count
          ,db_tab_col.*
    from information_schema.columns db_tab_col
    where lower(db_tab_col.table_schema) = sv_schemaname
      and lower(db_tab_col.table_name) = sv_tablename
      and lower(db_tab_col.column_name) not in('id')
  loop
    sv_text := sv_text||'create or replace function '||sv_schemaname||'.'||sv_tablename
                      ||'__set_'||lower(regexp_replace(curv_column.column_name
                                                      ,uni_const.reg_col_type()
                                                      ,'\2'));
    sv_text := sv_text||'(idp_self '||sp_schemaname||'.'||sp_tablename||'.id%type,'
                      ||' p_value '||sp_schemaname||'.'||sp_tablename||'.'||curv_column.column_name||'%type,'
                      ||' bp_internal_call t_boolean default false)'||uni_const.endl();
    -- Определение возвращаемого значения и языка функции
    begin
      sv_text := sv_text||'returns void'||uni_const.endl();
      sv_text := sv_text||'language plpgsql as $$'||uni_const.endl();
      sv_text := sv_text||format('/*<meta object="%I.%I__set_'||lower(regexp_replace(curv_column.column_name
                                                      ,uni_const.reg_col_type()
                                                      ,'\2'))||'"',sv_schemaname, sv_tablename)||uni_const.endl();
      sv_text := sv_text||format('        title="Функция setter для колонки "%I" таблицы %I.%I"',curv_column.column_name,sv_schemaname, sv_tablename)||uni_const.endl();
      sv_text := sv_text||format('        author="%I"',user)||uni_const.endl();
      sv_text := sv_text||format('        created=%I',to_char(now(),'dd.mm.yyyy'))||uni_const.endl();
      sv_text := sv_text||'        version="1.0"'||uni_const.endl();
      sv_text := sv_text||'        description="">'||uni_const.endl();
      sv_text := sv_text||'</meta>*/'||uni_const.endl();
    end;
    --declare
    begin
      sv_text := sv_text||'declare'||uni_const.endl();
      sv_text := sv_text||'  sv_schema_name t_name = '''||sv_schemaname||''';'||uni_const.endl();
      sv_text := sv_text||'  sv_table_name t_name = '''||sv_tablename||''';'||uni_const.endl();
      sv_text := sv_text||'  sv_column_name t_name = '''||curv_column.column_name||''';'||uni_const.endl();
      sv_text := sv_text||'  sv_identity_field t_name = ''id'';'||uni_const.endl();
    end;
    --begin
    begin
      sv_text := sv_text||'begin'||uni_const.endl();
      sv_text := sv_text||' perform uni_api.set_table_field_value(sv_schema_name, sv_table_name, sv_column_name';
      sv_text := sv_text||',idp_self, p_value, sv_identity_field);'||uni_const.endl();
    end;
    --end
    begin
      sv_text := sv_text||'end; $$;'||uni_const.endl()||uni_const.endl();
    end;
  end loop;
  return sv_text;
end;$_$;


--
-- Name: generate_table_api(public.t_name, public.t_name); Type: FUNCTION; Schema: uni_generator; Owner: -
--

CREATE FUNCTION uni_generator.generate_table_api(sp_schemaname public.t_name, sp_tablename public.t_name) RETURNS text
    LANGUAGE plpgsql
    AS $_$
declare
  sv_text text := '';
begin
  --Do
  sv_text := sv_text||'do'||uni_const.endl()||'$DO$'||uni_const.endl();
  sv_text := sv_text||'begin'||uni_const.endl();
  -- GetRow
  sv_text := sv_text||uni_generator.generate_get_row(sp_schemaname, sp_tablename);
  -- FindByName
  declare
    bv_exists_name t_boolean;
  begin
    begin
      select true
      into bv_exists_name
      from information_schema.columns db_tab_col
      where lower(db_tab_col.table_schema) = lower(sp_schemaname)
        and lower(db_tab_col.table_name) = lower(sp_tablename)
        and lower(db_tab_col.column_name) in ('s_name');
    end;
    if Coalesce(bv_exists_name, false) = true then
      sv_text := sv_text||uni_generator.generate_find_by_name(sp_schemaname, sp_tablename);
    end if;
  end;
  -- FindByCode
  declare
    bv_exists_code t_boolean;
  begin
    begin
      select true
      into bv_exists_code
      from information_schema.columns db_tab_col
      where lower(db_tab_col.table_schema) = lower(sp_schemaname)
        and lower(db_tab_col.table_name) = lower(sp_tablename)
        and lower(db_tab_col.column_name) in ('s_code');
    end;
    if Coalesce(bv_exists_code, false) = true then
      sv_text := sv_text||uni_generator.generate_find_by_code(sp_schemaname, sp_tablename);
    end if;
  end;
  -- LockRecord
  sv_text := sv_text||uni_generator.generate_lock_record(sp_schemaname, sp_tablename);
  -- InsertRecord
  sv_text := sv_text||uni_generator.generate_insert_record(sp_schemaname, sp_tablename); 
  -- DeleteRecord
  sv_text := sv_text||uni_generator.generate_delete_record(sp_schemaname, sp_tablename);
  -- Setters
  sv_text := sv_text||uni_generator.generate_setters(sp_schemaname, sp_tablename);
  -- Validate
  sv_text := sv_text||uni_generator.generate_validate(sp_schemaname, sp_tablename);
  -- AfterEdit
  sv_text := sv_text||uni_generator.generate_after_edit(sp_schemaname, sp_tablename);
  sv_text := sv_text||'end;'||uni_const.endl();
  sv_text := sv_text||'$DO$;';
  return sv_text;

end;$_$;


--
-- Name: generate_validate(public.t_name, public.t_name); Type: FUNCTION; Schema: uni_generator; Owner: -
--

CREATE FUNCTION uni_generator.generate_validate(sp_schemaname public.t_name, sp_tablename public.t_name) RETURNS text
    LANGUAGE plpgsql
    AS $_$
declare
  sv_text text := '';
  sv_schemaname t_name := lower(sp_schemaname);
  sv_tablename t_name := lower(sp_tablename);
begin
  -- шапка функции
  sv_text := sv_text||format('create or replace function %I.%I__validate',sv_schemaname,sv_tablename);
  sv_text := sv_text||format('(idp_self %I.%I.id%%type)',sv_schemaname,sv_tablename)||uni_const.endl();
  -- Определение возвращаемого значения и языка функции
  begin
    sv_text := sv_text||'returns void'||uni_const.endl();
    sv_text := sv_text||'language plpgsql as $$'||uni_const.endl();
    sv_text := sv_text||format('/*<meta object="%I.%I__validate"',sv_schemaname, sv_tablename)||uni_const.endl();
    sv_text := sv_text||format('        title="Функция validate таблицы %I.%I"',sv_schemaname, sv_tablename)||uni_const.endl();
    sv_text := sv_text||format('        author="%I"',user)||uni_const.endl();
    sv_text := sv_text||format('        created=%I',to_char(now(),'dd.mm.yyyy'))||uni_const.endl();
    sv_text := sv_text||'        version="1.0"'||uni_const.endl();
    sv_text := sv_text||'        description="">'||uni_const.endl();
    sv_text := sv_text||'</meta>*/'||uni_const.endl();
  end;
  --begin
  begin
    sv_text := sv_text||'begin'||uni_const.endl();
    sv_text := sv_text||' null;'||uni_const.endl();
  end;
  --end
  begin
    sv_text := sv_text||'end; $$;'||uni_const.endl()||uni_const.endl();
  end;
  return sv_text;
end;$_$;


--
-- Name: act_ge_bytearray; Type: TABLE; Schema: camunda; Owner: -
--

CREATE TABLE camunda.act_ge_bytearray (
    id_ character varying(64) NOT NULL,
    rev_ integer,
    name_ character varying(255),
    deployment_id_ character varying(64),
    bytes_ bytea,
    generated_ boolean,
    tenant_id_ character varying(64),
    type_ integer,
    create_time_ timestamp without time zone,
    root_proc_inst_id_ character varying(64),
    removal_time_ timestamp without time zone
);


--
-- Name: act_ge_property; Type: TABLE; Schema: camunda; Owner: -
--

CREATE TABLE camunda.act_ge_property (
    name_ character varying(64) NOT NULL,
    value_ character varying(300),
    rev_ integer
);


--
-- Name: act_ge_schema_log; Type: TABLE; Schema: camunda; Owner: -
--

CREATE TABLE camunda.act_ge_schema_log (
    id_ character varying(64) NOT NULL,
    timestamp_ timestamp without time zone,
    version_ character varying(255)
);


--
-- Name: act_hi_actinst; Type: TABLE; Schema: camunda; Owner: -
--

CREATE TABLE camunda.act_hi_actinst (
    id_ character varying(64) NOT NULL,
    parent_act_inst_id_ character varying(64),
    proc_def_key_ character varying(255),
    proc_def_id_ character varying(64) NOT NULL,
    root_proc_inst_id_ character varying(64),
    proc_inst_id_ character varying(64) NOT NULL,
    execution_id_ character varying(64) NOT NULL,
    act_id_ character varying(255) NOT NULL,
    task_id_ character varying(64),
    call_proc_inst_id_ character varying(64),
    call_case_inst_id_ character varying(64),
    act_name_ character varying(255),
    act_type_ character varying(255) NOT NULL,
    assignee_ character varying(255),
    start_time_ timestamp without time zone NOT NULL,
    end_time_ timestamp without time zone,
    duration_ bigint,
    act_inst_state_ integer,
    sequence_counter_ bigint,
    tenant_id_ character varying(64),
    removal_time_ timestamp without time zone
);


--
-- Name: act_hi_attachment; Type: TABLE; Schema: camunda; Owner: -
--

CREATE TABLE camunda.act_hi_attachment (
    id_ character varying(64) NOT NULL,
    rev_ integer,
    user_id_ character varying(255),
    name_ character varying(255),
    description_ character varying(4000),
    type_ character varying(255),
    task_id_ character varying(64),
    root_proc_inst_id_ character varying(64),
    proc_inst_id_ character varying(64),
    url_ character varying(4000),
    content_id_ character varying(64),
    tenant_id_ character varying(64),
    create_time_ timestamp without time zone,
    removal_time_ timestamp without time zone
);


--
-- Name: act_hi_batch; Type: TABLE; Schema: camunda; Owner: -
--

CREATE TABLE camunda.act_hi_batch (
    id_ character varying(64) NOT NULL,
    type_ character varying(255),
    total_jobs_ integer,
    jobs_per_seed_ integer,
    invocations_per_job_ integer,
    seed_job_def_id_ character varying(64),
    monitor_job_def_id_ character varying(64),
    batch_job_def_id_ character varying(64),
    tenant_id_ character varying(64),
    create_user_id_ character varying(255),
    start_time_ timestamp without time zone NOT NULL,
    end_time_ timestamp without time zone,
    removal_time_ timestamp without time zone,
    exec_start_time_ timestamp without time zone
);


--
-- Name: act_hi_caseactinst; Type: TABLE; Schema: camunda; Owner: -
--

CREATE TABLE camunda.act_hi_caseactinst (
    id_ character varying(64) NOT NULL,
    parent_act_inst_id_ character varying(64),
    case_def_id_ character varying(64) NOT NULL,
    case_inst_id_ character varying(64) NOT NULL,
    case_act_id_ character varying(255) NOT NULL,
    task_id_ character varying(64),
    call_proc_inst_id_ character varying(64),
    call_case_inst_id_ character varying(64),
    case_act_name_ character varying(255),
    case_act_type_ character varying(255),
    create_time_ timestamp without time zone NOT NULL,
    end_time_ timestamp without time zone,
    duration_ bigint,
    state_ integer,
    required_ boolean,
    tenant_id_ character varying(64)
);


--
-- Name: act_hi_caseinst; Type: TABLE; Schema: camunda; Owner: -
--

CREATE TABLE camunda.act_hi_caseinst (
    id_ character varying(64) NOT NULL,
    case_inst_id_ character varying(64) NOT NULL,
    business_key_ character varying(255),
    case_def_id_ character varying(64) NOT NULL,
    create_time_ timestamp without time zone NOT NULL,
    close_time_ timestamp without time zone,
    duration_ bigint,
    state_ integer,
    create_user_id_ character varying(255),
    super_case_instance_id_ character varying(64),
    super_process_instance_id_ character varying(64),
    tenant_id_ character varying(64)
);


--
-- Name: act_hi_comment; Type: TABLE; Schema: camunda; Owner: -
--

CREATE TABLE camunda.act_hi_comment (
    id_ character varying(64) NOT NULL,
    type_ character varying(255),
    time_ timestamp without time zone NOT NULL,
    user_id_ character varying(255),
    task_id_ character varying(64),
    root_proc_inst_id_ character varying(64),
    proc_inst_id_ character varying(64),
    action_ character varying(255),
    message_ character varying(4000),
    full_msg_ bytea,
    tenant_id_ character varying(64),
    removal_time_ timestamp without time zone
);


--
-- Name: act_hi_dec_in; Type: TABLE; Schema: camunda; Owner: -
--

CREATE TABLE camunda.act_hi_dec_in (
    id_ character varying(64) NOT NULL,
    dec_inst_id_ character varying(64) NOT NULL,
    clause_id_ character varying(64),
    clause_name_ character varying(255),
    var_type_ character varying(100),
    bytearray_id_ character varying(64),
    double_ double precision,
    long_ bigint,
    text_ character varying(4000),
    text2_ character varying(4000),
    tenant_id_ character varying(64),
    create_time_ timestamp without time zone,
    root_proc_inst_id_ character varying(64),
    removal_time_ timestamp without time zone
);


--
-- Name: act_hi_dec_out; Type: TABLE; Schema: camunda; Owner: -
--

CREATE TABLE camunda.act_hi_dec_out (
    id_ character varying(64) NOT NULL,
    dec_inst_id_ character varying(64) NOT NULL,
    clause_id_ character varying(64),
    clause_name_ character varying(255),
    rule_id_ character varying(64),
    rule_order_ integer,
    var_name_ character varying(255),
    var_type_ character varying(100),
    bytearray_id_ character varying(64),
    double_ double precision,
    long_ bigint,
    text_ character varying(4000),
    text2_ character varying(4000),
    tenant_id_ character varying(64),
    create_time_ timestamp without time zone,
    root_proc_inst_id_ character varying(64),
    removal_time_ timestamp without time zone
);


--
-- Name: act_hi_decinst; Type: TABLE; Schema: camunda; Owner: -
--

CREATE TABLE camunda.act_hi_decinst (
    id_ character varying(64) NOT NULL,
    dec_def_id_ character varying(64) NOT NULL,
    dec_def_key_ character varying(255) NOT NULL,
    dec_def_name_ character varying(255),
    proc_def_key_ character varying(255),
    proc_def_id_ character varying(64),
    proc_inst_id_ character varying(64),
    case_def_key_ character varying(255),
    case_def_id_ character varying(64),
    case_inst_id_ character varying(64),
    act_inst_id_ character varying(64),
    act_id_ character varying(255),
    eval_time_ timestamp without time zone NOT NULL,
    removal_time_ timestamp without time zone,
    collect_value_ double precision,
    user_id_ character varying(255),
    root_dec_inst_id_ character varying(64),
    root_proc_inst_id_ character varying(64),
    dec_req_id_ character varying(64),
    dec_req_key_ character varying(255),
    tenant_id_ character varying(64)
);


--
-- Name: act_hi_detail; Type: TABLE; Schema: camunda; Owner: -
--

CREATE TABLE camunda.act_hi_detail (
    id_ character varying(64) NOT NULL,
    type_ character varying(255) NOT NULL,
    proc_def_key_ character varying(255),
    proc_def_id_ character varying(64),
    root_proc_inst_id_ character varying(64),
    proc_inst_id_ character varying(64),
    execution_id_ character varying(64),
    case_def_key_ character varying(255),
    case_def_id_ character varying(64),
    case_inst_id_ character varying(64),
    case_execution_id_ character varying(64),
    task_id_ character varying(64),
    act_inst_id_ character varying(64),
    var_inst_id_ character varying(64),
    name_ character varying(255) NOT NULL,
    var_type_ character varying(64),
    rev_ integer,
    time_ timestamp without time zone NOT NULL,
    bytearray_id_ character varying(64),
    double_ double precision,
    long_ bigint,
    text_ character varying(4000),
    text2_ character varying(4000),
    sequence_counter_ bigint,
    tenant_id_ character varying(64),
    operation_id_ character varying(64),
    removal_time_ timestamp without time zone,
    initial_ boolean
);


--
-- Name: act_hi_ext_task_log; Type: TABLE; Schema: camunda; Owner: -
--

CREATE TABLE camunda.act_hi_ext_task_log (
    id_ character varying(64) NOT NULL,
    timestamp_ timestamp without time zone NOT NULL,
    ext_task_id_ character varying(64) NOT NULL,
    retries_ integer,
    topic_name_ character varying(255),
    worker_id_ character varying(255),
    priority_ bigint DEFAULT 0 NOT NULL,
    error_msg_ character varying(4000),
    error_details_id_ character varying(64),
    act_id_ character varying(255),
    act_inst_id_ character varying(64),
    execution_id_ character varying(64),
    proc_inst_id_ character varying(64),
    root_proc_inst_id_ character varying(64),
    proc_def_id_ character varying(64),
    proc_def_key_ character varying(255),
    tenant_id_ character varying(64),
    state_ integer,
    removal_time_ timestamp without time zone
);


--
-- Name: act_hi_identitylink; Type: TABLE; Schema: camunda; Owner: -
--

CREATE TABLE camunda.act_hi_identitylink (
    id_ character varying(64) NOT NULL,
    timestamp_ timestamp without time zone NOT NULL,
    type_ character varying(255),
    user_id_ character varying(255),
    group_id_ character varying(255),
    task_id_ character varying(64),
    root_proc_inst_id_ character varying(64),
    proc_def_id_ character varying(64),
    operation_type_ character varying(64),
    assigner_id_ character varying(64),
    proc_def_key_ character varying(255),
    tenant_id_ character varying(64),
    removal_time_ timestamp without time zone
);


--
-- Name: act_hi_incident; Type: TABLE; Schema: camunda; Owner: -
--

CREATE TABLE camunda.act_hi_incident (
    id_ character varying(64) NOT NULL,
    proc_def_key_ character varying(255),
    proc_def_id_ character varying(64),
    root_proc_inst_id_ character varying(64),
    proc_inst_id_ character varying(64),
    execution_id_ character varying(64),
    create_time_ timestamp without time zone NOT NULL,
    end_time_ timestamp without time zone,
    incident_msg_ character varying(4000),
    incident_type_ character varying(255) NOT NULL,
    activity_id_ character varying(255),
    failed_activity_id_ character varying(255),
    cause_incident_id_ character varying(64),
    root_cause_incident_id_ character varying(64),
    configuration_ character varying(255),
    history_configuration_ character varying(255),
    incident_state_ integer,
    tenant_id_ character varying(64),
    job_def_id_ character varying(64),
    annotation_ character varying(4000),
    removal_time_ timestamp without time zone
);


--
-- Name: act_hi_job_log; Type: TABLE; Schema: camunda; Owner: -
--

CREATE TABLE camunda.act_hi_job_log (
    id_ character varying(64) NOT NULL,
    timestamp_ timestamp without time zone NOT NULL,
    job_id_ character varying(64) NOT NULL,
    job_duedate_ timestamp without time zone,
    job_retries_ integer,
    job_priority_ bigint DEFAULT 0 NOT NULL,
    job_exception_msg_ character varying(4000),
    job_exception_stack_id_ character varying(64),
    job_state_ integer,
    job_def_id_ character varying(64),
    job_def_type_ character varying(255),
    job_def_configuration_ character varying(255),
    act_id_ character varying(255),
    failed_act_id_ character varying(255),
    execution_id_ character varying(64),
    root_proc_inst_id_ character varying(64),
    process_instance_id_ character varying(64),
    process_def_id_ character varying(64),
    process_def_key_ character varying(255),
    deployment_id_ character varying(64),
    sequence_counter_ bigint,
    tenant_id_ character varying(64),
    hostname_ character varying(255),
    removal_time_ timestamp without time zone
);


--
-- Name: act_hi_op_log; Type: TABLE; Schema: camunda; Owner: -
--

CREATE TABLE camunda.act_hi_op_log (
    id_ character varying(64) NOT NULL,
    deployment_id_ character varying(64),
    proc_def_id_ character varying(64),
    proc_def_key_ character varying(255),
    root_proc_inst_id_ character varying(64),
    proc_inst_id_ character varying(64),
    execution_id_ character varying(64),
    case_def_id_ character varying(64),
    case_inst_id_ character varying(64),
    case_execution_id_ character varying(64),
    task_id_ character varying(64),
    job_id_ character varying(64),
    job_def_id_ character varying(64),
    batch_id_ character varying(64),
    user_id_ character varying(255),
    timestamp_ timestamp without time zone NOT NULL,
    operation_type_ character varying(64),
    operation_id_ character varying(64),
    entity_type_ character varying(30),
    property_ character varying(64),
    org_value_ character varying(4000),
    new_value_ character varying(4000),
    tenant_id_ character varying(64),
    removal_time_ timestamp without time zone,
    category_ character varying(64),
    external_task_id_ character varying(64),
    annotation_ character varying(4000)
);


--
-- Name: act_hi_procinst; Type: TABLE; Schema: camunda; Owner: -
--

CREATE TABLE camunda.act_hi_procinst (
    id_ character varying(64) NOT NULL,
    proc_inst_id_ character varying(64) NOT NULL,
    business_key_ character varying(255),
    proc_def_key_ character varying(255),
    proc_def_id_ character varying(64) NOT NULL,
    start_time_ timestamp without time zone NOT NULL,
    end_time_ timestamp without time zone,
    removal_time_ timestamp without time zone,
    duration_ bigint,
    start_user_id_ character varying(255),
    start_act_id_ character varying(255),
    end_act_id_ character varying(255),
    super_process_instance_id_ character varying(64),
    root_proc_inst_id_ character varying(64),
    super_case_instance_id_ character varying(64),
    case_inst_id_ character varying(64),
    delete_reason_ character varying(4000),
    tenant_id_ character varying(64),
    state_ character varying(255)
);


--
-- Name: act_hi_taskinst; Type: TABLE; Schema: camunda; Owner: -
--

CREATE TABLE camunda.act_hi_taskinst (
    id_ character varying(64) NOT NULL,
    task_def_key_ character varying(255),
    proc_def_key_ character varying(255),
    proc_def_id_ character varying(64),
    root_proc_inst_id_ character varying(64),
    proc_inst_id_ character varying(64),
    execution_id_ character varying(64),
    case_def_key_ character varying(255),
    case_def_id_ character varying(64),
    case_inst_id_ character varying(64),
    case_execution_id_ character varying(64),
    act_inst_id_ character varying(64),
    name_ character varying(255),
    parent_task_id_ character varying(64),
    description_ character varying(4000),
    owner_ character varying(255),
    assignee_ character varying(255),
    start_time_ timestamp without time zone NOT NULL,
    end_time_ timestamp without time zone,
    duration_ bigint,
    delete_reason_ character varying(4000),
    priority_ integer,
    due_date_ timestamp without time zone,
    follow_up_date_ timestamp without time zone,
    tenant_id_ character varying(64),
    removal_time_ timestamp without time zone
);


--
-- Name: act_hi_varinst; Type: TABLE; Schema: camunda; Owner: -
--

CREATE TABLE camunda.act_hi_varinst (
    id_ character varying(64) NOT NULL,
    proc_def_key_ character varying(255),
    proc_def_id_ character varying(64),
    root_proc_inst_id_ character varying(64),
    proc_inst_id_ character varying(64),
    execution_id_ character varying(64),
    act_inst_id_ character varying(64),
    case_def_key_ character varying(255),
    case_def_id_ character varying(64),
    case_inst_id_ character varying(64),
    case_execution_id_ character varying(64),
    task_id_ character varying(64),
    name_ character varying(255) NOT NULL,
    var_type_ character varying(100),
    create_time_ timestamp without time zone,
    rev_ integer,
    bytearray_id_ character varying(64),
    double_ double precision,
    long_ bigint,
    text_ character varying(4000),
    text2_ character varying(4000),
    tenant_id_ character varying(64),
    state_ character varying(20),
    removal_time_ timestamp without time zone
);


--
-- Name: act_id_group; Type: TABLE; Schema: camunda; Owner: -
--

CREATE TABLE camunda.act_id_group (
    id_ character varying(64) NOT NULL,
    rev_ integer,
    name_ character varying(255),
    type_ character varying(255)
);


--
-- Name: act_id_info; Type: TABLE; Schema: camunda; Owner: -
--

CREATE TABLE camunda.act_id_info (
    id_ character varying(64) NOT NULL,
    rev_ integer,
    user_id_ character varying(64),
    type_ character varying(64),
    key_ character varying(255),
    value_ character varying(255),
    password_ bytea,
    parent_id_ character varying(255)
);


--
-- Name: act_id_membership; Type: TABLE; Schema: camunda; Owner: -
--

CREATE TABLE camunda.act_id_membership (
    user_id_ character varying(64) NOT NULL,
    group_id_ character varying(64) NOT NULL
);


--
-- Name: act_id_tenant; Type: TABLE; Schema: camunda; Owner: -
--

CREATE TABLE camunda.act_id_tenant (
    id_ character varying(64) NOT NULL,
    rev_ integer,
    name_ character varying(255)
);


--
-- Name: act_id_tenant_member; Type: TABLE; Schema: camunda; Owner: -
--

CREATE TABLE camunda.act_id_tenant_member (
    id_ character varying(64) NOT NULL,
    tenant_id_ character varying(64) NOT NULL,
    user_id_ character varying(64),
    group_id_ character varying(64)
);


--
-- Name: act_id_user; Type: TABLE; Schema: camunda; Owner: -
--

CREATE TABLE camunda.act_id_user (
    id_ character varying(64) NOT NULL,
    rev_ integer,
    first_ character varying(255),
    last_ character varying(255),
    email_ character varying(255),
    pwd_ character varying(255),
    salt_ character varying(255),
    lock_exp_time_ timestamp without time zone,
    attempts_ integer,
    picture_id_ character varying(64)
);


--
-- Name: act_re_camformdef; Type: TABLE; Schema: camunda; Owner: -
--

CREATE TABLE camunda.act_re_camformdef (
    id_ character varying(64) NOT NULL,
    rev_ integer,
    key_ character varying(255) NOT NULL,
    version_ integer NOT NULL,
    deployment_id_ character varying(64),
    resource_name_ character varying(4000),
    tenant_id_ character varying(64)
);


--
-- Name: act_re_case_def; Type: TABLE; Schema: camunda; Owner: -
--

CREATE TABLE camunda.act_re_case_def (
    id_ character varying(64) NOT NULL,
    rev_ integer,
    category_ character varying(255),
    name_ character varying(255),
    key_ character varying(255) NOT NULL,
    version_ integer NOT NULL,
    deployment_id_ character varying(64),
    resource_name_ character varying(4000),
    dgrm_resource_name_ character varying(4000),
    tenant_id_ character varying(64),
    history_ttl_ integer
);


--
-- Name: act_re_decision_def; Type: TABLE; Schema: camunda; Owner: -
--

CREATE TABLE camunda.act_re_decision_def (
    id_ character varying(64) NOT NULL,
    rev_ integer,
    category_ character varying(255),
    name_ character varying(255),
    key_ character varying(255) NOT NULL,
    version_ integer NOT NULL,
    deployment_id_ character varying(64),
    resource_name_ character varying(4000),
    dgrm_resource_name_ character varying(4000),
    dec_req_id_ character varying(64),
    dec_req_key_ character varying(255),
    tenant_id_ character varying(64),
    history_ttl_ integer,
    version_tag_ character varying(64)
);


--
-- Name: act_re_decision_req_def; Type: TABLE; Schema: camunda; Owner: -
--

CREATE TABLE camunda.act_re_decision_req_def (
    id_ character varying(64) NOT NULL,
    rev_ integer,
    category_ character varying(255),
    name_ character varying(255),
    key_ character varying(255) NOT NULL,
    version_ integer NOT NULL,
    deployment_id_ character varying(64),
    resource_name_ character varying(4000),
    dgrm_resource_name_ character varying(4000),
    tenant_id_ character varying(64)
);


--
-- Name: act_re_deployment; Type: TABLE; Schema: camunda; Owner: -
--

CREATE TABLE camunda.act_re_deployment (
    id_ character varying(64) NOT NULL,
    name_ character varying(255),
    deploy_time_ timestamp without time zone,
    source_ character varying(255),
    tenant_id_ character varying(64)
);


--
-- Name: act_re_procdef; Type: TABLE; Schema: camunda; Owner: -
--

CREATE TABLE camunda.act_re_procdef (
    id_ character varying(64) NOT NULL,
    rev_ integer,
    category_ character varying(255),
    name_ character varying(255),
    key_ character varying(255) NOT NULL,
    version_ integer NOT NULL,
    deployment_id_ character varying(64),
    resource_name_ character varying(4000),
    dgrm_resource_name_ character varying(4000),
    has_start_form_key_ boolean,
    suspension_state_ integer,
    tenant_id_ character varying(64),
    version_tag_ character varying(64),
    history_ttl_ integer,
    startable_ boolean DEFAULT true NOT NULL
);


--
-- Name: act_ru_authorization; Type: TABLE; Schema: camunda; Owner: -
--

CREATE TABLE camunda.act_ru_authorization (
    id_ character varying(64) NOT NULL,
    rev_ integer NOT NULL,
    type_ integer NOT NULL,
    group_id_ character varying(255),
    user_id_ character varying(255),
    resource_type_ integer NOT NULL,
    resource_id_ character varying(255),
    perms_ integer,
    removal_time_ timestamp without time zone,
    root_proc_inst_id_ character varying(64)
);


--
-- Name: act_ru_batch; Type: TABLE; Schema: camunda; Owner: -
--

CREATE TABLE camunda.act_ru_batch (
    id_ character varying(64) NOT NULL,
    rev_ integer NOT NULL,
    type_ character varying(255),
    total_jobs_ integer,
    jobs_created_ integer,
    jobs_per_seed_ integer,
    invocations_per_job_ integer,
    seed_job_def_id_ character varying(64),
    batch_job_def_id_ character varying(64),
    monitor_job_def_id_ character varying(64),
    suspension_state_ integer,
    configuration_ character varying(255),
    tenant_id_ character varying(64),
    create_user_id_ character varying(255),
    start_time_ timestamp without time zone,
    exec_start_time_ timestamp without time zone
);


--
-- Name: act_ru_case_execution; Type: TABLE; Schema: camunda; Owner: -
--

CREATE TABLE camunda.act_ru_case_execution (
    id_ character varying(64) NOT NULL,
    rev_ integer,
    case_inst_id_ character varying(64),
    super_case_exec_ character varying(64),
    super_exec_ character varying(64),
    business_key_ character varying(255),
    parent_id_ character varying(64),
    case_def_id_ character varying(64),
    act_id_ character varying(255),
    prev_state_ integer,
    current_state_ integer,
    required_ boolean,
    tenant_id_ character varying(64)
);


--
-- Name: act_ru_case_sentry_part; Type: TABLE; Schema: camunda; Owner: -
--

CREATE TABLE camunda.act_ru_case_sentry_part (
    id_ character varying(64) NOT NULL,
    rev_ integer,
    case_inst_id_ character varying(64),
    case_exec_id_ character varying(64),
    sentry_id_ character varying(255),
    type_ character varying(255),
    source_case_exec_id_ character varying(64),
    standard_event_ character varying(255),
    source_ character varying(255),
    variable_event_ character varying(255),
    variable_name_ character varying(255),
    satisfied_ boolean,
    tenant_id_ character varying(64)
);


--
-- Name: act_ru_event_subscr; Type: TABLE; Schema: camunda; Owner: -
--

CREATE TABLE camunda.act_ru_event_subscr (
    id_ character varying(64) NOT NULL,
    rev_ integer,
    event_type_ character varying(255) NOT NULL,
    event_name_ character varying(255),
    execution_id_ character varying(64),
    proc_inst_id_ character varying(64),
    activity_id_ character varying(255),
    configuration_ character varying(255),
    created_ timestamp without time zone NOT NULL,
    tenant_id_ character varying(64)
);


--
-- Name: act_ru_execution; Type: TABLE; Schema: camunda; Owner: -
--

CREATE TABLE camunda.act_ru_execution (
    id_ character varying(64) NOT NULL,
    rev_ integer,
    root_proc_inst_id_ character varying(64),
    proc_inst_id_ character varying(64),
    business_key_ character varying(255),
    parent_id_ character varying(64),
    proc_def_id_ character varying(64),
    super_exec_ character varying(64),
    super_case_exec_ character varying(64),
    case_inst_id_ character varying(64),
    act_id_ character varying(255),
    act_inst_id_ character varying(64),
    is_active_ boolean,
    is_concurrent_ boolean,
    is_scope_ boolean,
    is_event_scope_ boolean,
    suspension_state_ integer,
    cached_ent_state_ integer,
    sequence_counter_ bigint,
    tenant_id_ character varying(64)
);


--
-- Name: act_ru_ext_task; Type: TABLE; Schema: camunda; Owner: -
--

CREATE TABLE camunda.act_ru_ext_task (
    id_ character varying(64) NOT NULL,
    rev_ integer NOT NULL,
    worker_id_ character varying(255),
    topic_name_ character varying(255),
    retries_ integer,
    error_msg_ character varying(4000),
    error_details_id_ character varying(64),
    lock_exp_time_ timestamp without time zone,
    suspension_state_ integer,
    execution_id_ character varying(64),
    proc_inst_id_ character varying(64),
    proc_def_id_ character varying(64),
    proc_def_key_ character varying(255),
    act_id_ character varying(255),
    act_inst_id_ character varying(64),
    tenant_id_ character varying(64),
    priority_ bigint DEFAULT 0 NOT NULL,
    last_failure_log_id_ character varying(64)
);


--
-- Name: act_ru_filter; Type: TABLE; Schema: camunda; Owner: -
--

CREATE TABLE camunda.act_ru_filter (
    id_ character varying(64) NOT NULL,
    rev_ integer NOT NULL,
    resource_type_ character varying(255) NOT NULL,
    name_ character varying(255) NOT NULL,
    owner_ character varying(255),
    query_ text NOT NULL,
    properties_ text
);


--
-- Name: act_ru_identitylink; Type: TABLE; Schema: camunda; Owner: -
--

CREATE TABLE camunda.act_ru_identitylink (
    id_ character varying(64) NOT NULL,
    rev_ integer,
    group_id_ character varying(255),
    type_ character varying(255),
    user_id_ character varying(255),
    task_id_ character varying(64),
    proc_def_id_ character varying(64),
    tenant_id_ character varying(64)
);


--
-- Name: act_ru_incident; Type: TABLE; Schema: camunda; Owner: -
--

CREATE TABLE camunda.act_ru_incident (
    id_ character varying(64) NOT NULL,
    rev_ integer NOT NULL,
    incident_timestamp_ timestamp without time zone NOT NULL,
    incident_msg_ character varying(4000),
    incident_type_ character varying(255) NOT NULL,
    execution_id_ character varying(64),
    activity_id_ character varying(255),
    failed_activity_id_ character varying(255),
    proc_inst_id_ character varying(64),
    proc_def_id_ character varying(64),
    cause_incident_id_ character varying(64),
    root_cause_incident_id_ character varying(64),
    configuration_ character varying(255),
    tenant_id_ character varying(64),
    job_def_id_ character varying(64),
    annotation_ character varying(4000)
);


--
-- Name: act_ru_job; Type: TABLE; Schema: camunda; Owner: -
--

CREATE TABLE camunda.act_ru_job (
    id_ character varying(64) NOT NULL,
    rev_ integer,
    type_ character varying(255) NOT NULL,
    lock_exp_time_ timestamp without time zone,
    lock_owner_ character varying(255),
    exclusive_ boolean,
    execution_id_ character varying(64),
    process_instance_id_ character varying(64),
    process_def_id_ character varying(64),
    process_def_key_ character varying(255),
    retries_ integer,
    exception_stack_id_ character varying(64),
    exception_msg_ character varying(4000),
    failed_act_id_ character varying(255),
    duedate_ timestamp without time zone,
    repeat_ character varying(255),
    repeat_offset_ bigint DEFAULT 0,
    handler_type_ character varying(255),
    handler_cfg_ character varying(4000),
    deployment_id_ character varying(64),
    suspension_state_ integer DEFAULT 1 NOT NULL,
    job_def_id_ character varying(64),
    priority_ bigint DEFAULT 0 NOT NULL,
    sequence_counter_ bigint,
    tenant_id_ character varying(64),
    create_time_ timestamp without time zone,
    last_failure_log_id_ character varying(64)
);


--
-- Name: act_ru_jobdef; Type: TABLE; Schema: camunda; Owner: -
--

CREATE TABLE camunda.act_ru_jobdef (
    id_ character varying(64) NOT NULL,
    rev_ integer,
    proc_def_id_ character varying(64),
    proc_def_key_ character varying(255),
    act_id_ character varying(255),
    job_type_ character varying(255) NOT NULL,
    job_configuration_ character varying(255),
    suspension_state_ integer,
    job_priority_ bigint,
    tenant_id_ character varying(64),
    deployment_id_ character varying(64)
);


--
-- Name: act_ru_meter_log; Type: TABLE; Schema: camunda; Owner: -
--

CREATE TABLE camunda.act_ru_meter_log (
    id_ character varying(64) NOT NULL,
    name_ character varying(64) NOT NULL,
    reporter_ character varying(255),
    value_ bigint,
    timestamp_ timestamp without time zone,
    milliseconds_ bigint DEFAULT 0
);


--
-- Name: act_ru_task; Type: TABLE; Schema: camunda; Owner: -
--

CREATE TABLE camunda.act_ru_task (
    id_ character varying(64) NOT NULL,
    rev_ integer,
    execution_id_ character varying(64),
    proc_inst_id_ character varying(64),
    proc_def_id_ character varying(64),
    case_execution_id_ character varying(64),
    case_inst_id_ character varying(64),
    case_def_id_ character varying(64),
    name_ character varying(255),
    parent_task_id_ character varying(64),
    description_ character varying(4000),
    task_def_key_ character varying(255),
    owner_ character varying(255),
    assignee_ character varying(255),
    delegation_ character varying(64),
    priority_ integer,
    create_time_ timestamp without time zone,
    last_updated_ timestamp without time zone,
    due_date_ timestamp without time zone,
    follow_up_date_ timestamp without time zone,
    suspension_state_ integer,
    tenant_id_ character varying(64)
);


--
-- Name: act_ru_task_meter_log; Type: TABLE; Schema: camunda; Owner: -
--

CREATE TABLE camunda.act_ru_task_meter_log (
    id_ character varying(64) NOT NULL,
    assignee_hash_ bigint,
    timestamp_ timestamp without time zone
);


--
-- Name: act_ru_variable; Type: TABLE; Schema: camunda; Owner: -
--

CREATE TABLE camunda.act_ru_variable (
    id_ character varying(64) NOT NULL,
    rev_ integer,
    type_ character varying(255) NOT NULL,
    name_ character varying(255) NOT NULL,
    execution_id_ character varying(64),
    proc_inst_id_ character varying(64),
    proc_def_id_ character varying(64),
    case_execution_id_ character varying(64),
    case_inst_id_ character varying(64),
    task_id_ character varying(64),
    batch_id_ character varying(64),
    bytearray_id_ character varying(64),
    double_ double precision,
    long_ bigint,
    text_ character varying(4000),
    text2_ character varying(4000),
    var_scope_ character varying(64),
    sequence_counter_ bigint,
    is_concurrent_local_ boolean,
    tenant_id_ character varying(64)
);


--
-- Name: request_states; Type: TABLE; Schema: crm_request; Owner: -
--

CREATE TABLE crm_request.request_states (
    s_code public.t_code NOT NULL,
    s_caption public.t_caption NOT NULL
);


--
-- Name: TABLE request_states; Type: COMMENT; Schema: crm_request; Owner: -
--

COMMENT ON TABLE crm_request.request_states IS 'Состояния заявок';


--
-- Name: COLUMN request_states.s_code; Type: COMMENT; Schema: crm_request; Owner: -
--

COMMENT ON COLUMN crm_request.request_states.s_code IS 'Код';


--
-- Name: COLUMN request_states.s_caption; Type: COMMENT; Schema: crm_request; Owner: -
--

COMMENT ON COLUMN crm_request.request_states.s_caption IS 'Наименование';


--
-- Name: seq_request; Type: SEQUENCE; Schema: crm_request; Owner: -
--

CREATE SEQUENCE crm_request.seq_request
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: seq_request_item; Type: SEQUENCE; Schema: crm_request; Owner: -
--

CREATE SEQUENCE crm_request.seq_request_item
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: seq_blanks; Type: SEQUENCE; Schema: dictionaries; Owner: -
--

CREATE SEQUENCE dictionaries.seq_blanks
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: seq_contractor; Type: SEQUENCE; Schema: dictionaries; Owner: -
--

CREATE SEQUENCE dictionaries.seq_contractor
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: seq_material; Type: SEQUENCE; Schema: dictionaries; Owner: -
--

CREATE SEQUENCE dictionaries.seq_material
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: seq_materials_in_blanks; Type: SEQUENCE; Schema: dictionaries; Owner: -
--

CREATE SEQUENCE dictionaries.seq_materials_in_blanks
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: seq_product_composition; Type: SEQUENCE; Schema: dictionaries; Owner: -
--

CREATE SEQUENCE dictionaries.seq_product_composition
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: seq_products; Type: SEQUENCE; Schema: dictionaries; Owner: -
--

CREATE SEQUENCE dictionaries.seq_products
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: seq_component; Type: SEQUENCE; Schema: uni_component; Owner: -
--

CREATE SEQUENCE uni_component.seq_component
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: component_errors; Type: VIEW; Schema: uni_error; Owner: -
--

CREATE VIEW uni_error.component_errors AS
 WITH RECURSIVE componentall AS (
         SELECT componentin.id AS idroot,
            componentin.id,
            componentin.s_name AS sname,
            componentin.s_caption AS scaption
           FROM uni_component.component componentin
        UNION ALL
         SELECT componentall.idroot,
            componentin.id,
            componentin.s_name AS sname,
            componentin.s_caption AS scaption
           FROM (uni_component.component componentin
             JOIN componentall ON (((componentall.id)::bigint = (componentin.id_parent)::bigint)))
        )
 SELECT component.id AS id_component,
    component.sname AS s_component_mc,
    component.scaption AS s_component_hl,
    error.id AS id_error,
    error.s_name AS s_error_mc,
    error.s_caption AS s_error_hl,
    error.s_description AS s_error_dc
   FROM (componentall component
     LEFT JOIN uni_error.error error ON (((error.id_component)::bigint = (component.idroot)::bigint)));


--
-- Name: seq_error; Type: SEQUENCE; Schema: uni_error; Owner: -
--

CREATE SEQUENCE uni_error.seq_error
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Data for Name: act_ge_bytearray; Type: TABLE DATA; Schema: camunda; Owner: -
--

COPY camunda.act_ge_bytearray (id_, rev_, name_, deployment_id_, bytes_, generated_, tenant_id_, type_, create_time_, root_proc_inst_id_, removal_time_) FROM stdin;
\.
COPY camunda.act_ge_bytearray (id_, rev_, name_, deployment_id_, bytes_, generated_, tenant_id_, type_, create_time_, root_proc_inst_id_, removal_time_) FROM '$$PATH$$/3884.dat';

--
-- Data for Name: act_ge_property; Type: TABLE DATA; Schema: camunda; Owner: -
--

COPY camunda.act_ge_property (name_, value_, rev_) FROM stdin;
\.
COPY camunda.act_ge_property (name_, value_, rev_) FROM '$$PATH$$/3883.dat';

--
-- Data for Name: act_ge_schema_log; Type: TABLE DATA; Schema: camunda; Owner: -
--

COPY camunda.act_ge_schema_log (id_, timestamp_, version_) FROM stdin;
\.
COPY camunda.act_ge_schema_log (id_, timestamp_, version_) FROM '$$PATH$$/3885.dat';

--
-- Data for Name: act_hi_actinst; Type: TABLE DATA; Schema: camunda; Owner: -
--

COPY camunda.act_hi_actinst (id_, parent_act_inst_id_, proc_def_key_, proc_def_id_, root_proc_inst_id_, proc_inst_id_, execution_id_, act_id_, task_id_, call_proc_inst_id_, call_case_inst_id_, act_name_, act_type_, assignee_, start_time_, end_time_, duration_, act_inst_state_, sequence_counter_, tenant_id_, removal_time_) FROM stdin;
\.
COPY camunda.act_hi_actinst (id_, parent_act_inst_id_, proc_def_key_, proc_def_id_, root_proc_inst_id_, proc_inst_id_, execution_id_, act_id_, task_id_, call_proc_inst_id_, call_case_inst_id_, act_name_, act_type_, assignee_, start_time_, end_time_, duration_, act_inst_state_, sequence_counter_, tenant_id_, removal_time_) FROM '$$PATH$$/3904.dat';

--
-- Data for Name: act_hi_attachment; Type: TABLE DATA; Schema: camunda; Owner: -
--

COPY camunda.act_hi_attachment (id_, rev_, user_id_, name_, description_, type_, task_id_, root_proc_inst_id_, proc_inst_id_, url_, content_id_, tenant_id_, create_time_, removal_time_) FROM stdin;
\.
COPY camunda.act_hi_attachment (id_, rev_, user_id_, name_, description_, type_, task_id_, root_proc_inst_id_, proc_inst_id_, url_, content_id_, tenant_id_, create_time_, removal_time_) FROM '$$PATH$$/3910.dat';

--
-- Data for Name: act_hi_batch; Type: TABLE DATA; Schema: camunda; Owner: -
--

COPY camunda.act_hi_batch (id_, type_, total_jobs_, jobs_per_seed_, invocations_per_job_, seed_job_def_id_, monitor_job_def_id_, batch_job_def_id_, tenant_id_, create_user_id_, start_time_, end_time_, removal_time_, exec_start_time_) FROM stdin;
\.
COPY camunda.act_hi_batch (id_, type_, total_jobs_, jobs_per_seed_, invocations_per_job_, seed_job_def_id_, monitor_job_def_id_, batch_job_def_id_, tenant_id_, create_user_id_, start_time_, end_time_, removal_time_, exec_start_time_) FROM '$$PATH$$/3914.dat';

--
-- Data for Name: act_hi_caseactinst; Type: TABLE DATA; Schema: camunda; Owner: -
--

COPY camunda.act_hi_caseactinst (id_, parent_act_inst_id_, case_def_id_, case_inst_id_, case_act_id_, task_id_, call_proc_inst_id_, call_case_inst_id_, case_act_name_, case_act_type_, create_time_, end_time_, duration_, state_, required_, tenant_id_) FROM stdin;
\.
COPY camunda.act_hi_caseactinst (id_, parent_act_inst_id_, case_def_id_, case_inst_id_, case_act_id_, task_id_, call_proc_inst_id_, call_case_inst_id_, case_act_name_, case_act_type_, create_time_, end_time_, duration_, state_, required_, tenant_id_) FROM '$$PATH$$/3926.dat';

--
-- Data for Name: act_hi_caseinst; Type: TABLE DATA; Schema: camunda; Owner: -
--

COPY camunda.act_hi_caseinst (id_, case_inst_id_, business_key_, case_def_id_, create_time_, close_time_, duration_, state_, create_user_id_, super_case_instance_id_, super_process_instance_id_, tenant_id_) FROM stdin;
\.
COPY camunda.act_hi_caseinst (id_, case_inst_id_, business_key_, case_def_id_, create_time_, close_time_, duration_, state_, create_user_id_, super_case_instance_id_, super_process_instance_id_, tenant_id_) FROM '$$PATH$$/3925.dat';

--
-- Data for Name: act_hi_comment; Type: TABLE DATA; Schema: camunda; Owner: -
--

COPY camunda.act_hi_comment (id_, type_, time_, user_id_, task_id_, root_proc_inst_id_, proc_inst_id_, action_, message_, full_msg_, tenant_id_, removal_time_) FROM stdin;
\.
COPY camunda.act_hi_comment (id_, type_, time_, user_id_, task_id_, root_proc_inst_id_, proc_inst_id_, action_, message_, full_msg_, tenant_id_, removal_time_) FROM '$$PATH$$/3909.dat';

--
-- Data for Name: act_hi_dec_in; Type: TABLE DATA; Schema: camunda; Owner: -
--

COPY camunda.act_hi_dec_in (id_, dec_inst_id_, clause_id_, clause_name_, var_type_, bytearray_id_, double_, long_, text_, text2_, tenant_id_, create_time_, root_proc_inst_id_, removal_time_) FROM stdin;
\.
COPY camunda.act_hi_dec_in (id_, dec_inst_id_, clause_id_, clause_name_, var_type_, bytearray_id_, double_, long_, text_, text2_, tenant_id_, create_time_, root_proc_inst_id_, removal_time_) FROM '$$PATH$$/3930.dat';

--
-- Data for Name: act_hi_dec_out; Type: TABLE DATA; Schema: camunda; Owner: -
--

COPY camunda.act_hi_dec_out (id_, dec_inst_id_, clause_id_, clause_name_, rule_id_, rule_order_, var_name_, var_type_, bytearray_id_, double_, long_, text_, text2_, tenant_id_, create_time_, root_proc_inst_id_, removal_time_) FROM stdin;
\.
COPY camunda.act_hi_dec_out (id_, dec_inst_id_, clause_id_, clause_name_, rule_id_, rule_order_, var_name_, var_type_, bytearray_id_, double_, long_, text_, text2_, tenant_id_, create_time_, root_proc_inst_id_, removal_time_) FROM '$$PATH$$/3931.dat';

--
-- Data for Name: act_hi_decinst; Type: TABLE DATA; Schema: camunda; Owner: -
--

COPY camunda.act_hi_decinst (id_, dec_def_id_, dec_def_key_, dec_def_name_, proc_def_key_, proc_def_id_, proc_inst_id_, case_def_key_, case_def_id_, case_inst_id_, act_inst_id_, act_id_, eval_time_, removal_time_, collect_value_, user_id_, root_dec_inst_id_, root_proc_inst_id_, dec_req_id_, dec_req_key_, tenant_id_) FROM stdin;
\.
COPY camunda.act_hi_decinst (id_, dec_def_id_, dec_def_key_, dec_def_name_, proc_def_key_, proc_def_id_, proc_inst_id_, case_def_key_, case_def_id_, case_inst_id_, act_inst_id_, act_id_, eval_time_, removal_time_, collect_value_, user_id_, root_dec_inst_id_, root_proc_inst_id_, dec_req_id_, dec_req_key_, tenant_id_) FROM '$$PATH$$/3929.dat';

--
-- Data for Name: act_hi_detail; Type: TABLE DATA; Schema: camunda; Owner: -
--

COPY camunda.act_hi_detail (id_, type_, proc_def_key_, proc_def_id_, root_proc_inst_id_, proc_inst_id_, execution_id_, case_def_key_, case_def_id_, case_inst_id_, case_execution_id_, task_id_, act_inst_id_, var_inst_id_, name_, var_type_, rev_, time_, bytearray_id_, double_, long_, text_, text2_, sequence_counter_, tenant_id_, operation_id_, removal_time_, initial_) FROM stdin;
\.
COPY camunda.act_hi_detail (id_, type_, proc_def_key_, proc_def_id_, root_proc_inst_id_, proc_inst_id_, execution_id_, case_def_key_, case_def_id_, case_inst_id_, case_execution_id_, task_id_, act_inst_id_, var_inst_id_, name_, var_type_, rev_, time_, bytearray_id_, double_, long_, text_, text2_, sequence_counter_, tenant_id_, operation_id_, removal_time_, initial_) FROM '$$PATH$$/3907.dat';

--
-- Data for Name: act_hi_ext_task_log; Type: TABLE DATA; Schema: camunda; Owner: -
--

COPY camunda.act_hi_ext_task_log (id_, timestamp_, ext_task_id_, retries_, topic_name_, worker_id_, priority_, error_msg_, error_details_id_, act_id_, act_inst_id_, execution_id_, proc_inst_id_, root_proc_inst_id_, proc_def_id_, proc_def_key_, tenant_id_, state_, removal_time_) FROM stdin;
\.
COPY camunda.act_hi_ext_task_log (id_, timestamp_, ext_task_id_, retries_, topic_name_, worker_id_, priority_, error_msg_, error_details_id_, act_id_, act_inst_id_, execution_id_, proc_inst_id_, root_proc_inst_id_, proc_def_id_, proc_def_key_, tenant_id_, state_, removal_time_) FROM '$$PATH$$/3915.dat';

--
-- Data for Name: act_hi_identitylink; Type: TABLE DATA; Schema: camunda; Owner: -
--

COPY camunda.act_hi_identitylink (id_, timestamp_, type_, user_id_, group_id_, task_id_, root_proc_inst_id_, proc_def_id_, operation_type_, assigner_id_, proc_def_key_, tenant_id_, removal_time_) FROM stdin;
\.
COPY camunda.act_hi_identitylink (id_, timestamp_, type_, user_id_, group_id_, task_id_, root_proc_inst_id_, proc_def_id_, operation_type_, assigner_id_, proc_def_key_, tenant_id_, removal_time_) FROM '$$PATH$$/3908.dat';

--
-- Data for Name: act_hi_incident; Type: TABLE DATA; Schema: camunda; Owner: -
--

COPY camunda.act_hi_incident (id_, proc_def_key_, proc_def_id_, root_proc_inst_id_, proc_inst_id_, execution_id_, create_time_, end_time_, incident_msg_, incident_type_, activity_id_, failed_activity_id_, cause_incident_id_, root_cause_incident_id_, configuration_, history_configuration_, incident_state_, tenant_id_, job_def_id_, annotation_, removal_time_) FROM stdin;
\.
COPY camunda.act_hi_incident (id_, proc_def_key_, proc_def_id_, root_proc_inst_id_, proc_inst_id_, execution_id_, create_time_, end_time_, incident_msg_, incident_type_, activity_id_, failed_activity_id_, cause_incident_id_, root_cause_incident_id_, configuration_, history_configuration_, incident_state_, tenant_id_, job_def_id_, annotation_, removal_time_) FROM '$$PATH$$/3912.dat';

--
-- Data for Name: act_hi_job_log; Type: TABLE DATA; Schema: camunda; Owner: -
--

COPY camunda.act_hi_job_log (id_, timestamp_, job_id_, job_duedate_, job_retries_, job_priority_, job_exception_msg_, job_exception_stack_id_, job_state_, job_def_id_, job_def_type_, job_def_configuration_, act_id_, failed_act_id_, execution_id_, root_proc_inst_id_, process_instance_id_, process_def_id_, process_def_key_, deployment_id_, sequence_counter_, tenant_id_, hostname_, removal_time_) FROM stdin;
\.
COPY camunda.act_hi_job_log (id_, timestamp_, job_id_, job_duedate_, job_retries_, job_priority_, job_exception_msg_, job_exception_stack_id_, job_state_, job_def_id_, job_def_type_, job_def_configuration_, act_id_, failed_act_id_, execution_id_, root_proc_inst_id_, process_instance_id_, process_def_id_, process_def_key_, deployment_id_, sequence_counter_, tenant_id_, hostname_, removal_time_) FROM '$$PATH$$/3913.dat';

--
-- Data for Name: act_hi_op_log; Type: TABLE DATA; Schema: camunda; Owner: -
--

COPY camunda.act_hi_op_log (id_, deployment_id_, proc_def_id_, proc_def_key_, root_proc_inst_id_, proc_inst_id_, execution_id_, case_def_id_, case_inst_id_, case_execution_id_, task_id_, job_id_, job_def_id_, batch_id_, user_id_, timestamp_, operation_type_, operation_id_, entity_type_, property_, org_value_, new_value_, tenant_id_, removal_time_, category_, external_task_id_, annotation_) FROM stdin;
\.
COPY camunda.act_hi_op_log (id_, deployment_id_, proc_def_id_, proc_def_key_, root_proc_inst_id_, proc_inst_id_, execution_id_, case_def_id_, case_inst_id_, case_execution_id_, task_id_, job_id_, job_def_id_, batch_id_, user_id_, timestamp_, operation_type_, operation_id_, entity_type_, property_, org_value_, new_value_, tenant_id_, removal_time_, category_, external_task_id_, annotation_) FROM '$$PATH$$/3911.dat';

--
-- Data for Name: act_hi_procinst; Type: TABLE DATA; Schema: camunda; Owner: -
--

COPY camunda.act_hi_procinst (id_, proc_inst_id_, business_key_, proc_def_key_, proc_def_id_, start_time_, end_time_, removal_time_, duration_, start_user_id_, start_act_id_, end_act_id_, super_process_instance_id_, root_proc_inst_id_, super_case_instance_id_, case_inst_id_, delete_reason_, tenant_id_, state_) FROM stdin;
\.
COPY camunda.act_hi_procinst (id_, proc_inst_id_, business_key_, proc_def_key_, proc_def_id_, start_time_, end_time_, removal_time_, duration_, start_user_id_, start_act_id_, end_act_id_, super_process_instance_id_, root_proc_inst_id_, super_case_instance_id_, case_inst_id_, delete_reason_, tenant_id_, state_) FROM '$$PATH$$/3903.dat';

--
-- Data for Name: act_hi_taskinst; Type: TABLE DATA; Schema: camunda; Owner: -
--

COPY camunda.act_hi_taskinst (id_, task_def_key_, proc_def_key_, proc_def_id_, root_proc_inst_id_, proc_inst_id_, execution_id_, case_def_key_, case_def_id_, case_inst_id_, case_execution_id_, act_inst_id_, name_, parent_task_id_, description_, owner_, assignee_, start_time_, end_time_, duration_, delete_reason_, priority_, due_date_, follow_up_date_, tenant_id_, removal_time_) FROM stdin;
\.
COPY camunda.act_hi_taskinst (id_, task_def_key_, proc_def_key_, proc_def_id_, root_proc_inst_id_, proc_inst_id_, execution_id_, case_def_key_, case_def_id_, case_inst_id_, case_execution_id_, act_inst_id_, name_, parent_task_id_, description_, owner_, assignee_, start_time_, end_time_, duration_, delete_reason_, priority_, due_date_, follow_up_date_, tenant_id_, removal_time_) FROM '$$PATH$$/3905.dat';

--
-- Data for Name: act_hi_varinst; Type: TABLE DATA; Schema: camunda; Owner: -
--

COPY camunda.act_hi_varinst (id_, proc_def_key_, proc_def_id_, root_proc_inst_id_, proc_inst_id_, execution_id_, act_inst_id_, case_def_key_, case_def_id_, case_inst_id_, case_execution_id_, task_id_, name_, var_type_, create_time_, rev_, bytearray_id_, double_, long_, text_, text2_, tenant_id_, state_, removal_time_) FROM stdin;
\.
COPY camunda.act_hi_varinst (id_, proc_def_key_, proc_def_id_, root_proc_inst_id_, proc_inst_id_, execution_id_, act_inst_id_, case_def_key_, case_def_id_, case_inst_id_, case_execution_id_, task_id_, name_, var_type_, create_time_, rev_, bytearray_id_, double_, long_, text_, text2_, tenant_id_, state_, removal_time_) FROM '$$PATH$$/3906.dat';

--
-- Data for Name: act_id_group; Type: TABLE DATA; Schema: camunda; Owner: -
--

COPY camunda.act_id_group (id_, rev_, name_, type_) FROM stdin;
\.
COPY camunda.act_id_group (id_, rev_, name_, type_) FROM '$$PATH$$/3916.dat';

--
-- Data for Name: act_id_info; Type: TABLE DATA; Schema: camunda; Owner: -
--

COPY camunda.act_id_info (id_, rev_, user_id_, type_, key_, value_, password_, parent_id_) FROM stdin;
\.
COPY camunda.act_id_info (id_, rev_, user_id_, type_, key_, value_, password_, parent_id_) FROM '$$PATH$$/3919.dat';

--
-- Data for Name: act_id_membership; Type: TABLE DATA; Schema: camunda; Owner: -
--

COPY camunda.act_id_membership (user_id_, group_id_) FROM stdin;
\.
COPY camunda.act_id_membership (user_id_, group_id_) FROM '$$PATH$$/3917.dat';

--
-- Data for Name: act_id_tenant; Type: TABLE DATA; Schema: camunda; Owner: -
--

COPY camunda.act_id_tenant (id_, rev_, name_) FROM stdin;
\.
COPY camunda.act_id_tenant (id_, rev_, name_) FROM '$$PATH$$/3920.dat';

--
-- Data for Name: act_id_tenant_member; Type: TABLE DATA; Schema: camunda; Owner: -
--

COPY camunda.act_id_tenant_member (id_, tenant_id_, user_id_, group_id_) FROM stdin;
\.
COPY camunda.act_id_tenant_member (id_, tenant_id_, user_id_, group_id_) FROM '$$PATH$$/3921.dat';

--
-- Data for Name: act_id_user; Type: TABLE DATA; Schema: camunda; Owner: -
--

COPY camunda.act_id_user (id_, rev_, first_, last_, email_, pwd_, salt_, lock_exp_time_, attempts_, picture_id_) FROM stdin;
\.
COPY camunda.act_id_user (id_, rev_, first_, last_, email_, pwd_, salt_, lock_exp_time_, attempts_, picture_id_) FROM '$$PATH$$/3918.dat';

--
-- Data for Name: act_re_camformdef; Type: TABLE DATA; Schema: camunda; Owner: -
--

COPY camunda.act_re_camformdef (id_, rev_, key_, version_, deployment_id_, resource_name_, tenant_id_) FROM stdin;
\.
COPY camunda.act_re_camformdef (id_, rev_, key_, version_, deployment_id_, resource_name_, tenant_id_) FROM '$$PATH$$/3891.dat';

--
-- Data for Name: act_re_case_def; Type: TABLE DATA; Schema: camunda; Owner: -
--

COPY camunda.act_re_case_def (id_, rev_, category_, name_, key_, version_, deployment_id_, resource_name_, dgrm_resource_name_, tenant_id_, history_ttl_) FROM stdin;
\.
COPY camunda.act_re_case_def (id_, rev_, category_, name_, key_, version_, deployment_id_, resource_name_, dgrm_resource_name_, tenant_id_, history_ttl_) FROM '$$PATH$$/3922.dat';

--
-- Data for Name: act_re_decision_def; Type: TABLE DATA; Schema: camunda; Owner: -
--

COPY camunda.act_re_decision_def (id_, rev_, category_, name_, key_, version_, deployment_id_, resource_name_, dgrm_resource_name_, dec_req_id_, dec_req_key_, tenant_id_, history_ttl_, version_tag_) FROM stdin;
\.
COPY camunda.act_re_decision_def (id_, rev_, category_, name_, key_, version_, deployment_id_, resource_name_, dgrm_resource_name_, dec_req_id_, dec_req_key_, tenant_id_, history_ttl_, version_tag_) FROM '$$PATH$$/3927.dat';

--
-- Data for Name: act_re_decision_req_def; Type: TABLE DATA; Schema: camunda; Owner: -
--

COPY camunda.act_re_decision_req_def (id_, rev_, category_, name_, key_, version_, deployment_id_, resource_name_, dgrm_resource_name_, tenant_id_) FROM stdin;
\.
COPY camunda.act_re_decision_req_def (id_, rev_, category_, name_, key_, version_, deployment_id_, resource_name_, dgrm_resource_name_, tenant_id_) FROM '$$PATH$$/3928.dat';

--
-- Data for Name: act_re_deployment; Type: TABLE DATA; Schema: camunda; Owner: -
--

COPY camunda.act_re_deployment (id_, name_, deploy_time_, source_, tenant_id_) FROM stdin;
\.
COPY camunda.act_re_deployment (id_, name_, deploy_time_, source_, tenant_id_) FROM '$$PATH$$/3886.dat';

--
-- Data for Name: act_re_procdef; Type: TABLE DATA; Schema: camunda; Owner: -
--

COPY camunda.act_re_procdef (id_, rev_, category_, name_, key_, version_, deployment_id_, resource_name_, dgrm_resource_name_, has_start_form_key_, suspension_state_, tenant_id_, version_tag_, history_ttl_, startable_) FROM stdin;
\.
COPY camunda.act_re_procdef (id_, rev_, category_, name_, key_, version_, deployment_id_, resource_name_, dgrm_resource_name_, has_start_form_key_, suspension_state_, tenant_id_, version_tag_, history_ttl_, startable_) FROM '$$PATH$$/3890.dat';

--
-- Data for Name: act_ru_authorization; Type: TABLE DATA; Schema: camunda; Owner: -
--

COPY camunda.act_ru_authorization (id_, rev_, type_, group_id_, user_id_, resource_type_, resource_id_, perms_, removal_time_, root_proc_inst_id_) FROM stdin;
\.
COPY camunda.act_ru_authorization (id_, rev_, type_, group_id_, user_id_, resource_type_, resource_id_, perms_, removal_time_, root_proc_inst_id_) FROM '$$PATH$$/3897.dat';

--
-- Data for Name: act_ru_batch; Type: TABLE DATA; Schema: camunda; Owner: -
--

COPY camunda.act_ru_batch (id_, rev_, type_, total_jobs_, jobs_created_, jobs_per_seed_, invocations_per_job_, seed_job_def_id_, batch_job_def_id_, monitor_job_def_id_, suspension_state_, configuration_, tenant_id_, create_user_id_, start_time_, exec_start_time_) FROM stdin;
\.
COPY camunda.act_ru_batch (id_, rev_, type_, total_jobs_, jobs_created_, jobs_per_seed_, invocations_per_job_, seed_job_def_id_, batch_job_def_id_, monitor_job_def_id_, suspension_state_, configuration_, tenant_id_, create_user_id_, start_time_, exec_start_time_) FROM '$$PATH$$/3902.dat';

--
-- Data for Name: act_ru_case_execution; Type: TABLE DATA; Schema: camunda; Owner: -
--

COPY camunda.act_ru_case_execution (id_, rev_, case_inst_id_, super_case_exec_, super_exec_, business_key_, parent_id_, case_def_id_, act_id_, prev_state_, current_state_, required_, tenant_id_) FROM stdin;
\.
COPY camunda.act_ru_case_execution (id_, rev_, case_inst_id_, super_case_exec_, super_exec_, business_key_, parent_id_, case_def_id_, act_id_, prev_state_, current_state_, required_, tenant_id_) FROM '$$PATH$$/3923.dat';

--
-- Data for Name: act_ru_case_sentry_part; Type: TABLE DATA; Schema: camunda; Owner: -
--

COPY camunda.act_ru_case_sentry_part (id_, rev_, case_inst_id_, case_exec_id_, sentry_id_, type_, source_case_exec_id_, standard_event_, source_, variable_event_, variable_name_, satisfied_, tenant_id_) FROM stdin;
\.
COPY camunda.act_ru_case_sentry_part (id_, rev_, case_inst_id_, case_exec_id_, sentry_id_, type_, source_case_exec_id_, standard_event_, source_, variable_event_, variable_name_, satisfied_, tenant_id_) FROM '$$PATH$$/3924.dat';

--
-- Data for Name: act_ru_event_subscr; Type: TABLE DATA; Schema: camunda; Owner: -
--

COPY camunda.act_ru_event_subscr (id_, rev_, event_type_, event_name_, execution_id_, proc_inst_id_, activity_id_, configuration_, created_, tenant_id_) FROM stdin;
\.
COPY camunda.act_ru_event_subscr (id_, rev_, event_type_, event_name_, execution_id_, proc_inst_id_, activity_id_, configuration_, created_, tenant_id_) FROM '$$PATH$$/3895.dat';

--
-- Data for Name: act_ru_execution; Type: TABLE DATA; Schema: camunda; Owner: -
--

COPY camunda.act_ru_execution (id_, rev_, root_proc_inst_id_, proc_inst_id_, business_key_, parent_id_, proc_def_id_, super_exec_, super_case_exec_, case_inst_id_, act_id_, act_inst_id_, is_active_, is_concurrent_, is_scope_, is_event_scope_, suspension_state_, cached_ent_state_, sequence_counter_, tenant_id_) FROM stdin;
\.
COPY camunda.act_ru_execution (id_, rev_, root_proc_inst_id_, proc_inst_id_, business_key_, parent_id_, proc_def_id_, super_exec_, super_case_exec_, case_inst_id_, act_id_, act_inst_id_, is_active_, is_concurrent_, is_scope_, is_event_scope_, suspension_state_, cached_ent_state_, sequence_counter_, tenant_id_) FROM '$$PATH$$/3887.dat';

--
-- Data for Name: act_ru_ext_task; Type: TABLE DATA; Schema: camunda; Owner: -
--

COPY camunda.act_ru_ext_task (id_, rev_, worker_id_, topic_name_, retries_, error_msg_, error_details_id_, lock_exp_time_, suspension_state_, execution_id_, proc_inst_id_, proc_def_id_, proc_def_key_, act_id_, act_inst_id_, tenant_id_, priority_, last_failure_log_id_) FROM stdin;
\.
COPY camunda.act_ru_ext_task (id_, rev_, worker_id_, topic_name_, retries_, error_msg_, error_details_id_, lock_exp_time_, suspension_state_, execution_id_, proc_inst_id_, proc_def_id_, proc_def_key_, act_id_, act_inst_id_, tenant_id_, priority_, last_failure_log_id_) FROM '$$PATH$$/3901.dat';

--
-- Data for Name: act_ru_filter; Type: TABLE DATA; Schema: camunda; Owner: -
--

COPY camunda.act_ru_filter (id_, rev_, resource_type_, name_, owner_, query_, properties_) FROM stdin;
\.
COPY camunda.act_ru_filter (id_, rev_, resource_type_, name_, owner_, query_, properties_) FROM '$$PATH$$/3898.dat';

--
-- Data for Name: act_ru_identitylink; Type: TABLE DATA; Schema: camunda; Owner: -
--

COPY camunda.act_ru_identitylink (id_, rev_, group_id_, type_, user_id_, task_id_, proc_def_id_, tenant_id_) FROM stdin;
\.
COPY camunda.act_ru_identitylink (id_, rev_, group_id_, type_, user_id_, task_id_, proc_def_id_, tenant_id_) FROM '$$PATH$$/3893.dat';

--
-- Data for Name: act_ru_incident; Type: TABLE DATA; Schema: camunda; Owner: -
--

COPY camunda.act_ru_incident (id_, rev_, incident_timestamp_, incident_msg_, incident_type_, execution_id_, activity_id_, failed_activity_id_, proc_inst_id_, proc_def_id_, cause_incident_id_, root_cause_incident_id_, configuration_, tenant_id_, job_def_id_, annotation_) FROM stdin;
\.
COPY camunda.act_ru_incident (id_, rev_, incident_timestamp_, incident_msg_, incident_type_, execution_id_, activity_id_, failed_activity_id_, proc_inst_id_, proc_def_id_, cause_incident_id_, root_cause_incident_id_, configuration_, tenant_id_, job_def_id_, annotation_) FROM '$$PATH$$/3896.dat';

--
-- Data for Name: act_ru_job; Type: TABLE DATA; Schema: camunda; Owner: -
--

COPY camunda.act_ru_job (id_, rev_, type_, lock_exp_time_, lock_owner_, exclusive_, execution_id_, process_instance_id_, process_def_id_, process_def_key_, retries_, exception_stack_id_, exception_msg_, failed_act_id_, duedate_, repeat_, repeat_offset_, handler_type_, handler_cfg_, deployment_id_, suspension_state_, job_def_id_, priority_, sequence_counter_, tenant_id_, create_time_, last_failure_log_id_) FROM stdin;
\.
COPY camunda.act_ru_job (id_, rev_, type_, lock_exp_time_, lock_owner_, exclusive_, execution_id_, process_instance_id_, process_def_id_, process_def_key_, retries_, exception_stack_id_, exception_msg_, failed_act_id_, duedate_, repeat_, repeat_offset_, handler_type_, handler_cfg_, deployment_id_, suspension_state_, job_def_id_, priority_, sequence_counter_, tenant_id_, create_time_, last_failure_log_id_) FROM '$$PATH$$/3888.dat';

--
-- Data for Name: act_ru_jobdef; Type: TABLE DATA; Schema: camunda; Owner: -
--

COPY camunda.act_ru_jobdef (id_, rev_, proc_def_id_, proc_def_key_, act_id_, job_type_, job_configuration_, suspension_state_, job_priority_, tenant_id_, deployment_id_) FROM stdin;
\.
COPY camunda.act_ru_jobdef (id_, rev_, proc_def_id_, proc_def_key_, act_id_, job_type_, job_configuration_, suspension_state_, job_priority_, tenant_id_, deployment_id_) FROM '$$PATH$$/3889.dat';

--
-- Data for Name: act_ru_meter_log; Type: TABLE DATA; Schema: camunda; Owner: -
--

COPY camunda.act_ru_meter_log (id_, name_, reporter_, value_, timestamp_, milliseconds_) FROM stdin;
\.
COPY camunda.act_ru_meter_log (id_, name_, reporter_, value_, timestamp_, milliseconds_) FROM '$$PATH$$/3899.dat';

--
-- Data for Name: act_ru_task; Type: TABLE DATA; Schema: camunda; Owner: -
--

COPY camunda.act_ru_task (id_, rev_, execution_id_, proc_inst_id_, proc_def_id_, case_execution_id_, case_inst_id_, case_def_id_, name_, parent_task_id_, description_, task_def_key_, owner_, assignee_, delegation_, priority_, create_time_, last_updated_, due_date_, follow_up_date_, suspension_state_, tenant_id_) FROM stdin;
\.
COPY camunda.act_ru_task (id_, rev_, execution_id_, proc_inst_id_, proc_def_id_, case_execution_id_, case_inst_id_, case_def_id_, name_, parent_task_id_, description_, task_def_key_, owner_, assignee_, delegation_, priority_, create_time_, last_updated_, due_date_, follow_up_date_, suspension_state_, tenant_id_) FROM '$$PATH$$/3892.dat';

--
-- Data for Name: act_ru_task_meter_log; Type: TABLE DATA; Schema: camunda; Owner: -
--

COPY camunda.act_ru_task_meter_log (id_, assignee_hash_, timestamp_) FROM stdin;
\.
COPY camunda.act_ru_task_meter_log (id_, assignee_hash_, timestamp_) FROM '$$PATH$$/3900.dat';

--
-- Data for Name: act_ru_variable; Type: TABLE DATA; Schema: camunda; Owner: -
--

COPY camunda.act_ru_variable (id_, rev_, type_, name_, execution_id_, proc_inst_id_, proc_def_id_, case_execution_id_, case_inst_id_, task_id_, batch_id_, bytearray_id_, double_, long_, text_, text2_, var_scope_, sequence_counter_, is_concurrent_local_, tenant_id_) FROM stdin;
\.
COPY camunda.act_ru_variable (id_, rev_, type_, name_, execution_id_, proc_inst_id_, proc_def_id_, case_execution_id_, case_inst_id_, task_id_, batch_id_, bytearray_id_, double_, long_, text_, text2_, var_scope_, sequence_counter_, is_concurrent_local_, tenant_id_) FROM '$$PATH$$/3894.dat';

--
-- Data for Name: request; Type: TABLE DATA; Schema: crm_request; Owner: -
--

COPY crm_request.request (id, s_number, d_date, id_contractor, s_description, s_state_code, d_release_date) FROM stdin;
\.
COPY crm_request.request (id, s_number, d_date, id_contractor, s_description, s_state_code, d_release_date) FROM '$$PATH$$/3878.dat';

--
-- Data for Name: request_item; Type: TABLE DATA; Schema: crm_request; Owner: -
--

COPY crm_request.request_item (id, id_request, id_product, f_quantity, f_quantity_exec) FROM stdin;
\.
COPY crm_request.request_item (id, id_request, id_product, f_quantity, f_quantity_exec) FROM '$$PATH$$/3880.dat';

--
-- Data for Name: request_states; Type: TABLE DATA; Schema: crm_request; Owner: -
--

COPY crm_request.request_states (s_code, s_caption) FROM stdin;
\.
COPY crm_request.request_states (s_code, s_caption) FROM '$$PATH$$/3882.dat';

--
-- Data for Name: contractor; Type: TABLE DATA; Schema: dictionaries; Owner: -
--

COPY dictionaries.contractor (id, s_inn, s_caption) FROM stdin;
\.
COPY dictionaries.contractor (id, s_inn, s_caption) FROM '$$PATH$$/3876.dat';

--
-- Data for Name: products; Type: TABLE DATA; Schema: dictionaries; Owner: -
--

COPY dictionaries.products (id, s_code, s_caption, n_milling_time, n_lathe_time) FROM stdin;
\.
COPY dictionaries.products (id, s_code, s_caption, n_milling_time, n_lathe_time) FROM '$$PATH$$/3869.dat';

--
-- Data for Name: component; Type: TABLE DATA; Schema: uni_component; Owner: -
--

COPY uni_component.component (id, s_name, s_caption, s_description, id_parent) FROM stdin;
\.
COPY uni_component.component (id, s_name, s_caption, s_description, id_parent) FROM '$$PATH$$/3865.dat';

--
-- Data for Name: error; Type: TABLE DATA; Schema: uni_error; Owner: -
--

COPY uni_error.error (id, s_name, s_caption, s_description, d_created, d_edited, id_component) FROM stdin;
\.
COPY uni_error.error (id, s_name, s_caption, s_description, d_created, d_edited, id_component) FROM '$$PATH$$/3866.dat';

--
-- Name: seq_request; Type: SEQUENCE SET; Schema: crm_request; Owner: -
--

SELECT pg_catalog.setval('crm_request.seq_request', 318, true);


--
-- Name: seq_request_item; Type: SEQUENCE SET; Schema: crm_request; Owner: -
--

SELECT pg_catalog.setval('crm_request.seq_request_item', 2022, true);


--
-- Name: seq_request_number; Type: SEQUENCE SET; Schema: crm_request; Owner: -
--

SELECT pg_catalog.setval('crm_request.seq_request_number', 313, true);


--
-- Name: seq_blanks; Type: SEQUENCE SET; Schema: dictionaries; Owner: -
--

SELECT pg_catalog.setval('dictionaries.seq_blanks', 1, false);


--
-- Name: seq_contractor; Type: SEQUENCE SET; Schema: dictionaries; Owner: -
--

SELECT pg_catalog.setval('dictionaries.seq_contractor', 20, true);


--
-- Name: seq_material; Type: SEQUENCE SET; Schema: dictionaries; Owner: -
--

SELECT pg_catalog.setval('dictionaries.seq_material', 1, false);


--
-- Name: seq_materials_in_blanks; Type: SEQUENCE SET; Schema: dictionaries; Owner: -
--

SELECT pg_catalog.setval('dictionaries.seq_materials_in_blanks', 1, false);


--
-- Name: seq_product_composition; Type: SEQUENCE SET; Schema: dictionaries; Owner: -
--

SELECT pg_catalog.setval('dictionaries.seq_product_composition', 1, false);


--
-- Name: seq_products; Type: SEQUENCE SET; Schema: dictionaries; Owner: -
--

SELECT pg_catalog.setval('dictionaries.seq_products', 1900, true);


--
-- Name: seq_component; Type: SEQUENCE SET; Schema: uni_component; Owner: -
--

SELECT pg_catalog.setval('uni_component.seq_component', 9, true);


--
-- Name: seq_error; Type: SEQUENCE SET; Schema: uni_error; Owner: -
--

SELECT pg_catalog.setval('uni_error.seq_error', 23, true);


--
-- Name: act_id_membership act_id_membership_pkey; Type: CONSTRAINT; Schema: camunda; Owner: -
--

ALTER TABLE ONLY camunda.act_id_membership
    ADD CONSTRAINT act_id_membership_pkey PRIMARY KEY (user_id_, group_id_);


--
-- Name: act_idx_hi_act_inst_comp; Type: INDEX; Schema: camunda; Owner: -
--

CREATE INDEX act_idx_hi_act_inst_comp ON camunda.act_hi_actinst USING btree (execution_id_, act_id_, end_time_, id_);


--
-- Name: act_idx_hi_act_inst_procinst; Type: INDEX; Schema: camunda; Owner: -
--

CREATE INDEX act_idx_hi_act_inst_procinst ON camunda.act_hi_actinst USING btree (proc_inst_id_, act_id_);


--
-- Name: act_idx_hi_act_inst_start_end; Type: INDEX; Schema: camunda; Owner: -
--

CREATE INDEX act_idx_hi_act_inst_start_end ON camunda.act_hi_actinst USING btree (start_time_, end_time_);


--
-- Name: act_idx_hi_act_inst_stats; Type: INDEX; Schema: camunda; Owner: -
--

CREATE INDEX act_idx_hi_act_inst_stats ON camunda.act_hi_actinst USING btree (proc_def_id_, proc_inst_id_, act_id_, end_time_, act_inst_state_);


--
-- Name: act_idx_hi_ai_pdefid_end_time; Type: INDEX; Schema: camunda; Owner: -
--

CREATE INDEX act_idx_hi_ai_pdefid_end_time ON camunda.act_hi_actinst USING btree (proc_def_id_, end_time_);


--
-- Name: act_idx_hi_cas_a_i_comp; Type: INDEX; Schema: camunda; Owner: -
--

CREATE INDEX act_idx_hi_cas_a_i_comp ON camunda.act_hi_caseactinst USING btree (case_act_id_, end_time_, id_);


--
-- Name: act_idx_hi_dec_in_clause; Type: INDEX; Schema: camunda; Owner: -
--

CREATE INDEX act_idx_hi_dec_in_clause ON camunda.act_hi_dec_in USING btree (dec_inst_id_, clause_id_);


--
-- Name: act_idx_hi_dec_out_rule; Type: INDEX; Schema: camunda; Owner: -
--

CREATE INDEX act_idx_hi_dec_out_rule ON camunda.act_hi_dec_out USING btree (rule_order_, clause_id_);


--
-- Name: act_idx_hi_detail_task_bytear; Type: INDEX; Schema: camunda; Owner: -
--

CREATE INDEX act_idx_hi_detail_task_bytear ON camunda.act_hi_detail USING btree (bytearray_id_, task_id_);


--
-- Name: act_idx_hi_pi_pdefid_end_time; Type: INDEX; Schema: camunda; Owner: -
--

CREATE INDEX act_idx_hi_pi_pdefid_end_time ON camunda.act_hi_procinst USING btree (proc_def_id_, end_time_);


--
-- Name: act_idx_hi_pro_inst_proc_time; Type: INDEX; Schema: camunda; Owner: -
--

CREATE INDEX act_idx_hi_pro_inst_proc_time ON camunda.act_hi_procinst USING btree (start_time_, end_time_);


--
-- Name: act_idx_hi_procvar_name_type; Type: INDEX; Schema: camunda; Owner: -
--

CREATE INDEX act_idx_hi_procvar_name_type ON camunda.act_hi_varinst USING btree (name_, var_type_);


--
-- Name: act_idx_hi_taskinstid_procinst; Type: INDEX; Schema: camunda; Owner: -
--

CREATE INDEX act_idx_hi_taskinstid_procinst ON camunda.act_hi_taskinst USING btree (id_, proc_inst_id_);


--
-- Name: act_idx_hi_var_pi_name_type; Type: INDEX; Schema: camunda; Owner: -
--

CREATE INDEX act_idx_hi_var_pi_name_type ON camunda.act_hi_varinst USING btree (proc_inst_id_, name_, var_type_);


--
-- Name: act_idx_job_handler; Type: INDEX; Schema: camunda; Owner: -
--

CREATE INDEX act_idx_job_handler ON camunda.act_ru_job USING btree (handler_type_, handler_cfg_);


--
-- Name: act_idx_meter_log; Type: INDEX; Schema: camunda; Owner: -
--

CREATE INDEX act_idx_meter_log ON camunda.act_ru_meter_log USING btree (name_, timestamp_);


--
-- Name: act_idx_meter_log_name_ms; Type: INDEX; Schema: camunda; Owner: -
--

CREATE INDEX act_idx_meter_log_name_ms ON camunda.act_ru_meter_log USING btree (name_, milliseconds_);


--
-- Name: act_idx_meter_log_report; Type: INDEX; Schema: camunda; Owner: -
--

CREATE INDEX act_idx_meter_log_report ON camunda.act_ru_meter_log USING btree (name_, reporter_, milliseconds_);


--
-- Name: act_idx_variable_task_name_type; Type: INDEX; Schema: camunda; Owner: -
--

CREATE INDEX act_idx_variable_task_name_type ON camunda.act_ru_variable USING btree (task_id_, name_, type_);


--
-- Name: act_ru_authorization act_uniq_auth_group; Type: CONSTRAINT; Schema: camunda; Owner: -
--

ALTER TABLE ONLY camunda.act_ru_authorization
    ADD CONSTRAINT act_uniq_auth_group UNIQUE (type_, group_id_, resource_type_, resource_id_);


--
-- Name: act_ru_authorization act_uniq_auth_user; Type: CONSTRAINT; Schema: camunda; Owner: -
--

ALTER TABLE ONLY camunda.act_ru_authorization
    ADD CONSTRAINT act_uniq_auth_user UNIQUE (type_, user_id_, resource_type_, resource_id_);


--
-- Name: act_id_tenant_member act_uniq_tenant_memb_group; Type: CONSTRAINT; Schema: camunda; Owner: -
--

ALTER TABLE ONLY camunda.act_id_tenant_member
    ADD CONSTRAINT act_uniq_tenant_memb_group UNIQUE (tenant_id_, group_id_);


--
-- Name: act_id_tenant_member act_uniq_tenant_memb_user; Type: CONSTRAINT; Schema: camunda; Owner: -
--

ALTER TABLE ONLY camunda.act_id_tenant_member
    ADD CONSTRAINT act_uniq_tenant_memb_user UNIQUE (tenant_id_, user_id_);


--
-- Name: act_ru_variable act_uniq_variable; Type: CONSTRAINT; Schema: camunda; Owner: -
--

ALTER TABLE ONLY camunda.act_ru_variable
    ADD CONSTRAINT act_uniq_variable UNIQUE (var_scope_, name_);


--
-- Name: udx_request_item_id_request_id_product; Type: INDEX; Schema: crm_request; Owner: -
--

CREATE UNIQUE INDEX udx_request_item_id_request_id_product ON crm_request.request_item USING btree (id_request, id_product);


--
-- Name: act_ge_bytearray act_ge_bytearray_pkey; Type: CONSTRAINT; Schema: camunda; Owner: -
--

ALTER TABLE ONLY camunda.act_ge_bytearray
    ADD CONSTRAINT act_ge_bytearray_pkey PRIMARY KEY (id_);


--
-- Name: act_ge_property act_ge_property_pkey; Type: CONSTRAINT; Schema: camunda; Owner: -
--

ALTER TABLE ONLY camunda.act_ge_property
    ADD CONSTRAINT act_ge_property_pkey PRIMARY KEY (name_);


--
-- Name: act_ge_schema_log act_ge_schema_log_pkey; Type: CONSTRAINT; Schema: camunda; Owner: -
--

ALTER TABLE ONLY camunda.act_ge_schema_log
    ADD CONSTRAINT act_ge_schema_log_pkey PRIMARY KEY (id_);


--
-- Name: act_hi_actinst act_hi_actinst_pkey; Type: CONSTRAINT; Schema: camunda; Owner: -
--

ALTER TABLE ONLY camunda.act_hi_actinst
    ADD CONSTRAINT act_hi_actinst_pkey PRIMARY KEY (id_);


--
-- Name: act_hi_attachment act_hi_attachment_pkey; Type: CONSTRAINT; Schema: camunda; Owner: -
--

ALTER TABLE ONLY camunda.act_hi_attachment
    ADD CONSTRAINT act_hi_attachment_pkey PRIMARY KEY (id_);


--
-- Name: act_hi_batch act_hi_batch_pkey; Type: CONSTRAINT; Schema: camunda; Owner: -
--

ALTER TABLE ONLY camunda.act_hi_batch
    ADD CONSTRAINT act_hi_batch_pkey PRIMARY KEY (id_);


--
-- Name: act_hi_caseactinst act_hi_caseactinst_pkey; Type: CONSTRAINT; Schema: camunda; Owner: -
--

ALTER TABLE ONLY camunda.act_hi_caseactinst
    ADD CONSTRAINT act_hi_caseactinst_pkey PRIMARY KEY (id_);


--
-- Name: act_hi_caseinst act_hi_caseinst_case_inst_id__key; Type: CONSTRAINT; Schema: camunda; Owner: -
--

ALTER TABLE ONLY camunda.act_hi_caseinst
    ADD CONSTRAINT act_hi_caseinst_case_inst_id__key UNIQUE (case_inst_id_);


--
-- Name: act_hi_caseinst act_hi_caseinst_pkey; Type: CONSTRAINT; Schema: camunda; Owner: -
--

ALTER TABLE ONLY camunda.act_hi_caseinst
    ADD CONSTRAINT act_hi_caseinst_pkey PRIMARY KEY (id_);


--
-- Name: act_hi_comment act_hi_comment_pkey; Type: CONSTRAINT; Schema: camunda; Owner: -
--

ALTER TABLE ONLY camunda.act_hi_comment
    ADD CONSTRAINT act_hi_comment_pkey PRIMARY KEY (id_);


--
-- Name: act_hi_dec_in act_hi_dec_in_pkey; Type: CONSTRAINT; Schema: camunda; Owner: -
--

ALTER TABLE ONLY camunda.act_hi_dec_in
    ADD CONSTRAINT act_hi_dec_in_pkey PRIMARY KEY (id_);


--
-- Name: act_hi_dec_out act_hi_dec_out_pkey; Type: CONSTRAINT; Schema: camunda; Owner: -
--

ALTER TABLE ONLY camunda.act_hi_dec_out
    ADD CONSTRAINT act_hi_dec_out_pkey PRIMARY KEY (id_);


--
-- Name: act_hi_decinst act_hi_decinst_pkey; Type: CONSTRAINT; Schema: camunda; Owner: -
--

ALTER TABLE ONLY camunda.act_hi_decinst
    ADD CONSTRAINT act_hi_decinst_pkey PRIMARY KEY (id_);


--
-- Name: act_hi_detail act_hi_detail_pkey; Type: CONSTRAINT; Schema: camunda; Owner: -
--

ALTER TABLE ONLY camunda.act_hi_detail
    ADD CONSTRAINT act_hi_detail_pkey PRIMARY KEY (id_);


--
-- Name: act_hi_ext_task_log act_hi_ext_task_log_pkey; Type: CONSTRAINT; Schema: camunda; Owner: -
--

ALTER TABLE ONLY camunda.act_hi_ext_task_log
    ADD CONSTRAINT act_hi_ext_task_log_pkey PRIMARY KEY (id_);


--
-- Name: act_hi_identitylink act_hi_identitylink_pkey; Type: CONSTRAINT; Schema: camunda; Owner: -
--

ALTER TABLE ONLY camunda.act_hi_identitylink
    ADD CONSTRAINT act_hi_identitylink_pkey PRIMARY KEY (id_);


--
-- Name: act_hi_incident act_hi_incident_pkey; Type: CONSTRAINT; Schema: camunda; Owner: -
--

ALTER TABLE ONLY camunda.act_hi_incident
    ADD CONSTRAINT act_hi_incident_pkey PRIMARY KEY (id_);


--
-- Name: act_hi_job_log act_hi_job_log_pkey; Type: CONSTRAINT; Schema: camunda; Owner: -
--

ALTER TABLE ONLY camunda.act_hi_job_log
    ADD CONSTRAINT act_hi_job_log_pkey PRIMARY KEY (id_);


--
-- Name: act_hi_op_log act_hi_op_log_pkey; Type: CONSTRAINT; Schema: camunda; Owner: -
--

ALTER TABLE ONLY camunda.act_hi_op_log
    ADD CONSTRAINT act_hi_op_log_pkey PRIMARY KEY (id_);


--
-- Name: act_hi_procinst act_hi_procinst_pkey; Type: CONSTRAINT; Schema: camunda; Owner: -
--

ALTER TABLE ONLY camunda.act_hi_procinst
    ADD CONSTRAINT act_hi_procinst_pkey PRIMARY KEY (id_);


--
-- Name: act_hi_procinst act_hi_procinst_proc_inst_id__key; Type: CONSTRAINT; Schema: camunda; Owner: -
--

ALTER TABLE ONLY camunda.act_hi_procinst
    ADD CONSTRAINT act_hi_procinst_proc_inst_id__key UNIQUE (proc_inst_id_);


--
-- Name: act_hi_taskinst act_hi_taskinst_pkey; Type: CONSTRAINT; Schema: camunda; Owner: -
--

ALTER TABLE ONLY camunda.act_hi_taskinst
    ADD CONSTRAINT act_hi_taskinst_pkey PRIMARY KEY (id_);


--
-- Name: act_hi_varinst act_hi_varinst_pkey; Type: CONSTRAINT; Schema: camunda; Owner: -
--

ALTER TABLE ONLY camunda.act_hi_varinst
    ADD CONSTRAINT act_hi_varinst_pkey PRIMARY KEY (id_);


--
-- Name: act_id_group act_id_group_pkey; Type: CONSTRAINT; Schema: camunda; Owner: -
--

ALTER TABLE ONLY camunda.act_id_group
    ADD CONSTRAINT act_id_group_pkey PRIMARY KEY (id_);


--
-- Name: act_id_info act_id_info_pkey; Type: CONSTRAINT; Schema: camunda; Owner: -
--

ALTER TABLE ONLY camunda.act_id_info
    ADD CONSTRAINT act_id_info_pkey PRIMARY KEY (id_);


--
-- Name: act_id_tenant_member act_id_tenant_member_pkey; Type: CONSTRAINT; Schema: camunda; Owner: -
--

ALTER TABLE ONLY camunda.act_id_tenant_member
    ADD CONSTRAINT act_id_tenant_member_pkey PRIMARY KEY (id_);


--
-- Name: act_id_tenant act_id_tenant_pkey; Type: CONSTRAINT; Schema: camunda; Owner: -
--

ALTER TABLE ONLY camunda.act_id_tenant
    ADD CONSTRAINT act_id_tenant_pkey PRIMARY KEY (id_);


--
-- Name: act_id_user act_id_user_pkey; Type: CONSTRAINT; Schema: camunda; Owner: -
--

ALTER TABLE ONLY camunda.act_id_user
    ADD CONSTRAINT act_id_user_pkey PRIMARY KEY (id_);


--
-- Name: act_re_camformdef act_re_camformdef_pkey; Type: CONSTRAINT; Schema: camunda; Owner: -
--

ALTER TABLE ONLY camunda.act_re_camformdef
    ADD CONSTRAINT act_re_camformdef_pkey PRIMARY KEY (id_);


--
-- Name: act_re_case_def act_re_case_def_pkey; Type: CONSTRAINT; Schema: camunda; Owner: -
--

ALTER TABLE ONLY camunda.act_re_case_def
    ADD CONSTRAINT act_re_case_def_pkey PRIMARY KEY (id_);


--
-- Name: act_re_decision_def act_re_decision_def_pkey; Type: CONSTRAINT; Schema: camunda; Owner: -
--

ALTER TABLE ONLY camunda.act_re_decision_def
    ADD CONSTRAINT act_re_decision_def_pkey PRIMARY KEY (id_);


--
-- Name: act_re_decision_req_def act_re_decision_req_def_pkey; Type: CONSTRAINT; Schema: camunda; Owner: -
--

ALTER TABLE ONLY camunda.act_re_decision_req_def
    ADD CONSTRAINT act_re_decision_req_def_pkey PRIMARY KEY (id_);


--
-- Name: act_re_deployment act_re_deployment_pkey; Type: CONSTRAINT; Schema: camunda; Owner: -
--

ALTER TABLE ONLY camunda.act_re_deployment
    ADD CONSTRAINT act_re_deployment_pkey PRIMARY KEY (id_);


--
-- Name: act_re_procdef act_re_procdef_pkey; Type: CONSTRAINT; Schema: camunda; Owner: -
--

ALTER TABLE ONLY camunda.act_re_procdef
    ADD CONSTRAINT act_re_procdef_pkey PRIMARY KEY (id_);


--
-- Name: act_ru_authorization act_ru_authorization_pkey; Type: CONSTRAINT; Schema: camunda; Owner: -
--

ALTER TABLE ONLY camunda.act_ru_authorization
    ADD CONSTRAINT act_ru_authorization_pkey PRIMARY KEY (id_);


--
-- Name: act_ru_batch act_ru_batch_pkey; Type: CONSTRAINT; Schema: camunda; Owner: -
--

ALTER TABLE ONLY camunda.act_ru_batch
    ADD CONSTRAINT act_ru_batch_pkey PRIMARY KEY (id_);


--
-- Name: act_ru_case_execution act_ru_case_execution_pkey; Type: CONSTRAINT; Schema: camunda; Owner: -
--

ALTER TABLE ONLY camunda.act_ru_case_execution
    ADD CONSTRAINT act_ru_case_execution_pkey PRIMARY KEY (id_);


--
-- Name: act_ru_case_sentry_part act_ru_case_sentry_part_pkey; Type: CONSTRAINT; Schema: camunda; Owner: -
--

ALTER TABLE ONLY camunda.act_ru_case_sentry_part
    ADD CONSTRAINT act_ru_case_sentry_part_pkey PRIMARY KEY (id_);


--
-- Name: act_ru_event_subscr act_ru_event_subscr_pkey; Type: CONSTRAINT; Schema: camunda; Owner: -
--

ALTER TABLE ONLY camunda.act_ru_event_subscr
    ADD CONSTRAINT act_ru_event_subscr_pkey PRIMARY KEY (id_);


--
-- Name: act_ru_execution act_ru_execution_pkey; Type: CONSTRAINT; Schema: camunda; Owner: -
--

ALTER TABLE ONLY camunda.act_ru_execution
    ADD CONSTRAINT act_ru_execution_pkey PRIMARY KEY (id_);


--
-- Name: act_ru_ext_task act_ru_ext_task_pkey; Type: CONSTRAINT; Schema: camunda; Owner: -
--

ALTER TABLE ONLY camunda.act_ru_ext_task
    ADD CONSTRAINT act_ru_ext_task_pkey PRIMARY KEY (id_);


--
-- Name: act_ru_filter act_ru_filter_pkey; Type: CONSTRAINT; Schema: camunda; Owner: -
--

ALTER TABLE ONLY camunda.act_ru_filter
    ADD CONSTRAINT act_ru_filter_pkey PRIMARY KEY (id_);


--
-- Name: act_ru_identitylink act_ru_identitylink_pkey; Type: CONSTRAINT; Schema: camunda; Owner: -
--

ALTER TABLE ONLY camunda.act_ru_identitylink
    ADD CONSTRAINT act_ru_identitylink_pkey PRIMARY KEY (id_);


--
-- Name: act_ru_incident act_ru_incident_pkey; Type: CONSTRAINT; Schema: camunda; Owner: -
--

ALTER TABLE ONLY camunda.act_ru_incident
    ADD CONSTRAINT act_ru_incident_pkey PRIMARY KEY (id_);


--
-- Name: act_ru_job act_ru_job_pkey; Type: CONSTRAINT; Schema: camunda; Owner: -
--

ALTER TABLE ONLY camunda.act_ru_job
    ADD CONSTRAINT act_ru_job_pkey PRIMARY KEY (id_);


--
-- Name: act_ru_jobdef act_ru_jobdef_pkey; Type: CONSTRAINT; Schema: camunda; Owner: -
--

ALTER TABLE ONLY camunda.act_ru_jobdef
    ADD CONSTRAINT act_ru_jobdef_pkey PRIMARY KEY (id_);


--
-- Name: act_ru_meter_log act_ru_meter_log_pkey; Type: CONSTRAINT; Schema: camunda; Owner: -
--

ALTER TABLE ONLY camunda.act_ru_meter_log
    ADD CONSTRAINT act_ru_meter_log_pkey PRIMARY KEY (id_);


--
-- Name: act_ru_task_meter_log act_ru_task_meter_log_pkey; Type: CONSTRAINT; Schema: camunda; Owner: -
--

ALTER TABLE ONLY camunda.act_ru_task_meter_log
    ADD CONSTRAINT act_ru_task_meter_log_pkey PRIMARY KEY (id_);


--
-- Name: act_ru_task act_ru_task_pkey; Type: CONSTRAINT; Schema: camunda; Owner: -
--

ALTER TABLE ONLY camunda.act_ru_task
    ADD CONSTRAINT act_ru_task_pkey PRIMARY KEY (id_);


--
-- Name: act_ru_variable act_ru_variable_pkey; Type: CONSTRAINT; Schema: camunda; Owner: -
--

ALTER TABLE ONLY camunda.act_ru_variable
    ADD CONSTRAINT act_ru_variable_pkey PRIMARY KEY (id_);


--
-- Name: request pk_request; Type: CONSTRAINT; Schema: crm_request; Owner: -
--

ALTER TABLE ONLY crm_request.request
    ADD CONSTRAINT pk_request PRIMARY KEY (id);


--
-- Name: request_item pk_request_item; Type: CONSTRAINT; Schema: crm_request; Owner: -
--

ALTER TABLE ONLY crm_request.request_item
    ADD CONSTRAINT pk_request_item PRIMARY KEY (id);


--
-- Name: request_states pk_request_states; Type: CONSTRAINT; Schema: crm_request; Owner: -
--

ALTER TABLE ONLY crm_request.request_states
    ADD CONSTRAINT pk_request_states PRIMARY KEY (s_code);


--
-- Name: contractor pk_contractor; Type: CONSTRAINT; Schema: dictionaries; Owner: -
--

ALTER TABLE ONLY dictionaries.contractor
    ADD CONSTRAINT pk_contractor PRIMARY KEY (id);


--
-- Name: products pk_products; Type: CONSTRAINT; Schema: dictionaries; Owner: -
--

ALTER TABLE ONLY dictionaries.products
    ADD CONSTRAINT pk_products PRIMARY KEY (id);


--
-- Name: component pk_component_id; Type: CONSTRAINT; Schema: uni_component; Owner: -
--

ALTER TABLE ONLY uni_component.component
    ADD CONSTRAINT pk_component_id PRIMARY KEY (id);


--
-- Name: error pk_defaulterror; Type: CONSTRAINT; Schema: uni_error; Owner: -
--

ALTER TABLE ONLY uni_error.error
    ADD CONSTRAINT pk_defaulterror PRIMARY KEY (id);


--
-- Name: act_hi_bat_rm_time; Type: INDEX; Schema: camunda; Owner: -
--

CREATE INDEX act_hi_bat_rm_time ON camunda.act_hi_batch USING btree (removal_time_);


--
-- Name: act_hi_ext_task_log_proc_def_key; Type: INDEX; Schema: camunda; Owner: -
--

CREATE INDEX act_hi_ext_task_log_proc_def_key ON camunda.act_hi_ext_task_log USING btree (proc_def_key_);


--
-- Name: act_hi_ext_task_log_procdef; Type: INDEX; Schema: camunda; Owner: -
--

CREATE INDEX act_hi_ext_task_log_procdef ON camunda.act_hi_ext_task_log USING btree (proc_def_id_);


--
-- Name: act_hi_ext_task_log_procinst; Type: INDEX; Schema: camunda; Owner: -
--

CREATE INDEX act_hi_ext_task_log_procinst ON camunda.act_hi_ext_task_log USING btree (proc_inst_id_);


--
-- Name: act_hi_ext_task_log_rm_time; Type: INDEX; Schema: camunda; Owner: -
--

CREATE INDEX act_hi_ext_task_log_rm_time ON camunda.act_hi_ext_task_log USING btree (removal_time_);


--
-- Name: act_hi_ext_task_log_root_pi; Type: INDEX; Schema: camunda; Owner: -
--

CREATE INDEX act_hi_ext_task_log_root_pi ON camunda.act_hi_ext_task_log USING btree (root_proc_inst_id_);


--
-- Name: act_hi_ext_task_log_tenant_id; Type: INDEX; Schema: camunda; Owner: -
--

CREATE INDEX act_hi_ext_task_log_tenant_id ON camunda.act_hi_ext_task_log USING btree (tenant_id_);


--
-- Name: act_idx_athrz_procedef; Type: INDEX; Schema: camunda; Owner: -
--

CREATE INDEX act_idx_athrz_procedef ON camunda.act_ru_identitylink USING btree (proc_def_id_);


--
-- Name: act_idx_auth_group_id; Type: INDEX; Schema: camunda; Owner: -
--

CREATE INDEX act_idx_auth_group_id ON camunda.act_ru_authorization USING btree (group_id_);


--
-- Name: act_idx_auth_resource_id; Type: INDEX; Schema: camunda; Owner: -
--

CREATE INDEX act_idx_auth_resource_id ON camunda.act_ru_authorization USING btree (resource_id_);


--
-- Name: act_idx_auth_rm_time; Type: INDEX; Schema: camunda; Owner: -
--

CREATE INDEX act_idx_auth_rm_time ON camunda.act_ru_authorization USING btree (removal_time_);


--
-- Name: act_idx_auth_root_pi; Type: INDEX; Schema: camunda; Owner: -
--

CREATE INDEX act_idx_auth_root_pi ON camunda.act_ru_authorization USING btree (root_proc_inst_id_);


--
-- Name: act_idx_batch_id; Type: INDEX; Schema: camunda; Owner: -
--

CREATE INDEX act_idx_batch_id ON camunda.act_ru_variable USING btree (batch_id_);


--
-- Name: act_idx_batch_job_def; Type: INDEX; Schema: camunda; Owner: -
--

CREATE INDEX act_idx_batch_job_def ON camunda.act_ru_batch USING btree (batch_job_def_id_);


--
-- Name: act_idx_batch_monitor_job_def; Type: INDEX; Schema: camunda; Owner: -
--

CREATE INDEX act_idx_batch_monitor_job_def ON camunda.act_ru_batch USING btree (monitor_job_def_id_);


--
-- Name: act_idx_batch_seed_job_def; Type: INDEX; Schema: camunda; Owner: -
--

CREATE INDEX act_idx_batch_seed_job_def ON camunda.act_ru_batch USING btree (seed_job_def_id_);


--
-- Name: act_idx_bytear_depl; Type: INDEX; Schema: camunda; Owner: -
--

CREATE INDEX act_idx_bytear_depl ON camunda.act_ge_bytearray USING btree (deployment_id_);


--
-- Name: act_idx_bytearray_name; Type: INDEX; Schema: camunda; Owner: -
--

CREATE INDEX act_idx_bytearray_name ON camunda.act_ge_bytearray USING btree (name_);


--
-- Name: act_idx_bytearray_rm_time; Type: INDEX; Schema: camunda; Owner: -
--

CREATE INDEX act_idx_bytearray_rm_time ON camunda.act_ge_bytearray USING btree (removal_time_);


--
-- Name: act_idx_bytearray_root_pi; Type: INDEX; Schema: camunda; Owner: -
--

CREATE INDEX act_idx_bytearray_root_pi ON camunda.act_ge_bytearray USING btree (root_proc_inst_id_);


--
-- Name: act_idx_case_def_tenant_id; Type: INDEX; Schema: camunda; Owner: -
--

CREATE INDEX act_idx_case_def_tenant_id ON camunda.act_re_case_def USING btree (tenant_id_);


--
-- Name: act_idx_case_exe_case_def; Type: INDEX; Schema: camunda; Owner: -
--

CREATE INDEX act_idx_case_exe_case_def ON camunda.act_ru_case_execution USING btree (case_def_id_);


--
-- Name: act_idx_case_exe_case_inst; Type: INDEX; Schema: camunda; Owner: -
--

CREATE INDEX act_idx_case_exe_case_inst ON camunda.act_ru_case_execution USING btree (case_inst_id_);


--
-- Name: act_idx_case_exe_parent; Type: INDEX; Schema: camunda; Owner: -
--

CREATE INDEX act_idx_case_exe_parent ON camunda.act_ru_case_execution USING btree (parent_id_);


--
-- Name: act_idx_case_exec_buskey; Type: INDEX; Schema: camunda; Owner: -
--

CREATE INDEX act_idx_case_exec_buskey ON camunda.act_ru_case_execution USING btree (business_key_);


--
-- Name: act_idx_case_exec_tenant_id; Type: INDEX; Schema: camunda; Owner: -
--

CREATE INDEX act_idx_case_exec_tenant_id ON camunda.act_ru_case_execution USING btree (tenant_id_);


--
-- Name: act_idx_case_sentry_case_exec; Type: INDEX; Schema: camunda; Owner: -
--

CREATE INDEX act_idx_case_sentry_case_exec ON camunda.act_ru_case_sentry_part USING btree (case_exec_id_);


--
-- Name: act_idx_case_sentry_case_inst; Type: INDEX; Schema: camunda; Owner: -
--

CREATE INDEX act_idx_case_sentry_case_inst ON camunda.act_ru_case_sentry_part USING btree (case_inst_id_);


--
-- Name: act_idx_dec_def_req_id; Type: INDEX; Schema: camunda; Owner: -
--

CREATE INDEX act_idx_dec_def_req_id ON camunda.act_re_decision_def USING btree (dec_req_id_);


--
-- Name: act_idx_dec_def_tenant_id; Type: INDEX; Schema: camunda; Owner: -
--

CREATE INDEX act_idx_dec_def_tenant_id ON camunda.act_re_decision_def USING btree (tenant_id_);


--
-- Name: act_idx_dec_req_def_tenant_id; Type: INDEX; Schema: camunda; Owner: -
--

CREATE INDEX act_idx_dec_req_def_tenant_id ON camunda.act_re_decision_req_def USING btree (tenant_id_);


--
-- Name: act_idx_deployment_name; Type: INDEX; Schema: camunda; Owner: -
--

CREATE INDEX act_idx_deployment_name ON camunda.act_re_deployment USING btree (name_);


--
-- Name: act_idx_deployment_tenant_id; Type: INDEX; Schema: camunda; Owner: -
--

CREATE INDEX act_idx_deployment_tenant_id ON camunda.act_re_deployment USING btree (tenant_id_);


--
-- Name: act_idx_event_subscr; Type: INDEX; Schema: camunda; Owner: -
--

CREATE INDEX act_idx_event_subscr ON camunda.act_ru_event_subscr USING btree (execution_id_);


--
-- Name: act_idx_event_subscr_config_; Type: INDEX; Schema: camunda; Owner: -
--

CREATE INDEX act_idx_event_subscr_config_ ON camunda.act_ru_event_subscr USING btree (configuration_);


--
-- Name: act_idx_event_subscr_evt_name; Type: INDEX; Schema: camunda; Owner: -
--

CREATE INDEX act_idx_event_subscr_evt_name ON camunda.act_ru_event_subscr USING btree (event_name_);


--
-- Name: act_idx_event_subscr_tenant_id; Type: INDEX; Schema: camunda; Owner: -
--

CREATE INDEX act_idx_event_subscr_tenant_id ON camunda.act_ru_event_subscr USING btree (tenant_id_);


--
-- Name: act_idx_exe_parent; Type: INDEX; Schema: camunda; Owner: -
--

CREATE INDEX act_idx_exe_parent ON camunda.act_ru_execution USING btree (parent_id_);


--
-- Name: act_idx_exe_procdef; Type: INDEX; Schema: camunda; Owner: -
--

CREATE INDEX act_idx_exe_procdef ON camunda.act_ru_execution USING btree (proc_def_id_);


--
-- Name: act_idx_exe_procinst; Type: INDEX; Schema: camunda; Owner: -
--

CREATE INDEX act_idx_exe_procinst ON camunda.act_ru_execution USING btree (proc_inst_id_);


--
-- Name: act_idx_exe_root_pi; Type: INDEX; Schema: camunda; Owner: -
--

CREATE INDEX act_idx_exe_root_pi ON camunda.act_ru_execution USING btree (root_proc_inst_id_);


--
-- Name: act_idx_exe_super; Type: INDEX; Schema: camunda; Owner: -
--

CREATE INDEX act_idx_exe_super ON camunda.act_ru_execution USING btree (super_exec_);


--
-- Name: act_idx_exec_buskey; Type: INDEX; Schema: camunda; Owner: -
--

CREATE INDEX act_idx_exec_buskey ON camunda.act_ru_execution USING btree (business_key_);


--
-- Name: act_idx_exec_tenant_id; Type: INDEX; Schema: camunda; Owner: -
--

CREATE INDEX act_idx_exec_tenant_id ON camunda.act_ru_execution USING btree (tenant_id_);


--
-- Name: act_idx_ext_task_err_details; Type: INDEX; Schema: camunda; Owner: -
--

CREATE INDEX act_idx_ext_task_err_details ON camunda.act_ru_ext_task USING btree (error_details_id_);


--
-- Name: act_idx_ext_task_exec; Type: INDEX; Schema: camunda; Owner: -
--

CREATE INDEX act_idx_ext_task_exec ON camunda.act_ru_ext_task USING btree (execution_id_);


--
-- Name: act_idx_ext_task_priority; Type: INDEX; Schema: camunda; Owner: -
--

CREATE INDEX act_idx_ext_task_priority ON camunda.act_ru_ext_task USING btree (priority_);


--
-- Name: act_idx_ext_task_tenant_id; Type: INDEX; Schema: camunda; Owner: -
--

CREATE INDEX act_idx_ext_task_tenant_id ON camunda.act_ru_ext_task USING btree (tenant_id_);


--
-- Name: act_idx_ext_task_topic; Type: INDEX; Schema: camunda; Owner: -
--

CREATE INDEX act_idx_ext_task_topic ON camunda.act_ru_ext_task USING btree (topic_name_);


--
-- Name: act_idx_hi_act_inst_end; Type: INDEX; Schema: camunda; Owner: -
--

CREATE INDEX act_idx_hi_act_inst_end ON camunda.act_hi_actinst USING btree (end_time_);


--
-- Name: act_idx_hi_act_inst_proc_def_key; Type: INDEX; Schema: camunda; Owner: -
--

CREATE INDEX act_idx_hi_act_inst_proc_def_key ON camunda.act_hi_actinst USING btree (proc_def_key_);


--
-- Name: act_idx_hi_act_inst_rm_time; Type: INDEX; Schema: camunda; Owner: -
--

CREATE INDEX act_idx_hi_act_inst_rm_time ON camunda.act_hi_actinst USING btree (removal_time_);


--
-- Name: act_idx_hi_act_inst_tenant_id; Type: INDEX; Schema: camunda; Owner: -
--

CREATE INDEX act_idx_hi_act_inst_tenant_id ON camunda.act_hi_actinst USING btree (tenant_id_);


--
-- Name: act_idx_hi_actinst_root_pi; Type: INDEX; Schema: camunda; Owner: -
--

CREATE INDEX act_idx_hi_actinst_root_pi ON camunda.act_hi_actinst USING btree (root_proc_inst_id_);


--
-- Name: act_idx_hi_attachment_content; Type: INDEX; Schema: camunda; Owner: -
--

CREATE INDEX act_idx_hi_attachment_content ON camunda.act_hi_attachment USING btree (content_id_);


--
-- Name: act_idx_hi_attachment_procinst; Type: INDEX; Schema: camunda; Owner: -
--

CREATE INDEX act_idx_hi_attachment_procinst ON camunda.act_hi_attachment USING btree (proc_inst_id_);


--
-- Name: act_idx_hi_attachment_rm_time; Type: INDEX; Schema: camunda; Owner: -
--

CREATE INDEX act_idx_hi_attachment_rm_time ON camunda.act_hi_attachment USING btree (removal_time_);


--
-- Name: act_idx_hi_attachment_root_pi; Type: INDEX; Schema: camunda; Owner: -
--

CREATE INDEX act_idx_hi_attachment_root_pi ON camunda.act_hi_attachment USING btree (root_proc_inst_id_);


--
-- Name: act_idx_hi_attachment_task; Type: INDEX; Schema: camunda; Owner: -
--

CREATE INDEX act_idx_hi_attachment_task ON camunda.act_hi_attachment USING btree (task_id_);


--
-- Name: act_idx_hi_cas_a_i_create; Type: INDEX; Schema: camunda; Owner: -
--

CREATE INDEX act_idx_hi_cas_a_i_create ON camunda.act_hi_caseactinst USING btree (create_time_);


--
-- Name: act_idx_hi_cas_a_i_end; Type: INDEX; Schema: camunda; Owner: -
--

CREATE INDEX act_idx_hi_cas_a_i_end ON camunda.act_hi_caseactinst USING btree (end_time_);


--
-- Name: act_idx_hi_cas_a_i_tenant_id; Type: INDEX; Schema: camunda; Owner: -
--

CREATE INDEX act_idx_hi_cas_a_i_tenant_id ON camunda.act_hi_caseactinst USING btree (tenant_id_);


--
-- Name: act_idx_hi_cas_i_buskey; Type: INDEX; Schema: camunda; Owner: -
--

CREATE INDEX act_idx_hi_cas_i_buskey ON camunda.act_hi_caseinst USING btree (business_key_);


--
-- Name: act_idx_hi_cas_i_close; Type: INDEX; Schema: camunda; Owner: -
--

CREATE INDEX act_idx_hi_cas_i_close ON camunda.act_hi_caseinst USING btree (close_time_);


--
-- Name: act_idx_hi_cas_i_tenant_id; Type: INDEX; Schema: camunda; Owner: -
--

CREATE INDEX act_idx_hi_cas_i_tenant_id ON camunda.act_hi_caseinst USING btree (tenant_id_);


--
-- Name: act_idx_hi_casevar_case_inst; Type: INDEX; Schema: camunda; Owner: -
--

CREATE INDEX act_idx_hi_casevar_case_inst ON camunda.act_hi_varinst USING btree (case_inst_id_);


--
-- Name: act_idx_hi_comment_procinst; Type: INDEX; Schema: camunda; Owner: -
--

CREATE INDEX act_idx_hi_comment_procinst ON camunda.act_hi_comment USING btree (proc_inst_id_);


--
-- Name: act_idx_hi_comment_rm_time; Type: INDEX; Schema: camunda; Owner: -
--

CREATE INDEX act_idx_hi_comment_rm_time ON camunda.act_hi_comment USING btree (removal_time_);


--
-- Name: act_idx_hi_comment_root_pi; Type: INDEX; Schema: camunda; Owner: -
--

CREATE INDEX act_idx_hi_comment_root_pi ON camunda.act_hi_comment USING btree (root_proc_inst_id_);


--
-- Name: act_idx_hi_comment_task; Type: INDEX; Schema: camunda; Owner: -
--

CREATE INDEX act_idx_hi_comment_task ON camunda.act_hi_comment USING btree (task_id_);


--
-- Name: act_idx_hi_dec_in_inst; Type: INDEX; Schema: camunda; Owner: -
--

CREATE INDEX act_idx_hi_dec_in_inst ON camunda.act_hi_dec_in USING btree (dec_inst_id_);


--
-- Name: act_idx_hi_dec_in_rm_time; Type: INDEX; Schema: camunda; Owner: -
--

CREATE INDEX act_idx_hi_dec_in_rm_time ON camunda.act_hi_dec_in USING btree (removal_time_);


--
-- Name: act_idx_hi_dec_in_root_pi; Type: INDEX; Schema: camunda; Owner: -
--

CREATE INDEX act_idx_hi_dec_in_root_pi ON camunda.act_hi_dec_in USING btree (root_proc_inst_id_);


--
-- Name: act_idx_hi_dec_inst_act; Type: INDEX; Schema: camunda; Owner: -
--

CREATE INDEX act_idx_hi_dec_inst_act ON camunda.act_hi_decinst USING btree (act_id_);


--
-- Name: act_idx_hi_dec_inst_act_inst; Type: INDEX; Schema: camunda; Owner: -
--

CREATE INDEX act_idx_hi_dec_inst_act_inst ON camunda.act_hi_decinst USING btree (act_inst_id_);


--
-- Name: act_idx_hi_dec_inst_ci; Type: INDEX; Schema: camunda; Owner: -
--

CREATE INDEX act_idx_hi_dec_inst_ci ON camunda.act_hi_decinst USING btree (case_inst_id_);


--
-- Name: act_idx_hi_dec_inst_id; Type: INDEX; Schema: camunda; Owner: -
--

CREATE INDEX act_idx_hi_dec_inst_id ON camunda.act_hi_decinst USING btree (dec_def_id_);


--
-- Name: act_idx_hi_dec_inst_key; Type: INDEX; Schema: camunda; Owner: -
--

CREATE INDEX act_idx_hi_dec_inst_key ON camunda.act_hi_decinst USING btree (dec_def_key_);


--
-- Name: act_idx_hi_dec_inst_pi; Type: INDEX; Schema: camunda; Owner: -
--

CREATE INDEX act_idx_hi_dec_inst_pi ON camunda.act_hi_decinst USING btree (proc_inst_id_);


--
-- Name: act_idx_hi_dec_inst_req_id; Type: INDEX; Schema: camunda; Owner: -
--

CREATE INDEX act_idx_hi_dec_inst_req_id ON camunda.act_hi_decinst USING btree (dec_req_id_);


--
-- Name: act_idx_hi_dec_inst_req_key; Type: INDEX; Schema: camunda; Owner: -
--

CREATE INDEX act_idx_hi_dec_inst_req_key ON camunda.act_hi_decinst USING btree (dec_req_key_);


--
-- Name: act_idx_hi_dec_inst_rm_time; Type: INDEX; Schema: camunda; Owner: -
--

CREATE INDEX act_idx_hi_dec_inst_rm_time ON camunda.act_hi_decinst USING btree (removal_time_);


--
-- Name: act_idx_hi_dec_inst_root_id; Type: INDEX; Schema: camunda; Owner: -
--

CREATE INDEX act_idx_hi_dec_inst_root_id ON camunda.act_hi_decinst USING btree (root_dec_inst_id_);


--
-- Name: act_idx_hi_dec_inst_root_pi; Type: INDEX; Schema: camunda; Owner: -
--

CREATE INDEX act_idx_hi_dec_inst_root_pi ON camunda.act_hi_decinst USING btree (root_proc_inst_id_);


--
-- Name: act_idx_hi_dec_inst_tenant_id; Type: INDEX; Schema: camunda; Owner: -
--

CREATE INDEX act_idx_hi_dec_inst_tenant_id ON camunda.act_hi_decinst USING btree (tenant_id_);


--
-- Name: act_idx_hi_dec_inst_time; Type: INDEX; Schema: camunda; Owner: -
--

CREATE INDEX act_idx_hi_dec_inst_time ON camunda.act_hi_decinst USING btree (eval_time_);


--
-- Name: act_idx_hi_dec_out_inst; Type: INDEX; Schema: camunda; Owner: -
--

CREATE INDEX act_idx_hi_dec_out_inst ON camunda.act_hi_dec_out USING btree (dec_inst_id_);


--
-- Name: act_idx_hi_dec_out_rm_time; Type: INDEX; Schema: camunda; Owner: -
--

CREATE INDEX act_idx_hi_dec_out_rm_time ON camunda.act_hi_dec_out USING btree (removal_time_);


--
-- Name: act_idx_hi_dec_out_root_pi; Type: INDEX; Schema: camunda; Owner: -
--

CREATE INDEX act_idx_hi_dec_out_root_pi ON camunda.act_hi_dec_out USING btree (root_proc_inst_id_);


--
-- Name: act_idx_hi_detail_act_inst; Type: INDEX; Schema: camunda; Owner: -
--

CREATE INDEX act_idx_hi_detail_act_inst ON camunda.act_hi_detail USING btree (act_inst_id_);


--
-- Name: act_idx_hi_detail_bytear; Type: INDEX; Schema: camunda; Owner: -
--

CREATE INDEX act_idx_hi_detail_bytear ON camunda.act_hi_detail USING btree (bytearray_id_);


--
-- Name: act_idx_hi_detail_case_exec; Type: INDEX; Schema: camunda; Owner: -
--

CREATE INDEX act_idx_hi_detail_case_exec ON camunda.act_hi_detail USING btree (case_execution_id_);


--
-- Name: act_idx_hi_detail_case_inst; Type: INDEX; Schema: camunda; Owner: -
--

CREATE INDEX act_idx_hi_detail_case_inst ON camunda.act_hi_detail USING btree (case_inst_id_);


--
-- Name: act_idx_hi_detail_name; Type: INDEX; Schema: camunda; Owner: -
--

CREATE INDEX act_idx_hi_detail_name ON camunda.act_hi_detail USING btree (name_);


--
-- Name: act_idx_hi_detail_proc_def_key; Type: INDEX; Schema: camunda; Owner: -
--

CREATE INDEX act_idx_hi_detail_proc_def_key ON camunda.act_hi_detail USING btree (proc_def_key_);


--
-- Name: act_idx_hi_detail_proc_inst; Type: INDEX; Schema: camunda; Owner: -
--

CREATE INDEX act_idx_hi_detail_proc_inst ON camunda.act_hi_detail USING btree (proc_inst_id_);


--
-- Name: act_idx_hi_detail_rm_time; Type: INDEX; Schema: camunda; Owner: -
--

CREATE INDEX act_idx_hi_detail_rm_time ON camunda.act_hi_detail USING btree (removal_time_);


--
-- Name: act_idx_hi_detail_root_pi; Type: INDEX; Schema: camunda; Owner: -
--

CREATE INDEX act_idx_hi_detail_root_pi ON camunda.act_hi_detail USING btree (root_proc_inst_id_);


--
-- Name: act_idx_hi_detail_task_id; Type: INDEX; Schema: camunda; Owner: -
--

CREATE INDEX act_idx_hi_detail_task_id ON camunda.act_hi_detail USING btree (task_id_);


--
-- Name: act_idx_hi_detail_tenant_id; Type: INDEX; Schema: camunda; Owner: -
--

CREATE INDEX act_idx_hi_detail_tenant_id ON camunda.act_hi_detail USING btree (tenant_id_);


--
-- Name: act_idx_hi_detail_time; Type: INDEX; Schema: camunda; Owner: -
--

CREATE INDEX act_idx_hi_detail_time ON camunda.act_hi_detail USING btree (time_);


--
-- Name: act_idx_hi_detail_var_inst_id; Type: INDEX; Schema: camunda; Owner: -
--

CREATE INDEX act_idx_hi_detail_var_inst_id ON camunda.act_hi_detail USING btree (var_inst_id_);


--
-- Name: act_idx_hi_exttasklog_errordet; Type: INDEX; Schema: camunda; Owner: -
--

CREATE INDEX act_idx_hi_exttasklog_errordet ON camunda.act_hi_ext_task_log USING btree (error_details_id_);


--
-- Name: act_idx_hi_ident_link_rm_time; Type: INDEX; Schema: camunda; Owner: -
--

CREATE INDEX act_idx_hi_ident_link_rm_time ON camunda.act_hi_identitylink USING btree (removal_time_);


--
-- Name: act_idx_hi_ident_link_task; Type: INDEX; Schema: camunda; Owner: -
--

CREATE INDEX act_idx_hi_ident_link_task ON camunda.act_hi_identitylink USING btree (task_id_);


--
-- Name: act_idx_hi_ident_lnk_group; Type: INDEX; Schema: camunda; Owner: -
--

CREATE INDEX act_idx_hi_ident_lnk_group ON camunda.act_hi_identitylink USING btree (group_id_);


--
-- Name: act_idx_hi_ident_lnk_proc_def_key; Type: INDEX; Schema: camunda; Owner: -
--

CREATE INDEX act_idx_hi_ident_lnk_proc_def_key ON camunda.act_hi_identitylink USING btree (proc_def_key_);


--
-- Name: act_idx_hi_ident_lnk_root_pi; Type: INDEX; Schema: camunda; Owner: -
--

CREATE INDEX act_idx_hi_ident_lnk_root_pi ON camunda.act_hi_identitylink USING btree (root_proc_inst_id_);


--
-- Name: act_idx_hi_ident_lnk_tenant_id; Type: INDEX; Schema: camunda; Owner: -
--

CREATE INDEX act_idx_hi_ident_lnk_tenant_id ON camunda.act_hi_identitylink USING btree (tenant_id_);


--
-- Name: act_idx_hi_ident_lnk_timestamp; Type: INDEX; Schema: camunda; Owner: -
--

CREATE INDEX act_idx_hi_ident_lnk_timestamp ON camunda.act_hi_identitylink USING btree (timestamp_);


--
-- Name: act_idx_hi_ident_lnk_user; Type: INDEX; Schema: camunda; Owner: -
--

CREATE INDEX act_idx_hi_ident_lnk_user ON camunda.act_hi_identitylink USING btree (user_id_);


--
-- Name: act_idx_hi_incident_create_time; Type: INDEX; Schema: camunda; Owner: -
--

CREATE INDEX act_idx_hi_incident_create_time ON camunda.act_hi_incident USING btree (create_time_);


--
-- Name: act_idx_hi_incident_end_time; Type: INDEX; Schema: camunda; Owner: -
--

CREATE INDEX act_idx_hi_incident_end_time ON camunda.act_hi_incident USING btree (end_time_);


--
-- Name: act_idx_hi_incident_proc_def_key; Type: INDEX; Schema: camunda; Owner: -
--

CREATE INDEX act_idx_hi_incident_proc_def_key ON camunda.act_hi_incident USING btree (proc_def_key_);


--
-- Name: act_idx_hi_incident_procinst; Type: INDEX; Schema: camunda; Owner: -
--

CREATE INDEX act_idx_hi_incident_procinst ON camunda.act_hi_incident USING btree (proc_inst_id_);


--
-- Name: act_idx_hi_incident_rm_time; Type: INDEX; Schema: camunda; Owner: -
--

CREATE INDEX act_idx_hi_incident_rm_time ON camunda.act_hi_incident USING btree (removal_time_);


--
-- Name: act_idx_hi_incident_root_pi; Type: INDEX; Schema: camunda; Owner: -
--

CREATE INDEX act_idx_hi_incident_root_pi ON camunda.act_hi_incident USING btree (root_proc_inst_id_);


--
-- Name: act_idx_hi_incident_tenant_id; Type: INDEX; Schema: camunda; Owner: -
--

CREATE INDEX act_idx_hi_incident_tenant_id ON camunda.act_hi_incident USING btree (tenant_id_);


--
-- Name: act_idx_hi_job_log_ex_stack; Type: INDEX; Schema: camunda; Owner: -
--

CREATE INDEX act_idx_hi_job_log_ex_stack ON camunda.act_hi_job_log USING btree (job_exception_stack_id_);


--
-- Name: act_idx_hi_job_log_job_conf; Type: INDEX; Schema: camunda; Owner: -
--

CREATE INDEX act_idx_hi_job_log_job_conf ON camunda.act_hi_job_log USING btree (job_def_configuration_);


--
-- Name: act_idx_hi_job_log_job_def_id; Type: INDEX; Schema: camunda; Owner: -
--

CREATE INDEX act_idx_hi_job_log_job_def_id ON camunda.act_hi_job_log USING btree (job_def_id_);


--
-- Name: act_idx_hi_job_log_proc_def_key; Type: INDEX; Schema: camunda; Owner: -
--

CREATE INDEX act_idx_hi_job_log_proc_def_key ON camunda.act_hi_job_log USING btree (process_def_key_);


--
-- Name: act_idx_hi_job_log_procdef; Type: INDEX; Schema: camunda; Owner: -
--

CREATE INDEX act_idx_hi_job_log_procdef ON camunda.act_hi_job_log USING btree (process_def_id_);


--
-- Name: act_idx_hi_job_log_procinst; Type: INDEX; Schema: camunda; Owner: -
--

CREATE INDEX act_idx_hi_job_log_procinst ON camunda.act_hi_job_log USING btree (process_instance_id_);


--
-- Name: act_idx_hi_job_log_rm_time; Type: INDEX; Schema: camunda; Owner: -
--

CREATE INDEX act_idx_hi_job_log_rm_time ON camunda.act_hi_job_log USING btree (removal_time_);


--
-- Name: act_idx_hi_job_log_root_pi; Type: INDEX; Schema: camunda; Owner: -
--

CREATE INDEX act_idx_hi_job_log_root_pi ON camunda.act_hi_job_log USING btree (root_proc_inst_id_);


--
-- Name: act_idx_hi_job_log_tenant_id; Type: INDEX; Schema: camunda; Owner: -
--

CREATE INDEX act_idx_hi_job_log_tenant_id ON camunda.act_hi_job_log USING btree (tenant_id_);


--
-- Name: act_idx_hi_op_log_entity_type; Type: INDEX; Schema: camunda; Owner: -
--

CREATE INDEX act_idx_hi_op_log_entity_type ON camunda.act_hi_op_log USING btree (entity_type_);


--
-- Name: act_idx_hi_op_log_op_type; Type: INDEX; Schema: camunda; Owner: -
--

CREATE INDEX act_idx_hi_op_log_op_type ON camunda.act_hi_op_log USING btree (operation_type_);


--
-- Name: act_idx_hi_op_log_procdef; Type: INDEX; Schema: camunda; Owner: -
--

CREATE INDEX act_idx_hi_op_log_procdef ON camunda.act_hi_op_log USING btree (proc_def_id_);


--
-- Name: act_idx_hi_op_log_procinst; Type: INDEX; Schema: camunda; Owner: -
--

CREATE INDEX act_idx_hi_op_log_procinst ON camunda.act_hi_op_log USING btree (proc_inst_id_);


--
-- Name: act_idx_hi_op_log_rm_time; Type: INDEX; Schema: camunda; Owner: -
--

CREATE INDEX act_idx_hi_op_log_rm_time ON camunda.act_hi_op_log USING btree (removal_time_);


--
-- Name: act_idx_hi_op_log_root_pi; Type: INDEX; Schema: camunda; Owner: -
--

CREATE INDEX act_idx_hi_op_log_root_pi ON camunda.act_hi_op_log USING btree (root_proc_inst_id_);


--
-- Name: act_idx_hi_op_log_task; Type: INDEX; Schema: camunda; Owner: -
--

CREATE INDEX act_idx_hi_op_log_task ON camunda.act_hi_op_log USING btree (task_id_);


--
-- Name: act_idx_hi_op_log_timestamp; Type: INDEX; Schema: camunda; Owner: -
--

CREATE INDEX act_idx_hi_op_log_timestamp ON camunda.act_hi_op_log USING btree (timestamp_);


--
-- Name: act_idx_hi_op_log_user_id; Type: INDEX; Schema: camunda; Owner: -
--

CREATE INDEX act_idx_hi_op_log_user_id ON camunda.act_hi_op_log USING btree (user_id_);


--
-- Name: act_idx_hi_pro_i_buskey; Type: INDEX; Schema: camunda; Owner: -
--

CREATE INDEX act_idx_hi_pro_i_buskey ON camunda.act_hi_procinst USING btree (business_key_);


--
-- Name: act_idx_hi_pro_inst_end; Type: INDEX; Schema: camunda; Owner: -
--

CREATE INDEX act_idx_hi_pro_inst_end ON camunda.act_hi_procinst USING btree (end_time_);


--
-- Name: act_idx_hi_pro_inst_proc_def_key; Type: INDEX; Schema: camunda; Owner: -
--

CREATE INDEX act_idx_hi_pro_inst_proc_def_key ON camunda.act_hi_procinst USING btree (proc_def_key_);


--
-- Name: act_idx_hi_pro_inst_rm_time; Type: INDEX; Schema: camunda; Owner: -
--

CREATE INDEX act_idx_hi_pro_inst_rm_time ON camunda.act_hi_procinst USING btree (removal_time_);


--
-- Name: act_idx_hi_pro_inst_root_pi; Type: INDEX; Schema: camunda; Owner: -
--

CREATE INDEX act_idx_hi_pro_inst_root_pi ON camunda.act_hi_procinst USING btree (root_proc_inst_id_);


--
-- Name: act_idx_hi_pro_inst_tenant_id; Type: INDEX; Schema: camunda; Owner: -
--

CREATE INDEX act_idx_hi_pro_inst_tenant_id ON camunda.act_hi_procinst USING btree (tenant_id_);


--
-- Name: act_idx_hi_procvar_proc_inst; Type: INDEX; Schema: camunda; Owner: -
--

CREATE INDEX act_idx_hi_procvar_proc_inst ON camunda.act_hi_varinst USING btree (proc_inst_id_);


--
-- Name: act_idx_hi_task_inst_end; Type: INDEX; Schema: camunda; Owner: -
--

CREATE INDEX act_idx_hi_task_inst_end ON camunda.act_hi_taskinst USING btree (end_time_);


--
-- Name: act_idx_hi_task_inst_proc_def_key; Type: INDEX; Schema: camunda; Owner: -
--

CREATE INDEX act_idx_hi_task_inst_proc_def_key ON camunda.act_hi_taskinst USING btree (proc_def_key_);


--
-- Name: act_idx_hi_task_inst_rm_time; Type: INDEX; Schema: camunda; Owner: -
--

CREATE INDEX act_idx_hi_task_inst_rm_time ON camunda.act_hi_taskinst USING btree (removal_time_);


--
-- Name: act_idx_hi_task_inst_start; Type: INDEX; Schema: camunda; Owner: -
--

CREATE INDEX act_idx_hi_task_inst_start ON camunda.act_hi_taskinst USING btree (start_time_);


--
-- Name: act_idx_hi_task_inst_tenant_id; Type: INDEX; Schema: camunda; Owner: -
--

CREATE INDEX act_idx_hi_task_inst_tenant_id ON camunda.act_hi_taskinst USING btree (tenant_id_);


--
-- Name: act_idx_hi_taskinst_procinst; Type: INDEX; Schema: camunda; Owner: -
--

CREATE INDEX act_idx_hi_taskinst_procinst ON camunda.act_hi_taskinst USING btree (proc_inst_id_);


--
-- Name: act_idx_hi_taskinst_root_pi; Type: INDEX; Schema: camunda; Owner: -
--

CREATE INDEX act_idx_hi_taskinst_root_pi ON camunda.act_hi_taskinst USING btree (root_proc_inst_id_);


--
-- Name: act_idx_hi_var_inst_proc_def_key; Type: INDEX; Schema: camunda; Owner: -
--

CREATE INDEX act_idx_hi_var_inst_proc_def_key ON camunda.act_hi_varinst USING btree (proc_def_key_);


--
-- Name: act_idx_hi_var_inst_tenant_id; Type: INDEX; Schema: camunda; Owner: -
--

CREATE INDEX act_idx_hi_var_inst_tenant_id ON camunda.act_hi_varinst USING btree (tenant_id_);


--
-- Name: act_idx_hi_varinst_act_inst_id; Type: INDEX; Schema: camunda; Owner: -
--

CREATE INDEX act_idx_hi_varinst_act_inst_id ON camunda.act_hi_varinst USING btree (act_inst_id_);


--
-- Name: act_idx_hi_varinst_bytear; Type: INDEX; Schema: camunda; Owner: -
--

CREATE INDEX act_idx_hi_varinst_bytear ON camunda.act_hi_varinst USING btree (bytearray_id_);


--
-- Name: act_idx_hi_varinst_name; Type: INDEX; Schema: camunda; Owner: -
--

CREATE INDEX act_idx_hi_varinst_name ON camunda.act_hi_varinst USING btree (name_);


--
-- Name: act_idx_hi_varinst_rm_time; Type: INDEX; Schema: camunda; Owner: -
--

CREATE INDEX act_idx_hi_varinst_rm_time ON camunda.act_hi_varinst USING btree (removal_time_);


--
-- Name: act_idx_hi_varinst_root_pi; Type: INDEX; Schema: camunda; Owner: -
--

CREATE INDEX act_idx_hi_varinst_root_pi ON camunda.act_hi_varinst USING btree (root_proc_inst_id_);


--
-- Name: act_idx_ident_lnk_group; Type: INDEX; Schema: camunda; Owner: -
--

CREATE INDEX act_idx_ident_lnk_group ON camunda.act_ru_identitylink USING btree (group_id_);


--
-- Name: act_idx_ident_lnk_user; Type: INDEX; Schema: camunda; Owner: -
--

CREATE INDEX act_idx_ident_lnk_user ON camunda.act_ru_identitylink USING btree (user_id_);


--
-- Name: act_idx_inc_causeincid; Type: INDEX; Schema: camunda; Owner: -
--

CREATE INDEX act_idx_inc_causeincid ON camunda.act_ru_incident USING btree (cause_incident_id_);


--
-- Name: act_idx_inc_configuration; Type: INDEX; Schema: camunda; Owner: -
--

CREATE INDEX act_idx_inc_configuration ON camunda.act_ru_incident USING btree (configuration_);


--
-- Name: act_idx_inc_exid; Type: INDEX; Schema: camunda; Owner: -
--

CREATE INDEX act_idx_inc_exid ON camunda.act_ru_incident USING btree (execution_id_);


--
-- Name: act_idx_inc_job_def; Type: INDEX; Schema: camunda; Owner: -
--

CREATE INDEX act_idx_inc_job_def ON camunda.act_ru_incident USING btree (job_def_id_);


--
-- Name: act_idx_inc_procdefid; Type: INDEX; Schema: camunda; Owner: -
--

CREATE INDEX act_idx_inc_procdefid ON camunda.act_ru_incident USING btree (proc_def_id_);


--
-- Name: act_idx_inc_procinstid; Type: INDEX; Schema: camunda; Owner: -
--

CREATE INDEX act_idx_inc_procinstid ON camunda.act_ru_incident USING btree (proc_inst_id_);


--
-- Name: act_idx_inc_rootcauseincid; Type: INDEX; Schema: camunda; Owner: -
--

CREATE INDEX act_idx_inc_rootcauseincid ON camunda.act_ru_incident USING btree (root_cause_incident_id_);


--
-- Name: act_idx_inc_tenant_id; Type: INDEX; Schema: camunda; Owner: -
--

CREATE INDEX act_idx_inc_tenant_id ON camunda.act_ru_incident USING btree (tenant_id_);


--
-- Name: act_idx_job_exception; Type: INDEX; Schema: camunda; Owner: -
--

CREATE INDEX act_idx_job_exception ON camunda.act_ru_job USING btree (exception_stack_id_);


--
-- Name: act_idx_job_execution_id; Type: INDEX; Schema: camunda; Owner: -
--

CREATE INDEX act_idx_job_execution_id ON camunda.act_ru_job USING btree (execution_id_);


--
-- Name: act_idx_job_handler_type; Type: INDEX; Schema: camunda; Owner: -
--

CREATE INDEX act_idx_job_handler_type ON camunda.act_ru_job USING btree (handler_type_);


--
-- Name: act_idx_job_job_def_id; Type: INDEX; Schema: camunda; Owner: -
--

CREATE INDEX act_idx_job_job_def_id ON camunda.act_ru_job USING btree (job_def_id_);


--
-- Name: act_idx_job_procinst; Type: INDEX; Schema: camunda; Owner: -
--

CREATE INDEX act_idx_job_procinst ON camunda.act_ru_job USING btree (process_instance_id_);


--
-- Name: act_idx_job_tenant_id; Type: INDEX; Schema: camunda; Owner: -
--

CREATE INDEX act_idx_job_tenant_id ON camunda.act_ru_job USING btree (tenant_id_);


--
-- Name: act_idx_jobdef_proc_def_id; Type: INDEX; Schema: camunda; Owner: -
--

CREATE INDEX act_idx_jobdef_proc_def_id ON camunda.act_ru_jobdef USING btree (proc_def_id_);


--
-- Name: act_idx_jobdef_tenant_id; Type: INDEX; Schema: camunda; Owner: -
--

CREATE INDEX act_idx_jobdef_tenant_id ON camunda.act_ru_jobdef USING btree (tenant_id_);


--
-- Name: act_idx_memb_group; Type: INDEX; Schema: camunda; Owner: -
--

CREATE INDEX act_idx_memb_group ON camunda.act_id_membership USING btree (group_id_);


--
-- Name: act_idx_memb_user; Type: INDEX; Schema: camunda; Owner: -
--

CREATE INDEX act_idx_memb_user ON camunda.act_id_membership USING btree (user_id_);


--
-- Name: act_idx_meter_log_ms; Type: INDEX; Schema: camunda; Owner: -
--

CREATE INDEX act_idx_meter_log_ms ON camunda.act_ru_meter_log USING btree (milliseconds_);


--
-- Name: act_idx_meter_log_time; Type: INDEX; Schema: camunda; Owner: -
--

CREATE INDEX act_idx_meter_log_time ON camunda.act_ru_meter_log USING btree (timestamp_);


--
-- Name: act_idx_procdef_deployment_id; Type: INDEX; Schema: camunda; Owner: -
--

CREATE INDEX act_idx_procdef_deployment_id ON camunda.act_re_procdef USING btree (deployment_id_);


--
-- Name: act_idx_procdef_tenant_id; Type: INDEX; Schema: camunda; Owner: -
--

CREATE INDEX act_idx_procdef_tenant_id ON camunda.act_re_procdef USING btree (tenant_id_);


--
-- Name: act_idx_procdef_ver_tag; Type: INDEX; Schema: camunda; Owner: -
--

CREATE INDEX act_idx_procdef_ver_tag ON camunda.act_re_procdef USING btree (version_tag_);


--
-- Name: act_idx_task_assignee; Type: INDEX; Schema: camunda; Owner: -
--

CREATE INDEX act_idx_task_assignee ON camunda.act_ru_task USING btree (assignee_);


--
-- Name: act_idx_task_case_def_id; Type: INDEX; Schema: camunda; Owner: -
--

CREATE INDEX act_idx_task_case_def_id ON camunda.act_ru_task USING btree (case_def_id_);


--
-- Name: act_idx_task_case_exec; Type: INDEX; Schema: camunda; Owner: -
--

CREATE INDEX act_idx_task_case_exec ON camunda.act_ru_task USING btree (case_execution_id_);


--
-- Name: act_idx_task_create; Type: INDEX; Schema: camunda; Owner: -
--

CREATE INDEX act_idx_task_create ON camunda.act_ru_task USING btree (create_time_);


--
-- Name: act_idx_task_exec; Type: INDEX; Schema: camunda; Owner: -
--

CREATE INDEX act_idx_task_exec ON camunda.act_ru_task USING btree (execution_id_);


--
-- Name: act_idx_task_last_updated; Type: INDEX; Schema: camunda; Owner: -
--

CREATE INDEX act_idx_task_last_updated ON camunda.act_ru_task USING btree (last_updated_);


--
-- Name: act_idx_task_meter_log_time; Type: INDEX; Schema: camunda; Owner: -
--

CREATE INDEX act_idx_task_meter_log_time ON camunda.act_ru_task_meter_log USING btree (timestamp_);


--
-- Name: act_idx_task_owner; Type: INDEX; Schema: camunda; Owner: -
--

CREATE INDEX act_idx_task_owner ON camunda.act_ru_task USING btree (owner_);


--
-- Name: act_idx_task_procdef; Type: INDEX; Schema: camunda; Owner: -
--

CREATE INDEX act_idx_task_procdef ON camunda.act_ru_task USING btree (proc_def_id_);


--
-- Name: act_idx_task_procinst; Type: INDEX; Schema: camunda; Owner: -
--

CREATE INDEX act_idx_task_procinst ON camunda.act_ru_task USING btree (proc_inst_id_);


--
-- Name: act_idx_task_tenant_id; Type: INDEX; Schema: camunda; Owner: -
--

CREATE INDEX act_idx_task_tenant_id ON camunda.act_ru_task USING btree (tenant_id_);


--
-- Name: act_idx_tenant_memb; Type: INDEX; Schema: camunda; Owner: -
--

CREATE INDEX act_idx_tenant_memb ON camunda.act_id_tenant_member USING btree (tenant_id_);


--
-- Name: act_idx_tenant_memb_group; Type: INDEX; Schema: camunda; Owner: -
--

CREATE INDEX act_idx_tenant_memb_group ON camunda.act_id_tenant_member USING btree (group_id_);


--
-- Name: act_idx_tenant_memb_user; Type: INDEX; Schema: camunda; Owner: -
--

CREATE INDEX act_idx_tenant_memb_user ON camunda.act_id_tenant_member USING btree (user_id_);


--
-- Name: act_idx_tskass_task; Type: INDEX; Schema: camunda; Owner: -
--

CREATE INDEX act_idx_tskass_task ON camunda.act_ru_identitylink USING btree (task_id_);


--
-- Name: act_idx_var_bytearray; Type: INDEX; Schema: camunda; Owner: -
--

CREATE INDEX act_idx_var_bytearray ON camunda.act_ru_variable USING btree (bytearray_id_);


--
-- Name: act_idx_var_case_exe; Type: INDEX; Schema: camunda; Owner: -
--

CREATE INDEX act_idx_var_case_exe ON camunda.act_ru_variable USING btree (case_execution_id_);


--
-- Name: act_idx_var_case_inst_id; Type: INDEX; Schema: camunda; Owner: -
--

CREATE INDEX act_idx_var_case_inst_id ON camunda.act_ru_variable USING btree (case_inst_id_);


--
-- Name: act_idx_var_exe; Type: INDEX; Schema: camunda; Owner: -
--

CREATE INDEX act_idx_var_exe ON camunda.act_ru_variable USING btree (execution_id_);


--
-- Name: act_idx_var_procinst; Type: INDEX; Schema: camunda; Owner: -
--

CREATE INDEX act_idx_var_procinst ON camunda.act_ru_variable USING btree (proc_inst_id_);


--
-- Name: act_idx_variable_task_id; Type: INDEX; Schema: camunda; Owner: -
--

CREATE INDEX act_idx_variable_task_id ON camunda.act_ru_variable USING btree (task_id_);


--
-- Name: act_idx_variable_tenant_id; Type: INDEX; Schema: camunda; Owner: -
--

CREATE INDEX act_idx_variable_tenant_id ON camunda.act_ru_variable USING btree (tenant_id_);


--
-- Name: udx_request_s_number; Type: INDEX; Schema: crm_request; Owner: -
--

CREATE UNIQUE INDEX udx_request_s_number ON crm_request.request USING btree (s_number);


--
-- Name: udx_contractor_s_inn; Type: INDEX; Schema: dictionaries; Owner: -
--

CREATE UNIQUE INDEX udx_contractor_s_inn ON dictionaries.contractor USING btree (s_inn);


--
-- Name: udx_products_s_code; Type: INDEX; Schema: dictionaries; Owner: -
--

CREATE UNIQUE INDEX udx_products_s_code ON dictionaries.products USING btree (s_code);


--
-- Name: idx_component_component_parent; Type: INDEX; Schema: uni_component; Owner: -
--

CREATE INDEX idx_component_component_parent ON uni_component.component USING btree (id_parent);


--
-- Name: idx_component_sname; Type: INDEX; Schema: uni_component; Owner: -
--

CREATE UNIQUE INDEX idx_component_sname ON uni_component.component USING btree (s_name);


--
-- Name: error_id_component_idx; Type: INDEX; Schema: uni_error; Owner: -
--

CREATE INDEX error_id_component_idx ON uni_error.error USING btree (id_component);


--
-- Name: idx_defaulterror_unq_name; Type: INDEX; Schema: uni_error; Owner: -
--

CREATE UNIQUE INDEX idx_defaulterror_unq_name ON uni_error.error USING btree (s_name);


--
-- Name: act_ru_identitylink act_fk_athrz_procedef; Type: FK CONSTRAINT; Schema: camunda; Owner: -
--

ALTER TABLE ONLY camunda.act_ru_identitylink
    ADD CONSTRAINT act_fk_athrz_procedef FOREIGN KEY (proc_def_id_) REFERENCES camunda.act_re_procdef(id_);


--
-- Name: act_ru_batch act_fk_batch_job_def; Type: FK CONSTRAINT; Schema: camunda; Owner: -
--

ALTER TABLE ONLY camunda.act_ru_batch
    ADD CONSTRAINT act_fk_batch_job_def FOREIGN KEY (batch_job_def_id_) REFERENCES camunda.act_ru_jobdef(id_);


--
-- Name: act_ru_batch act_fk_batch_monitor_job_def; Type: FK CONSTRAINT; Schema: camunda; Owner: -
--

ALTER TABLE ONLY camunda.act_ru_batch
    ADD CONSTRAINT act_fk_batch_monitor_job_def FOREIGN KEY (monitor_job_def_id_) REFERENCES camunda.act_ru_jobdef(id_);


--
-- Name: act_ru_batch act_fk_batch_seed_job_def; Type: FK CONSTRAINT; Schema: camunda; Owner: -
--

ALTER TABLE ONLY camunda.act_ru_batch
    ADD CONSTRAINT act_fk_batch_seed_job_def FOREIGN KEY (seed_job_def_id_) REFERENCES camunda.act_ru_jobdef(id_);


--
-- Name: act_ge_bytearray act_fk_bytearr_depl; Type: FK CONSTRAINT; Schema: camunda; Owner: -
--

ALTER TABLE ONLY camunda.act_ge_bytearray
    ADD CONSTRAINT act_fk_bytearr_depl FOREIGN KEY (deployment_id_) REFERENCES camunda.act_re_deployment(id_);


--
-- Name: act_ru_case_execution act_fk_case_exe_case_def; Type: FK CONSTRAINT; Schema: camunda; Owner: -
--

ALTER TABLE ONLY camunda.act_ru_case_execution
    ADD CONSTRAINT act_fk_case_exe_case_def FOREIGN KEY (case_def_id_) REFERENCES camunda.act_re_case_def(id_);


--
-- Name: act_ru_case_execution act_fk_case_exe_case_inst; Type: FK CONSTRAINT; Schema: camunda; Owner: -
--

ALTER TABLE ONLY camunda.act_ru_case_execution
    ADD CONSTRAINT act_fk_case_exe_case_inst FOREIGN KEY (case_inst_id_) REFERENCES camunda.act_ru_case_execution(id_);


--
-- Name: act_ru_case_execution act_fk_case_exe_parent; Type: FK CONSTRAINT; Schema: camunda; Owner: -
--

ALTER TABLE ONLY camunda.act_ru_case_execution
    ADD CONSTRAINT act_fk_case_exe_parent FOREIGN KEY (parent_id_) REFERENCES camunda.act_ru_case_execution(id_);


--
-- Name: act_ru_case_sentry_part act_fk_case_sentry_case_exec; Type: FK CONSTRAINT; Schema: camunda; Owner: -
--

ALTER TABLE ONLY camunda.act_ru_case_sentry_part
    ADD CONSTRAINT act_fk_case_sentry_case_exec FOREIGN KEY (case_exec_id_) REFERENCES camunda.act_ru_case_execution(id_);


--
-- Name: act_ru_case_sentry_part act_fk_case_sentry_case_inst; Type: FK CONSTRAINT; Schema: camunda; Owner: -
--

ALTER TABLE ONLY camunda.act_ru_case_sentry_part
    ADD CONSTRAINT act_fk_case_sentry_case_inst FOREIGN KEY (case_inst_id_) REFERENCES camunda.act_ru_case_execution(id_);


--
-- Name: act_re_decision_def act_fk_dec_req; Type: FK CONSTRAINT; Schema: camunda; Owner: -
--

ALTER TABLE ONLY camunda.act_re_decision_def
    ADD CONSTRAINT act_fk_dec_req FOREIGN KEY (dec_req_id_) REFERENCES camunda.act_re_decision_req_def(id_);


--
-- Name: act_ru_event_subscr act_fk_event_exec; Type: FK CONSTRAINT; Schema: camunda; Owner: -
--

ALTER TABLE ONLY camunda.act_ru_event_subscr
    ADD CONSTRAINT act_fk_event_exec FOREIGN KEY (execution_id_) REFERENCES camunda.act_ru_execution(id_);


--
-- Name: act_ru_execution act_fk_exe_parent; Type: FK CONSTRAINT; Schema: camunda; Owner: -
--

ALTER TABLE ONLY camunda.act_ru_execution
    ADD CONSTRAINT act_fk_exe_parent FOREIGN KEY (parent_id_) REFERENCES camunda.act_ru_execution(id_);


--
-- Name: act_ru_execution act_fk_exe_procdef; Type: FK CONSTRAINT; Schema: camunda; Owner: -
--

ALTER TABLE ONLY camunda.act_ru_execution
    ADD CONSTRAINT act_fk_exe_procdef FOREIGN KEY (proc_def_id_) REFERENCES camunda.act_re_procdef(id_);


--
-- Name: act_ru_execution act_fk_exe_procinst; Type: FK CONSTRAINT; Schema: camunda; Owner: -
--

ALTER TABLE ONLY camunda.act_ru_execution
    ADD CONSTRAINT act_fk_exe_procinst FOREIGN KEY (proc_inst_id_) REFERENCES camunda.act_ru_execution(id_);


--
-- Name: act_ru_execution act_fk_exe_super; Type: FK CONSTRAINT; Schema: camunda; Owner: -
--

ALTER TABLE ONLY camunda.act_ru_execution
    ADD CONSTRAINT act_fk_exe_super FOREIGN KEY (super_exec_) REFERENCES camunda.act_ru_execution(id_);


--
-- Name: act_ru_ext_task act_fk_ext_task_error_details; Type: FK CONSTRAINT; Schema: camunda; Owner: -
--

ALTER TABLE ONLY camunda.act_ru_ext_task
    ADD CONSTRAINT act_fk_ext_task_error_details FOREIGN KEY (error_details_id_) REFERENCES camunda.act_ge_bytearray(id_);


--
-- Name: act_ru_ext_task act_fk_ext_task_exe; Type: FK CONSTRAINT; Schema: camunda; Owner: -
--

ALTER TABLE ONLY camunda.act_ru_ext_task
    ADD CONSTRAINT act_fk_ext_task_exe FOREIGN KEY (execution_id_) REFERENCES camunda.act_ru_execution(id_);


--
-- Name: act_ru_incident act_fk_inc_cause; Type: FK CONSTRAINT; Schema: camunda; Owner: -
--

ALTER TABLE ONLY camunda.act_ru_incident
    ADD CONSTRAINT act_fk_inc_cause FOREIGN KEY (cause_incident_id_) REFERENCES camunda.act_ru_incident(id_);


--
-- Name: act_ru_incident act_fk_inc_exe; Type: FK CONSTRAINT; Schema: camunda; Owner: -
--

ALTER TABLE ONLY camunda.act_ru_incident
    ADD CONSTRAINT act_fk_inc_exe FOREIGN KEY (execution_id_) REFERENCES camunda.act_ru_execution(id_);


--
-- Name: act_ru_incident act_fk_inc_job_def; Type: FK CONSTRAINT; Schema: camunda; Owner: -
--

ALTER TABLE ONLY camunda.act_ru_incident
    ADD CONSTRAINT act_fk_inc_job_def FOREIGN KEY (job_def_id_) REFERENCES camunda.act_ru_jobdef(id_);


--
-- Name: act_ru_incident act_fk_inc_procdef; Type: FK CONSTRAINT; Schema: camunda; Owner: -
--

ALTER TABLE ONLY camunda.act_ru_incident
    ADD CONSTRAINT act_fk_inc_procdef FOREIGN KEY (proc_def_id_) REFERENCES camunda.act_re_procdef(id_);


--
-- Name: act_ru_incident act_fk_inc_procinst; Type: FK CONSTRAINT; Schema: camunda; Owner: -
--

ALTER TABLE ONLY camunda.act_ru_incident
    ADD CONSTRAINT act_fk_inc_procinst FOREIGN KEY (proc_inst_id_) REFERENCES camunda.act_ru_execution(id_);


--
-- Name: act_ru_incident act_fk_inc_rcause; Type: FK CONSTRAINT; Schema: camunda; Owner: -
--

ALTER TABLE ONLY camunda.act_ru_incident
    ADD CONSTRAINT act_fk_inc_rcause FOREIGN KEY (root_cause_incident_id_) REFERENCES camunda.act_ru_incident(id_);


--
-- Name: act_ru_job act_fk_job_exception; Type: FK CONSTRAINT; Schema: camunda; Owner: -
--

ALTER TABLE ONLY camunda.act_ru_job
    ADD CONSTRAINT act_fk_job_exception FOREIGN KEY (exception_stack_id_) REFERENCES camunda.act_ge_bytearray(id_);


--
-- Name: act_id_membership act_fk_memb_group; Type: FK CONSTRAINT; Schema: camunda; Owner: -
--

ALTER TABLE ONLY camunda.act_id_membership
    ADD CONSTRAINT act_fk_memb_group FOREIGN KEY (group_id_) REFERENCES camunda.act_id_group(id_);


--
-- Name: act_id_membership act_fk_memb_user; Type: FK CONSTRAINT; Schema: camunda; Owner: -
--

ALTER TABLE ONLY camunda.act_id_membership
    ADD CONSTRAINT act_fk_memb_user FOREIGN KEY (user_id_) REFERENCES camunda.act_id_user(id_);


--
-- Name: act_ru_task act_fk_task_case_def; Type: FK CONSTRAINT; Schema: camunda; Owner: -
--

ALTER TABLE ONLY camunda.act_ru_task
    ADD CONSTRAINT act_fk_task_case_def FOREIGN KEY (case_def_id_) REFERENCES camunda.act_re_case_def(id_);


--
-- Name: act_ru_task act_fk_task_case_exe; Type: FK CONSTRAINT; Schema: camunda; Owner: -
--

ALTER TABLE ONLY camunda.act_ru_task
    ADD CONSTRAINT act_fk_task_case_exe FOREIGN KEY (case_execution_id_) REFERENCES camunda.act_ru_case_execution(id_);


--
-- Name: act_ru_task act_fk_task_exe; Type: FK CONSTRAINT; Schema: camunda; Owner: -
--

ALTER TABLE ONLY camunda.act_ru_task
    ADD CONSTRAINT act_fk_task_exe FOREIGN KEY (execution_id_) REFERENCES camunda.act_ru_execution(id_);


--
-- Name: act_ru_task act_fk_task_procdef; Type: FK CONSTRAINT; Schema: camunda; Owner: -
--

ALTER TABLE ONLY camunda.act_ru_task
    ADD CONSTRAINT act_fk_task_procdef FOREIGN KEY (proc_def_id_) REFERENCES camunda.act_re_procdef(id_);


--
-- Name: act_ru_task act_fk_task_procinst; Type: FK CONSTRAINT; Schema: camunda; Owner: -
--

ALTER TABLE ONLY camunda.act_ru_task
    ADD CONSTRAINT act_fk_task_procinst FOREIGN KEY (proc_inst_id_) REFERENCES camunda.act_ru_execution(id_);


--
-- Name: act_id_tenant_member act_fk_tenant_memb; Type: FK CONSTRAINT; Schema: camunda; Owner: -
--

ALTER TABLE ONLY camunda.act_id_tenant_member
    ADD CONSTRAINT act_fk_tenant_memb FOREIGN KEY (tenant_id_) REFERENCES camunda.act_id_tenant(id_);


--
-- Name: act_id_tenant_member act_fk_tenant_memb_group; Type: FK CONSTRAINT; Schema: camunda; Owner: -
--

ALTER TABLE ONLY camunda.act_id_tenant_member
    ADD CONSTRAINT act_fk_tenant_memb_group FOREIGN KEY (group_id_) REFERENCES camunda.act_id_group(id_);


--
-- Name: act_id_tenant_member act_fk_tenant_memb_user; Type: FK CONSTRAINT; Schema: camunda; Owner: -
--

ALTER TABLE ONLY camunda.act_id_tenant_member
    ADD CONSTRAINT act_fk_tenant_memb_user FOREIGN KEY (user_id_) REFERENCES camunda.act_id_user(id_);


--
-- Name: act_ru_identitylink act_fk_tskass_task; Type: FK CONSTRAINT; Schema: camunda; Owner: -
--

ALTER TABLE ONLY camunda.act_ru_identitylink
    ADD CONSTRAINT act_fk_tskass_task FOREIGN KEY (task_id_) REFERENCES camunda.act_ru_task(id_);


--
-- Name: act_ru_variable act_fk_var_batch; Type: FK CONSTRAINT; Schema: camunda; Owner: -
--

ALTER TABLE ONLY camunda.act_ru_variable
    ADD CONSTRAINT act_fk_var_batch FOREIGN KEY (batch_id_) REFERENCES camunda.act_ru_batch(id_);


--
-- Name: act_ru_variable act_fk_var_bytearray; Type: FK CONSTRAINT; Schema: camunda; Owner: -
--

ALTER TABLE ONLY camunda.act_ru_variable
    ADD CONSTRAINT act_fk_var_bytearray FOREIGN KEY (bytearray_id_) REFERENCES camunda.act_ge_bytearray(id_);


--
-- Name: act_ru_variable act_fk_var_case_exe; Type: FK CONSTRAINT; Schema: camunda; Owner: -
--

ALTER TABLE ONLY camunda.act_ru_variable
    ADD CONSTRAINT act_fk_var_case_exe FOREIGN KEY (case_execution_id_) REFERENCES camunda.act_ru_case_execution(id_);


--
-- Name: act_ru_variable act_fk_var_case_inst; Type: FK CONSTRAINT; Schema: camunda; Owner: -
--

ALTER TABLE ONLY camunda.act_ru_variable
    ADD CONSTRAINT act_fk_var_case_inst FOREIGN KEY (case_inst_id_) REFERENCES camunda.act_ru_case_execution(id_);


--
-- Name: act_ru_variable act_fk_var_exe; Type: FK CONSTRAINT; Schema: camunda; Owner: -
--

ALTER TABLE ONLY camunda.act_ru_variable
    ADD CONSTRAINT act_fk_var_exe FOREIGN KEY (execution_id_) REFERENCES camunda.act_ru_execution(id_);


--
-- Name: act_ru_variable act_fk_var_procinst; Type: FK CONSTRAINT; Schema: camunda; Owner: -
--

ALTER TABLE ONLY camunda.act_ru_variable
    ADD CONSTRAINT act_fk_var_procinst FOREIGN KEY (proc_inst_id_) REFERENCES camunda.act_ru_execution(id_);


--
-- Name: request fk_request_id_contractor; Type: FK CONSTRAINT; Schema: crm_request; Owner: -
--

ALTER TABLE ONLY crm_request.request
    ADD CONSTRAINT fk_request_id_contractor FOREIGN KEY (id_contractor) REFERENCES dictionaries.contractor(id);


--
-- Name: request_item fk_request_item_id_product; Type: FK CONSTRAINT; Schema: crm_request; Owner: -
--

ALTER TABLE ONLY crm_request.request_item
    ADD CONSTRAINT fk_request_item_id_product FOREIGN KEY (id_product) REFERENCES dictionaries.products(id);


--
-- Name: request_item fk_request_item_id_request; Type: FK CONSTRAINT; Schema: crm_request; Owner: -
--

ALTER TABLE ONLY crm_request.request_item
    ADD CONSTRAINT fk_request_item_id_request FOREIGN KEY (id_request) REFERENCES crm_request.request(id);


--
-- Name: request fk_request_s_state_code; Type: FK CONSTRAINT; Schema: crm_request; Owner: -
--

ALTER TABLE ONLY crm_request.request
    ADD CONSTRAINT fk_request_s_state_code FOREIGN KEY (s_state_code) REFERENCES crm_request.request_states(s_code);


--
-- Name: component fk_component_component_parent; Type: FK CONSTRAINT; Schema: uni_component; Owner: -
--

ALTER TABLE ONLY uni_component.component
    ADD CONSTRAINT fk_component_component_parent FOREIGN KEY (id_parent) REFERENCES uni_component.component(id) ON DELETE CASCADE;


--
-- Name: error error_component_fk; Type: FK CONSTRAINT; Schema: uni_error; Owner: -
--

ALTER TABLE ONLY uni_error.error
    ADD CONSTRAINT error_component_fk FOREIGN KEY (id_component) REFERENCES uni_component.component(id) ON DELETE CASCADE;


--
-- Name: SCHEMA camunda; Type: ACL; Schema: -; Owner: -
--

GRANT ALL ON SCHEMA camunda TO uni_admin;
GRANT USAGE ON SCHEMA camunda TO uni_user;


--
-- Name: SCHEMA crm_request; Type: ACL; Schema: -; Owner: -
--

GRANT ALL ON SCHEMA crm_request TO uni_admin;
GRANT USAGE ON SCHEMA crm_request TO uni_user;


--
-- Name: SCHEMA dictionaries; Type: ACL; Schema: -; Owner: -
--

GRANT ALL ON SCHEMA dictionaries TO uni_admin;
GRANT USAGE ON SCHEMA dictionaries TO uni_user;


--
-- Name: SCHEMA uni_api; Type: ACL; Schema: -; Owner: -
--

GRANT ALL ON SCHEMA uni_api TO uni_admin;
GRANT USAGE ON SCHEMA uni_api TO uni_user;


--
-- Name: SCHEMA uni_component; Type: ACL; Schema: -; Owner: -
--

GRANT ALL ON SCHEMA uni_component TO uni_admin;
GRANT USAGE ON SCHEMA uni_component TO uni_user;


--
-- Name: SCHEMA uni_const; Type: ACL; Schema: -; Owner: -
--

GRANT ALL ON SCHEMA uni_const TO uni_admin;
GRANT USAGE ON SCHEMA uni_const TO uni_user;


--
-- Name: SCHEMA uni_error; Type: ACL; Schema: -; Owner: -
--

GRANT ALL ON SCHEMA uni_error TO uni_admin;
GRANT USAGE ON SCHEMA uni_error TO uni_user;


--
-- Name: SCHEMA uni_generator; Type: ACL; Schema: -; Owner: -
--

GRANT ALL ON SCHEMA uni_generator TO uni_admin;
GRANT USAGE ON SCHEMA uni_generator TO uni_user;


--
-- Name: FUNCTION request__after_edit(idp_self public.t_id); Type: ACL; Schema: crm_request; Owner: -
--

GRANT ALL ON FUNCTION crm_request.request__after_edit(idp_self public.t_id) TO uni_user;


--
-- Name: FUNCTION request__create_request(); Type: ACL; Schema: crm_request; Owner: -
--

GRANT ALL ON FUNCTION crm_request.request__create_request() TO uni_admin;
GRANT ALL ON FUNCTION crm_request.request__create_request() TO uni_user;


--
-- Name: FUNCTION request__delete_record(idp_self public.t_id); Type: ACL; Schema: crm_request; Owner: -
--

GRANT ALL ON FUNCTION crm_request.request__delete_record(idp_self public.t_id) TO uni_user;


--
-- Name: SEQUENCE seq_request_number; Type: ACL; Schema: crm_request; Owner: -
--

GRANT ALL ON SEQUENCE crm_request.seq_request_number TO uni_admin;
GRANT ALL ON SEQUENCE crm_request.seq_request_number TO uni_user;


--
-- Name: TABLE request; Type: ACL; Schema: crm_request; Owner: -
--

GRANT ALL ON TABLE crm_request.request TO uni_admin;
GRANT SELECT,INSERT,UPDATE ON TABLE crm_request.request TO uni_user;


--
-- Name: FUNCTION request__get_row(idp_self public.t_id); Type: ACL; Schema: crm_request; Owner: -
--

GRANT ALL ON FUNCTION crm_request.request__get_row(idp_self public.t_id) TO uni_user;


--
-- Name: FUNCTION request__insert_record(); Type: ACL; Schema: crm_request; Owner: -
--

GRANT ALL ON FUNCTION crm_request.request__insert_record() TO uni_user;


--
-- Name: FUNCTION request__lock_record(idp_self public.t_id); Type: ACL; Schema: crm_request; Owner: -
--

GRANT ALL ON FUNCTION crm_request.request__lock_record(idp_self public.t_id) TO uni_user;


--
-- Name: FUNCTION request__set_contractor(idp_self public.t_id, p_value public.t_id, bp_internal_call public.t_boolean); Type: ACL; Schema: crm_request; Owner: -
--

GRANT ALL ON FUNCTION crm_request.request__set_contractor(idp_self public.t_id, p_value public.t_id, bp_internal_call public.t_boolean) TO uni_user;


--
-- Name: FUNCTION request__set_date(idp_self public.t_id, p_value public.t_date, bp_internal_call public.t_boolean); Type: ACL; Schema: crm_request; Owner: -
--

GRANT ALL ON FUNCTION crm_request.request__set_date(idp_self public.t_id, p_value public.t_date, bp_internal_call public.t_boolean) TO uni_user;


--
-- Name: FUNCTION request__set_description(idp_self public.t_id, p_value public.t_description, bp_internal_call public.t_boolean); Type: ACL; Schema: crm_request; Owner: -
--

GRANT ALL ON FUNCTION crm_request.request__set_description(idp_self public.t_id, p_value public.t_description, bp_internal_call public.t_boolean) TO uni_user;


--
-- Name: FUNCTION request__set_number(idp_self public.t_id, p_value public.t_shortstring, bp_internal_call public.t_boolean); Type: ACL; Schema: crm_request; Owner: -
--

GRANT ALL ON FUNCTION crm_request.request__set_number(idp_self public.t_id, p_value public.t_shortstring, bp_internal_call public.t_boolean) TO uni_user;


--
-- Name: FUNCTION request__set_release_date(idp_self public.t_id, p_value public.t_date, bp_internal_call public.t_boolean); Type: ACL; Schema: crm_request; Owner: -
--

GRANT ALL ON FUNCTION crm_request.request__set_release_date(idp_self public.t_id, p_value public.t_date, bp_internal_call public.t_boolean) TO uni_user;


--
-- Name: FUNCTION request__set_state_code(idp_self public.t_id, p_value public.t_code, bp_internal_call public.t_boolean); Type: ACL; Schema: crm_request; Owner: -
--

GRANT ALL ON FUNCTION crm_request.request__set_state_code(idp_self public.t_id, p_value public.t_code, bp_internal_call public.t_boolean) TO uni_user;


--
-- Name: FUNCTION request__validate(idp_self public.t_id); Type: ACL; Schema: crm_request; Owner: -
--

GRANT ALL ON FUNCTION crm_request.request__validate(idp_self public.t_id) TO uni_user;


--
-- Name: FUNCTION request_item__after_edit(idp_self public.t_id); Type: ACL; Schema: crm_request; Owner: -
--

GRANT ALL ON FUNCTION crm_request.request_item__after_edit(idp_self public.t_id) TO uni_user;


--
-- Name: FUNCTION request_item__delete_record(idp_self public.t_id); Type: ACL; Schema: crm_request; Owner: -
--

GRANT ALL ON FUNCTION crm_request.request_item__delete_record(idp_self public.t_id) TO uni_user;


--
-- Name: TABLE request_item; Type: ACL; Schema: crm_request; Owner: -
--

GRANT ALL ON TABLE crm_request.request_item TO uni_admin;
GRANT SELECT,INSERT,UPDATE ON TABLE crm_request.request_item TO uni_user;


--
-- Name: FUNCTION request_item__get_row(idp_self public.t_id); Type: ACL; Schema: crm_request; Owner: -
--

GRANT ALL ON FUNCTION crm_request.request_item__get_row(idp_self public.t_id) TO uni_user;


--
-- Name: FUNCTION request_item__insert_record(idp_request public.t_id, idp_product public.t_id); Type: ACL; Schema: crm_request; Owner: -
--

GRANT ALL ON FUNCTION crm_request.request_item__insert_record(idp_request public.t_id, idp_product public.t_id) TO uni_user;


--
-- Name: FUNCTION request_item__lock_record(idp_self public.t_id); Type: ACL; Schema: crm_request; Owner: -
--

GRANT ALL ON FUNCTION crm_request.request_item__lock_record(idp_self public.t_id) TO uni_user;


--
-- Name: FUNCTION request_item__set_product(idp_self public.t_id, p_value public.t_id, bp_internal_call public.t_boolean); Type: ACL; Schema: crm_request; Owner: -
--

GRANT ALL ON FUNCTION crm_request.request_item__set_product(idp_self public.t_id, p_value public.t_id, bp_internal_call public.t_boolean) TO uni_user;


--
-- Name: FUNCTION request_item__set_quantity(idp_self public.t_id, p_value public.t_float, bp_internal_call public.t_boolean); Type: ACL; Schema: crm_request; Owner: -
--

GRANT ALL ON FUNCTION crm_request.request_item__set_quantity(idp_self public.t_id, p_value public.t_float, bp_internal_call public.t_boolean) TO uni_user;


--
-- Name: FUNCTION request_item__set_quantity_exec(idp_self public.t_id, p_value public.t_float, bp_internal_call public.t_boolean); Type: ACL; Schema: crm_request; Owner: -
--

GRANT ALL ON FUNCTION crm_request.request_item__set_quantity_exec(idp_self public.t_id, p_value public.t_float, bp_internal_call public.t_boolean) TO uni_user;


--
-- Name: FUNCTION request_item__set_request(idp_self public.t_id, p_value public.t_id, bp_internal_call public.t_boolean); Type: ACL; Schema: crm_request; Owner: -
--

GRANT ALL ON FUNCTION crm_request.request_item__set_request(idp_self public.t_id, p_value public.t_id, bp_internal_call public.t_boolean) TO uni_user;


--
-- Name: FUNCTION request_item__validate(idp_self public.t_id); Type: ACL; Schema: crm_request; Owner: -
--

GRANT ALL ON FUNCTION crm_request.request_item__validate(idp_self public.t_id) TO uni_user;


--
-- Name: FUNCTION contractor__after_edit(idp_self public.t_id); Type: ACL; Schema: dictionaries; Owner: -
--

GRANT ALL ON FUNCTION dictionaries.contractor__after_edit(idp_self public.t_id) TO uni_user;


--
-- Name: FUNCTION contractor__delete_record(idp_self public.t_id); Type: ACL; Schema: dictionaries; Owner: -
--

GRANT ALL ON FUNCTION dictionaries.contractor__delete_record(idp_self public.t_id) TO uni_user;


--
-- Name: TABLE contractor; Type: ACL; Schema: dictionaries; Owner: -
--

GRANT ALL ON TABLE dictionaries.contractor TO uni_admin;
GRANT SELECT ON TABLE dictionaries.contractor TO uni_user;


--
-- Name: FUNCTION contractor__get_row(idp_self public.t_id); Type: ACL; Schema: dictionaries; Owner: -
--

GRANT ALL ON FUNCTION dictionaries.contractor__get_row(idp_self public.t_id) TO uni_user;


--
-- Name: FUNCTION contractor__insert_record(sp_inn public.t_shortstring); Type: ACL; Schema: dictionaries; Owner: -
--

GRANT ALL ON FUNCTION dictionaries.contractor__insert_record(sp_inn public.t_shortstring) TO uni_user;


--
-- Name: FUNCTION contractor__lock_record(idp_self public.t_id); Type: ACL; Schema: dictionaries; Owner: -
--

GRANT ALL ON FUNCTION dictionaries.contractor__lock_record(idp_self public.t_id) TO uni_user;


--
-- Name: FUNCTION contractor__set_caption(idp_self public.t_id, p_value public.t_caption, bp_internal_call public.t_boolean); Type: ACL; Schema: dictionaries; Owner: -
--

GRANT ALL ON FUNCTION dictionaries.contractor__set_caption(idp_self public.t_id, p_value public.t_caption, bp_internal_call public.t_boolean) TO uni_user;


--
-- Name: FUNCTION contractor__set_inn(idp_self public.t_id, p_value public.t_shortstring, bp_internal_call public.t_boolean); Type: ACL; Schema: dictionaries; Owner: -
--

GRANT ALL ON FUNCTION dictionaries.contractor__set_inn(idp_self public.t_id, p_value public.t_shortstring, bp_internal_call public.t_boolean) TO uni_user;


--
-- Name: FUNCTION contractor__validate(idp_self public.t_id); Type: ACL; Schema: dictionaries; Owner: -
--

GRANT ALL ON FUNCTION dictionaries.contractor__validate(idp_self public.t_id) TO uni_user;


--
-- Name: FUNCTION products__after_edit(idp_self public.t_id); Type: ACL; Schema: dictionaries; Owner: -
--

GRANT ALL ON FUNCTION dictionaries.products__after_edit(idp_self public.t_id) TO uni_user;


--
-- Name: FUNCTION products__create_product(); Type: ACL; Schema: dictionaries; Owner: -
--

GRANT ALL ON FUNCTION dictionaries.products__create_product() TO uni_user;


--
-- Name: FUNCTION products__delete_record(idp_self public.t_id); Type: ACL; Schema: dictionaries; Owner: -
--

GRANT ALL ON FUNCTION dictionaries.products__delete_record(idp_self public.t_id) TO uni_user;


--
-- Name: FUNCTION products__find_by_code(sp_code public.t_code); Type: ACL; Schema: dictionaries; Owner: -
--

GRANT ALL ON FUNCTION dictionaries.products__find_by_code(sp_code public.t_code) TO uni_user;


--
-- Name: TABLE products; Type: ACL; Schema: dictionaries; Owner: -
--

GRANT ALL ON TABLE dictionaries.products TO uni_admin;
GRANT SELECT,INSERT,UPDATE ON TABLE dictionaries.products TO uni_user;


--
-- Name: FUNCTION products__get_row(idp_self public.t_id); Type: ACL; Schema: dictionaries; Owner: -
--

GRANT ALL ON FUNCTION dictionaries.products__get_row(idp_self public.t_id) TO uni_user;


--
-- Name: FUNCTION products__insert_record(sp_code public.t_code); Type: ACL; Schema: dictionaries; Owner: -
--

GRANT ALL ON FUNCTION dictionaries.products__insert_record(sp_code public.t_code) TO uni_user;


--
-- Name: FUNCTION products__lock_record(idp_self public.t_id); Type: ACL; Schema: dictionaries; Owner: -
--

GRANT ALL ON FUNCTION dictionaries.products__lock_record(idp_self public.t_id) TO uni_user;


--
-- Name: FUNCTION products__set_caption(idp_self public.t_id, p_value public.t_caption, bp_internal_call public.t_boolean); Type: ACL; Schema: dictionaries; Owner: -
--

GRANT ALL ON FUNCTION dictionaries.products__set_caption(idp_self public.t_id, p_value public.t_caption, bp_internal_call public.t_boolean) TO uni_user;


--
-- Name: FUNCTION products__set_code(idp_self public.t_id, p_value public.t_code, bp_internal_call public.t_boolean); Type: ACL; Schema: dictionaries; Owner: -
--

GRANT ALL ON FUNCTION dictionaries.products__set_code(idp_self public.t_id, p_value public.t_code, bp_internal_call public.t_boolean) TO uni_user;


--
-- Name: FUNCTION products__set_lathe_time(idp_self public.t_id, p_value public.t_integer, bp_internal_call public.t_boolean); Type: ACL; Schema: dictionaries; Owner: -
--

GRANT ALL ON FUNCTION dictionaries.products__set_lathe_time(idp_self public.t_id, p_value public.t_integer, bp_internal_call public.t_boolean) TO uni_user;


--
-- Name: FUNCTION products__set_milling_time(idp_self public.t_id, p_value public.t_integer, bp_internal_call public.t_boolean); Type: ACL; Schema: dictionaries; Owner: -
--

GRANT ALL ON FUNCTION dictionaries.products__set_milling_time(idp_self public.t_id, p_value public.t_integer, bp_internal_call public.t_boolean) TO uni_user;


--
-- Name: FUNCTION products__validate(idp_self public.t_id); Type: ACL; Schema: dictionaries; Owner: -
--

GRANT ALL ON FUNCTION dictionaries.products__validate(idp_self public.t_id) TO uni_user;


--
-- Name: FUNCTION get_table_id(sp_schema public.t_name, sp_table public.t_name); Type: ACL; Schema: uni_api; Owner: -
--

GRANT ALL ON FUNCTION uni_api.get_table_id(sp_schema public.t_name, sp_table public.t_name) TO uni_user;
GRANT ALL ON FUNCTION uni_api.get_table_id(sp_schema public.t_name, sp_table public.t_name) TO uni_admin;


--
-- Name: FUNCTION set_table_field_value(sp_schema public.t_name, sp_table public.t_name, sp_field public.t_name, idp_self public.t_id, p_value public.t_boolean, sp_identityfield public.t_name); Type: ACL; Schema: uni_api; Owner: -
--

GRANT ALL ON FUNCTION uni_api.set_table_field_value(sp_schema public.t_name, sp_table public.t_name, sp_field public.t_name, idp_self public.t_id, p_value public.t_boolean, sp_identityfield public.t_name) TO uni_user;
GRANT ALL ON FUNCTION uni_api.set_table_field_value(sp_schema public.t_name, sp_table public.t_name, sp_field public.t_name, idp_self public.t_id, p_value public.t_boolean, sp_identityfield public.t_name) TO uni_admin;


--
-- Name: FUNCTION set_table_field_value(sp_schema public.t_name, sp_table public.t_name, sp_field public.t_name, idp_self public.t_id, p_value public.t_caption, sp_identityfield public.t_name); Type: ACL; Schema: uni_api; Owner: -
--

GRANT ALL ON FUNCTION uni_api.set_table_field_value(sp_schema public.t_name, sp_table public.t_name, sp_field public.t_name, idp_self public.t_id, p_value public.t_caption, sp_identityfield public.t_name) TO uni_user;
GRANT ALL ON FUNCTION uni_api.set_table_field_value(sp_schema public.t_name, sp_table public.t_name, sp_field public.t_name, idp_self public.t_id, p_value public.t_caption, sp_identityfield public.t_name) TO uni_admin;


--
-- Name: FUNCTION set_table_field_value(sp_schema public.t_name, sp_table public.t_name, sp_field public.t_name, idp_self public.t_id, p_value public.t_clob, sp_identityfield public.t_name); Type: ACL; Schema: uni_api; Owner: -
--

GRANT ALL ON FUNCTION uni_api.set_table_field_value(sp_schema public.t_name, sp_table public.t_name, sp_field public.t_name, idp_self public.t_id, p_value public.t_clob, sp_identityfield public.t_name) TO uni_user;
GRANT ALL ON FUNCTION uni_api.set_table_field_value(sp_schema public.t_name, sp_table public.t_name, sp_field public.t_name, idp_self public.t_id, p_value public.t_clob, sp_identityfield public.t_name) TO uni_admin;


--
-- Name: FUNCTION set_table_field_value(sp_schema public.t_name, sp_table public.t_name, sp_field public.t_name, idp_self public.t_id, p_value public.t_code, sp_identityfield public.t_name); Type: ACL; Schema: uni_api; Owner: -
--

GRANT ALL ON FUNCTION uni_api.set_table_field_value(sp_schema public.t_name, sp_table public.t_name, sp_field public.t_name, idp_self public.t_id, p_value public.t_code, sp_identityfield public.t_name) TO uni_user;
GRANT ALL ON FUNCTION uni_api.set_table_field_value(sp_schema public.t_name, sp_table public.t_name, sp_field public.t_name, idp_self public.t_id, p_value public.t_code, sp_identityfield public.t_name) TO uni_admin;


--
-- Name: FUNCTION set_table_field_value(sp_schema public.t_name, sp_table public.t_name, sp_field public.t_name, idp_self public.t_id, p_value public.t_date, sp_identityfield public.t_name); Type: ACL; Schema: uni_api; Owner: -
--

GRANT ALL ON FUNCTION uni_api.set_table_field_value(sp_schema public.t_name, sp_table public.t_name, sp_field public.t_name, idp_self public.t_id, p_value public.t_date, sp_identityfield public.t_name) TO uni_user;
GRANT ALL ON FUNCTION uni_api.set_table_field_value(sp_schema public.t_name, sp_table public.t_name, sp_field public.t_name, idp_self public.t_id, p_value public.t_date, sp_identityfield public.t_name) TO uni_admin;


--
-- Name: FUNCTION set_table_field_value(sp_schema public.t_name, sp_table public.t_name, sp_field public.t_name, idp_self public.t_id, p_value public.t_float, sp_identityfield public.t_name); Type: ACL; Schema: uni_api; Owner: -
--

GRANT ALL ON FUNCTION uni_api.set_table_field_value(sp_schema public.t_name, sp_table public.t_name, sp_field public.t_name, idp_self public.t_id, p_value public.t_float, sp_identityfield public.t_name) TO uni_user;


--
-- Name: FUNCTION set_table_field_value(sp_schema public.t_name, sp_table public.t_name, sp_field public.t_name, idp_self public.t_id, p_value public.t_html, sp_identityfield public.t_name); Type: ACL; Schema: uni_api; Owner: -
--

GRANT ALL ON FUNCTION uni_api.set_table_field_value(sp_schema public.t_name, sp_table public.t_name, sp_field public.t_name, idp_self public.t_id, p_value public.t_html, sp_identityfield public.t_name) TO uni_user;
GRANT ALL ON FUNCTION uni_api.set_table_field_value(sp_schema public.t_name, sp_table public.t_name, sp_field public.t_name, idp_self public.t_id, p_value public.t_html, sp_identityfield public.t_name) TO uni_admin;


--
-- Name: FUNCTION set_table_field_value(sp_schema public.t_name, sp_table public.t_name, sp_field public.t_name, idp_self public.t_id, p_value public.t_id, sp_identityfield public.t_name); Type: ACL; Schema: uni_api; Owner: -
--

GRANT ALL ON FUNCTION uni_api.set_table_field_value(sp_schema public.t_name, sp_table public.t_name, sp_field public.t_name, idp_self public.t_id, p_value public.t_id, sp_identityfield public.t_name) TO uni_user;
GRANT ALL ON FUNCTION uni_api.set_table_field_value(sp_schema public.t_name, sp_table public.t_name, sp_field public.t_name, idp_self public.t_id, p_value public.t_id, sp_identityfield public.t_name) TO uni_admin;


--
-- Name: FUNCTION set_table_field_value(sp_schema public.t_name, sp_table public.t_name, sp_field public.t_name, idp_self public.t_id, p_value public.t_integer, sp_identityfield public.t_name); Type: ACL; Schema: uni_api; Owner: -
--

GRANT ALL ON FUNCTION uni_api.set_table_field_value(sp_schema public.t_name, sp_table public.t_name, sp_field public.t_name, idp_self public.t_id, p_value public.t_integer, sp_identityfield public.t_name) TO uni_user;
GRANT ALL ON FUNCTION uni_api.set_table_field_value(sp_schema public.t_name, sp_table public.t_name, sp_field public.t_name, idp_self public.t_id, p_value public.t_integer, sp_identityfield public.t_name) TO uni_admin;


--
-- Name: FUNCTION set_table_field_value(sp_schema public.t_name, sp_table public.t_name, sp_field public.t_name, idp_self public.t_id, p_value public.t_json, sp_identityfield public.t_name); Type: ACL; Schema: uni_api; Owner: -
--

GRANT ALL ON FUNCTION uni_api.set_table_field_value(sp_schema public.t_name, sp_table public.t_name, sp_field public.t_name, idp_self public.t_id, p_value public.t_json, sp_identityfield public.t_name) TO uni_user;
GRANT ALL ON FUNCTION uni_api.set_table_field_value(sp_schema public.t_name, sp_table public.t_name, sp_field public.t_name, idp_self public.t_id, p_value public.t_json, sp_identityfield public.t_name) TO uni_admin;


--
-- Name: FUNCTION set_table_field_value(sp_schema public.t_name, sp_table public.t_name, sp_field public.t_name, idp_self public.t_id, p_value public.t_longstring, sp_identityfield public.t_name); Type: ACL; Schema: uni_api; Owner: -
--

GRANT ALL ON FUNCTION uni_api.set_table_field_value(sp_schema public.t_name, sp_table public.t_name, sp_field public.t_name, idp_self public.t_id, p_value public.t_longstring, sp_identityfield public.t_name) TO uni_user;
GRANT ALL ON FUNCTION uni_api.set_table_field_value(sp_schema public.t_name, sp_table public.t_name, sp_field public.t_name, idp_self public.t_id, p_value public.t_longstring, sp_identityfield public.t_name) TO uni_admin;


--
-- Name: FUNCTION set_table_field_value(sp_schema public.t_name, sp_table public.t_name, sp_field public.t_name, idp_self public.t_id, p_value public.t_money, sp_identityfield public.t_name); Type: ACL; Schema: uni_api; Owner: -
--

GRANT ALL ON FUNCTION uni_api.set_table_field_value(sp_schema public.t_name, sp_table public.t_name, sp_field public.t_name, idp_self public.t_id, p_value public.t_money, sp_identityfield public.t_name) TO uni_user;
GRANT ALL ON FUNCTION uni_api.set_table_field_value(sp_schema public.t_name, sp_table public.t_name, sp_field public.t_name, idp_self public.t_id, p_value public.t_money, sp_identityfield public.t_name) TO uni_admin;


--
-- Name: FUNCTION set_table_field_value(sp_schema public.t_name, sp_table public.t_name, sp_field public.t_name, idp_self public.t_id, p_value public.t_name, sp_identityfield public.t_name); Type: ACL; Schema: uni_api; Owner: -
--

GRANT ALL ON FUNCTION uni_api.set_table_field_value(sp_schema public.t_name, sp_table public.t_name, sp_field public.t_name, idp_self public.t_id, p_value public.t_name, sp_identityfield public.t_name) TO uni_user;
GRANT ALL ON FUNCTION uni_api.set_table_field_value(sp_schema public.t_name, sp_table public.t_name, sp_field public.t_name, idp_self public.t_id, p_value public.t_name, sp_identityfield public.t_name) TO uni_admin;


--
-- Name: FUNCTION set_table_field_value(sp_schema public.t_name, sp_table public.t_name, sp_field public.t_name, idp_self public.t_id, p_value public.t_shortstring, sp_identityfield public.t_name); Type: ACL; Schema: uni_api; Owner: -
--

GRANT ALL ON FUNCTION uni_api.set_table_field_value(sp_schema public.t_name, sp_table public.t_name, sp_field public.t_name, idp_self public.t_id, p_value public.t_shortstring, sp_identityfield public.t_name) TO uni_user;
GRANT ALL ON FUNCTION uni_api.set_table_field_value(sp_schema public.t_name, sp_table public.t_name, sp_field public.t_name, idp_self public.t_id, p_value public.t_shortstring, sp_identityfield public.t_name) TO uni_admin;


--
-- Name: FUNCTION set_table_field_value(sp_schema public.t_name, sp_table public.t_name, sp_field public.t_name, idp_self public.t_id, p_value public.t_xml, sp_identityfield public.t_name); Type: ACL; Schema: uni_api; Owner: -
--

GRANT ALL ON FUNCTION uni_api.set_table_field_value(sp_schema public.t_name, sp_table public.t_name, sp_field public.t_name, idp_self public.t_id, p_value public.t_xml, sp_identityfield public.t_name) TO uni_user;
GRANT ALL ON FUNCTION uni_api.set_table_field_value(sp_schema public.t_name, sp_table public.t_name, sp_field public.t_name, idp_self public.t_id, p_value public.t_xml, sp_identityfield public.t_name) TO uni_admin;


--
-- Name: FUNCTION component__after_edit(idp_self public.t_id); Type: ACL; Schema: uni_component; Owner: -
--

GRANT ALL ON FUNCTION uni_component.component__after_edit(idp_self public.t_id) TO uni_user;
GRANT ALL ON FUNCTION uni_component.component__after_edit(idp_self public.t_id) TO uni_admin;


--
-- Name: FUNCTION component__delete_record(idp_self public.t_id); Type: ACL; Schema: uni_component; Owner: -
--

GRANT ALL ON FUNCTION uni_component.component__delete_record(idp_self public.t_id) TO uni_user;
GRANT ALL ON FUNCTION uni_component.component__delete_record(idp_self public.t_id) TO uni_admin;


--
-- Name: FUNCTION component__find_by_name(sp_name public.t_name); Type: ACL; Schema: uni_component; Owner: -
--

GRANT ALL ON FUNCTION uni_component.component__find_by_name(sp_name public.t_name) TO uni_user;
GRANT ALL ON FUNCTION uni_component.component__find_by_name(sp_name public.t_name) TO uni_admin;


--
-- Name: TABLE component; Type: ACL; Schema: uni_component; Owner: -
--

GRANT SELECT ON TABLE uni_component.component TO uni_user;
GRANT SELECT,INSERT,DELETE,UPDATE ON TABLE uni_component.component TO uni_admin;


--
-- Name: FUNCTION component__get_row(idp_self public.t_id); Type: ACL; Schema: uni_component; Owner: -
--

GRANT ALL ON FUNCTION uni_component.component__get_row(idp_self public.t_id) TO uni_user;
GRANT ALL ON FUNCTION uni_component.component__get_row(idp_self public.t_id) TO uni_admin;


--
-- Name: FUNCTION component__insert_record(sp_name public.t_name); Type: ACL; Schema: uni_component; Owner: -
--

GRANT ALL ON FUNCTION uni_component.component__insert_record(sp_name public.t_name) TO uni_user;
GRANT ALL ON FUNCTION uni_component.component__insert_record(sp_name public.t_name) TO uni_admin;


--
-- Name: FUNCTION component__lock_record(idp_self public.t_id); Type: ACL; Schema: uni_component; Owner: -
--

GRANT ALL ON FUNCTION uni_component.component__lock_record(idp_self public.t_id) TO uni_user;
GRANT ALL ON FUNCTION uni_component.component__lock_record(idp_self public.t_id) TO uni_admin;


--
-- Name: FUNCTION component__set_caption(idp_self public.t_id, p_value public.t_caption); Type: ACL; Schema: uni_component; Owner: -
--

GRANT ALL ON FUNCTION uni_component.component__set_caption(idp_self public.t_id, p_value public.t_caption) TO uni_user;
GRANT ALL ON FUNCTION uni_component.component__set_caption(idp_self public.t_id, p_value public.t_caption) TO uni_admin;


--
-- Name: FUNCTION component__set_description(idp_self public.t_id, p_value public.t_description); Type: ACL; Schema: uni_component; Owner: -
--

GRANT ALL ON FUNCTION uni_component.component__set_description(idp_self public.t_id, p_value public.t_description) TO uni_user;
GRANT ALL ON FUNCTION uni_component.component__set_description(idp_self public.t_id, p_value public.t_description) TO uni_admin;


--
-- Name: FUNCTION component__set_name(idp_self public.t_id, p_value public.t_name); Type: ACL; Schema: uni_component; Owner: -
--

GRANT ALL ON FUNCTION uni_component.component__set_name(idp_self public.t_id, p_value public.t_name) TO uni_user;
GRANT ALL ON FUNCTION uni_component.component__set_name(idp_self public.t_id, p_value public.t_name) TO uni_admin;


--
-- Name: FUNCTION component__set_parent(idp_self public.t_id, p_value public.t_id); Type: ACL; Schema: uni_component; Owner: -
--

GRANT ALL ON FUNCTION uni_component.component__set_parent(idp_self public.t_id, p_value public.t_id) TO uni_user;
GRANT ALL ON FUNCTION uni_component.component__set_parent(idp_self public.t_id, p_value public.t_id) TO uni_admin;


--
-- Name: FUNCTION component__validate(idp_self public.t_id); Type: ACL; Schema: uni_component; Owner: -
--

GRANT ALL ON FUNCTION uni_component.component__validate(idp_self public.t_id) TO uni_user;
GRANT ALL ON FUNCTION uni_component.component__validate(idp_self public.t_id) TO uni_admin;


--
-- Name: FUNCTION endl(); Type: ACL; Schema: uni_const; Owner: -
--

GRANT ALL ON FUNCTION uni_const.endl() TO uni_user;
GRANT ALL ON FUNCTION uni_const.endl() TO uni_admin;


--
-- Name: FUNCTION max_date(); Type: ACL; Schema: uni_const; Owner: -
--

GRANT ALL ON FUNCTION uni_const.max_date() TO uni_user;


--
-- Name: FUNCTION min_date(); Type: ACL; Schema: uni_const; Owner: -
--

GRANT ALL ON FUNCTION uni_const.min_date() TO uni_user;


--
-- Name: FUNCTION reg_col_type(); Type: ACL; Schema: uni_const; Owner: -
--

GRANT ALL ON FUNCTION uni_const.reg_col_type() TO uni_admin;
GRANT ALL ON FUNCTION uni_const.reg_col_type() TO uni_user;


--
-- Name: FUNCTION reg_replace(sp_prefix public.t_name); Type: ACL; Schema: uni_const; Owner: -
--

GRANT ALL ON FUNCTION uni_const.reg_replace(sp_prefix public.t_name) TO uni_admin;
GRANT ALL ON FUNCTION uni_const.reg_replace(sp_prefix public.t_name) TO uni_user;


--
-- Name: FUNCTION error__after_edit(idp_self public.t_id); Type: ACL; Schema: uni_error; Owner: -
--

GRANT ALL ON FUNCTION uni_error.error__after_edit(idp_self public.t_id) TO uni_user;
GRANT ALL ON FUNCTION uni_error.error__after_edit(idp_self public.t_id) TO uni_admin;


--
-- Name: FUNCTION error__delete_record(idp_self public.t_id); Type: ACL; Schema: uni_error; Owner: -
--

GRANT ALL ON FUNCTION uni_error.error__delete_record(idp_self public.t_id) TO uni_user;
GRANT ALL ON FUNCTION uni_error.error__delete_record(idp_self public.t_id) TO uni_admin;


--
-- Name: FUNCTION error__find_by_name(sp_name public.t_name); Type: ACL; Schema: uni_error; Owner: -
--

GRANT ALL ON FUNCTION uni_error.error__find_by_name(sp_name public.t_name) TO uni_user;
GRANT ALL ON FUNCTION uni_error.error__find_by_name(sp_name public.t_name) TO uni_admin;


--
-- Name: TABLE error; Type: ACL; Schema: uni_error; Owner: -
--

GRANT SELECT,INSERT,DELETE,UPDATE ON TABLE uni_error.error TO uni_admin;
GRANT SELECT ON TABLE uni_error.error TO uni_user;


--
-- Name: FUNCTION error__get_row(idp_self public.t_id); Type: ACL; Schema: uni_error; Owner: -
--

GRANT ALL ON FUNCTION uni_error.error__get_row(idp_self public.t_id) TO uni_user;
GRANT ALL ON FUNCTION uni_error.error__get_row(idp_self public.t_id) TO uni_admin;


--
-- Name: FUNCTION error__insert_record(sp_name public.t_name, idp_component public.t_id); Type: ACL; Schema: uni_error; Owner: -
--

GRANT ALL ON FUNCTION uni_error.error__insert_record(sp_name public.t_name, idp_component public.t_id) TO uni_user;
GRANT ALL ON FUNCTION uni_error.error__insert_record(sp_name public.t_name, idp_component public.t_id) TO uni_admin;


--
-- Name: FUNCTION error__lock_record(idp_self public.t_id); Type: ACL; Schema: uni_error; Owner: -
--

GRANT ALL ON FUNCTION uni_error.error__lock_record(idp_self public.t_id) TO uni_user;
GRANT ALL ON FUNCTION uni_error.error__lock_record(idp_self public.t_id) TO uni_admin;


--
-- Name: FUNCTION error__set_caption(idp_self public.t_id, p_value public.t_caption); Type: ACL; Schema: uni_error; Owner: -
--

GRANT ALL ON FUNCTION uni_error.error__set_caption(idp_self public.t_id, p_value public.t_caption) TO uni_user;
GRANT ALL ON FUNCTION uni_error.error__set_caption(idp_self public.t_id, p_value public.t_caption) TO uni_admin;


--
-- Name: FUNCTION error__set_component(idp_self public.t_id, p_value public.t_id); Type: ACL; Schema: uni_error; Owner: -
--

GRANT ALL ON FUNCTION uni_error.error__set_component(idp_self public.t_id, p_value public.t_id) TO uni_user;
GRANT ALL ON FUNCTION uni_error.error__set_component(idp_self public.t_id, p_value public.t_id) TO uni_admin;


--
-- Name: FUNCTION error__set_created(idp_self public.t_id, p_value public.t_datetime); Type: ACL; Schema: uni_error; Owner: -
--

GRANT ALL ON FUNCTION uni_error.error__set_created(idp_self public.t_id, p_value public.t_datetime) TO uni_user;
GRANT ALL ON FUNCTION uni_error.error__set_created(idp_self public.t_id, p_value public.t_datetime) TO uni_admin;


--
-- Name: FUNCTION error__set_description(idp_self public.t_id, p_value public.t_description); Type: ACL; Schema: uni_error; Owner: -
--

GRANT ALL ON FUNCTION uni_error.error__set_description(idp_self public.t_id, p_value public.t_description) TO uni_user;
GRANT ALL ON FUNCTION uni_error.error__set_description(idp_self public.t_id, p_value public.t_description) TO uni_admin;


--
-- Name: FUNCTION error__set_edited(idp_self public.t_id, p_value public.t_datetime); Type: ACL; Schema: uni_error; Owner: -
--

GRANT ALL ON FUNCTION uni_error.error__set_edited(idp_self public.t_id, p_value public.t_datetime) TO uni_user;
GRANT ALL ON FUNCTION uni_error.error__set_edited(idp_self public.t_id, p_value public.t_datetime) TO uni_admin;


--
-- Name: FUNCTION error__set_name(idp_self public.t_id, p_value public.t_name); Type: ACL; Schema: uni_error; Owner: -
--

GRANT ALL ON FUNCTION uni_error.error__set_name(idp_self public.t_id, p_value public.t_name) TO uni_user;
GRANT ALL ON FUNCTION uni_error.error__set_name(idp_self public.t_id, p_value public.t_name) TO uni_admin;


--
-- Name: FUNCTION error__validate(idp_self public.t_id); Type: ACL; Schema: uni_error; Owner: -
--

GRANT ALL ON FUNCTION uni_error.error__validate(idp_self public.t_id) TO uni_user;
GRANT ALL ON FUNCTION uni_error.error__validate(idp_self public.t_id) TO uni_admin;


--
-- Name: FUNCTION generate(sp_component public.t_name, sp_name public.t_name, VARIADIC params public.t_shortstring[]); Type: ACL; Schema: uni_error; Owner: -
--

GRANT ALL ON FUNCTION uni_error.generate(sp_component public.t_name, sp_name public.t_name, VARIADIC params public.t_shortstring[]) TO uni_user;
GRANT ALL ON FUNCTION uni_error.generate(sp_component public.t_name, sp_name public.t_name, VARIADIC params public.t_shortstring[]) TO uni_admin;


--
-- Name: FUNCTION generate_after_edit(sp_schemaname public.t_name, sp_tablename public.t_name); Type: ACL; Schema: uni_generator; Owner: -
--

GRANT ALL ON FUNCTION uni_generator.generate_after_edit(sp_schemaname public.t_name, sp_tablename public.t_name) TO uni_user;
GRANT ALL ON FUNCTION uni_generator.generate_after_edit(sp_schemaname public.t_name, sp_tablename public.t_name) TO uni_admin;


--
-- Name: FUNCTION generate_delete_record(sp_schemaname public.t_name, sp_tablename public.t_name); Type: ACL; Schema: uni_generator; Owner: -
--

GRANT ALL ON FUNCTION uni_generator.generate_delete_record(sp_schemaname public.t_name, sp_tablename public.t_name) TO uni_user;
GRANT ALL ON FUNCTION uni_generator.generate_delete_record(sp_schemaname public.t_name, sp_tablename public.t_name) TO uni_admin;


--
-- Name: FUNCTION generate_find_by_code(sp_schemaname public.t_name, sp_tablename public.t_name); Type: ACL; Schema: uni_generator; Owner: -
--

GRANT ALL ON FUNCTION uni_generator.generate_find_by_code(sp_schemaname public.t_name, sp_tablename public.t_name) TO uni_user;
GRANT ALL ON FUNCTION uni_generator.generate_find_by_code(sp_schemaname public.t_name, sp_tablename public.t_name) TO uni_admin;


--
-- Name: FUNCTION generate_find_by_name(sp_schemaname public.t_name, sp_tablename public.t_name); Type: ACL; Schema: uni_generator; Owner: -
--

GRANT ALL ON FUNCTION uni_generator.generate_find_by_name(sp_schemaname public.t_name, sp_tablename public.t_name) TO uni_admin;
GRANT ALL ON FUNCTION uni_generator.generate_find_by_name(sp_schemaname public.t_name, sp_tablename public.t_name) TO uni_user;


--
-- Name: FUNCTION generate_get_row(sp_schemaname public.t_name, sp_tablename public.t_name); Type: ACL; Schema: uni_generator; Owner: -
--

GRANT ALL ON FUNCTION uni_generator.generate_get_row(sp_schemaname public.t_name, sp_tablename public.t_name) TO uni_user;
GRANT ALL ON FUNCTION uni_generator.generate_get_row(sp_schemaname public.t_name, sp_tablename public.t_name) TO uni_admin;


--
-- Name: FUNCTION generate_grants(sp_schemaname public.t_name, sp_tablename public.t_name, sap_roles public.t_shortstring[]); Type: ACL; Schema: uni_generator; Owner: -
--

GRANT ALL ON FUNCTION uni_generator.generate_grants(sp_schemaname public.t_name, sp_tablename public.t_name, sap_roles public.t_shortstring[]) TO uni_user;
GRANT ALL ON FUNCTION uni_generator.generate_grants(sp_schemaname public.t_name, sp_tablename public.t_name, sap_roles public.t_shortstring[]) TO uni_admin;


--
-- Name: FUNCTION generate_insert_record(sp_schemaname public.t_name, sp_tablename public.t_name); Type: ACL; Schema: uni_generator; Owner: -
--

GRANT ALL ON FUNCTION uni_generator.generate_insert_record(sp_schemaname public.t_name, sp_tablename public.t_name) TO uni_user;
GRANT ALL ON FUNCTION uni_generator.generate_insert_record(sp_schemaname public.t_name, sp_tablename public.t_name) TO uni_admin;


--
-- Name: FUNCTION generate_lock_record(sp_schemaname public.t_name, sp_tablename public.t_name); Type: ACL; Schema: uni_generator; Owner: -
--

GRANT ALL ON FUNCTION uni_generator.generate_lock_record(sp_schemaname public.t_name, sp_tablename public.t_name) TO uni_user;
GRANT ALL ON FUNCTION uni_generator.generate_lock_record(sp_schemaname public.t_name, sp_tablename public.t_name) TO uni_admin;


--
-- Name: FUNCTION generate_setters(sp_schemaname public.t_name, sp_tablename public.t_name); Type: ACL; Schema: uni_generator; Owner: -
--

GRANT ALL ON FUNCTION uni_generator.generate_setters(sp_schemaname public.t_name, sp_tablename public.t_name) TO uni_user;
GRANT ALL ON FUNCTION uni_generator.generate_setters(sp_schemaname public.t_name, sp_tablename public.t_name) TO uni_admin;


--
-- Name: FUNCTION generate_table_api(sp_schemaname public.t_name, sp_tablename public.t_name); Type: ACL; Schema: uni_generator; Owner: -
--

GRANT ALL ON FUNCTION uni_generator.generate_table_api(sp_schemaname public.t_name, sp_tablename public.t_name) TO uni_user;
GRANT ALL ON FUNCTION uni_generator.generate_table_api(sp_schemaname public.t_name, sp_tablename public.t_name) TO uni_admin;


--
-- Name: FUNCTION generate_validate(sp_schemaname public.t_name, sp_tablename public.t_name); Type: ACL; Schema: uni_generator; Owner: -
--

GRANT ALL ON FUNCTION uni_generator.generate_validate(sp_schemaname public.t_name, sp_tablename public.t_name) TO uni_user;
GRANT ALL ON FUNCTION uni_generator.generate_validate(sp_schemaname public.t_name, sp_tablename public.t_name) TO uni_admin;


--
-- Name: TABLE request_states; Type: ACL; Schema: crm_request; Owner: -
--

GRANT ALL ON TABLE crm_request.request_states TO uni_admin;
GRANT SELECT ON TABLE crm_request.request_states TO uni_user;


--
-- Name: SEQUENCE seq_request; Type: ACL; Schema: crm_request; Owner: -
--

GRANT ALL ON SEQUENCE crm_request.seq_request TO uni_admin;
GRANT ALL ON SEQUENCE crm_request.seq_request TO uni_user;


--
-- Name: SEQUENCE seq_request_item; Type: ACL; Schema: crm_request; Owner: -
--

GRANT ALL ON SEQUENCE crm_request.seq_request_item TO uni_admin;
GRANT ALL ON SEQUENCE crm_request.seq_request_item TO uni_user;


--
-- Name: SEQUENCE seq_blanks; Type: ACL; Schema: dictionaries; Owner: -
--

GRANT ALL ON SEQUENCE dictionaries.seq_blanks TO uni_admin;
GRANT ALL ON SEQUENCE dictionaries.seq_blanks TO uni_user;


--
-- Name: SEQUENCE seq_material; Type: ACL; Schema: dictionaries; Owner: -
--

GRANT ALL ON SEQUENCE dictionaries.seq_material TO uni_admin;
GRANT ALL ON SEQUENCE dictionaries.seq_material TO uni_user;


--
-- Name: SEQUENCE seq_materials_in_blanks; Type: ACL; Schema: dictionaries; Owner: -
--

GRANT ALL ON SEQUENCE dictionaries.seq_materials_in_blanks TO uni_admin;
GRANT ALL ON SEQUENCE dictionaries.seq_materials_in_blanks TO uni_user;


--
-- Name: SEQUENCE seq_product_composition; Type: ACL; Schema: dictionaries; Owner: -
--

GRANT ALL ON SEQUENCE dictionaries.seq_product_composition TO uni_admin;
GRANT ALL ON SEQUENCE dictionaries.seq_product_composition TO uni_user;


--
-- Name: SEQUENCE seq_products; Type: ACL; Schema: dictionaries; Owner: -
--

GRANT ALL ON SEQUENCE dictionaries.seq_products TO uni_admin;
GRANT ALL ON SEQUENCE dictionaries.seq_products TO uni_user;


--
-- Name: SEQUENCE seq_component; Type: ACL; Schema: uni_component; Owner: -
--

GRANT SELECT ON SEQUENCE uni_component.seq_component TO uni_user;


--
-- Name: TABLE component_errors; Type: ACL; Schema: uni_error; Owner: -
--

GRANT SELECT ON TABLE uni_error.component_errors TO uni_admin;
GRANT SELECT ON TABLE uni_error.component_errors TO uni_user;


--
-- PostgreSQL database dump complete
--

